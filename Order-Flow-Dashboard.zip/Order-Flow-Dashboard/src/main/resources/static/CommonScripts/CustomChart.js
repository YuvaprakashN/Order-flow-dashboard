var charts = (function () {
    var chartDataLabel = function () {
        Chart.defaults.global.legend.labels.usePointStyle = true;
        Chart.plugins.register({
            afterDatasetsDraw: function (chart) {
                var ctx = chart.ctx;
                if (chart.config.type == "bar") {
                    if (chart.config.options.scales.xAxes[0].stacked == false) {
                        chart.data.datasets.forEach(function (dataset, i) {
                            var meta = chart.getDatasetMeta(i);
                            if (!meta.hidden) {
                                meta.data.forEach(function (element, index) {
                                    // Draw the text in black, with the specified font
                                    ctx.fillStyle = 'rgb(0, 0, 0)';

                                    var fontSize = 12;
                                    var fontStyle = 'normal';
                                    var fontFamily = 'Helvetica Neue';
                                    ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                                    // Just naively convert to string for now
                                    var dataString = dataset.data[index].toString();


                                    // Make sure alignment settings are correct
                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = 'middle';

                                    var padding = 1;
                                    var position = element.tooltipPosition();
                                    ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);

                                });
                            }
                        });
                    }
                }
                if (chart.config.type == "pie") {

                    chart.data.datasets.forEach(function (dataset, i) {
                        var meta = chart.getDatasetMeta(i);
                        if (!meta.hidden) {
                            meta.data.forEach(function (element, index) {
                                // Draw the text in black, with the specified font
                                ctx.fillStyle = 'rgb(0, 0, 0)';

                                var fontSize = 12;
                                var fontStyle = 'normal';
                                var fontFamily = 'Helvetica Neue';
                                ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                                // Just naively convert to string for now
                                var dataString = dataset.data[index].toString();


                                // Make sure alignment settings are correct
                                ctx.textAlign = 'center';
                                ctx.textBaseline = 'middle';

                                var padding = 1;
                                var position = element.tooltipPosition();
                                ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);

                            });
                        }
                    });
                }

                if (chart.config.type == "horizontalBar") {
                    chart.data.datasets.forEach(function (dataset, i) {
                        var meta = chart.getDatasetMeta(i);
                        if (!meta.hidden) {
                            meta.data.forEach(function (element, index) {
                                // Draw the text in black, with the specified font
                                ctx.fillStyle = 'rgb(0, 0, 0)';

                                var fontSize = 12;
                                var fontStyle = 'normal';
                                var fontFamily = 'Helvetica Neue';
                                ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                                // Just naively convert to string for now
                                var dataString = dataset.data[index].toString();

                                // Make sure alignment settings are correct
                                ctx.textAlign = 'center';
                                ctx.textBaseline = 'middle';

                                var xpadding = 9;
                                var ypadding = 1;
                                var position = element.tooltipPosition();
                                ctx.fillText(dataString, position.x + xpadding, position.y + ypadding);
                            });
                        }
                    });
                }
            }
        });

    };
    var barChart = function (ctx, dataSource, ylabel, isStacked, xbarPercentage, isXAxes, isLegend, chartTitle) {

        var chartTitleDisplay = true;
        if (chartTitle == "")
        {
            chartTitleDisplay = false;
        }

        var CTSBarChart = new Chart(ctx, {
            type: 'bar',
            data: dataSource,
            options: {
                title: {
                    display: chartTitleDisplay,
                    text: chartTitle,
                    position : 'top',
                    lineHeight: 2,
                    padding : 10
                },
                //responsive: true,
                layout: {
                    padding: {
                        top: 20
                    }
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            display: true
                        },
                        scaleLabel: {
                            display: true,
                        },
                        barPercentage: xbarPercentage,
                        stacked: isStacked,
                        //display: isXAxes,                        
                        //ticks: {
                        //    min: 6,
                        //    maxTicksLimit: 6,                          
                        //}

                    }],
                    yAxes: [{
                        ticks: {
                            min: 0,
                            maxTicksLimit: 6
                        },
                        scaleLabel: {
                            display: true,
                            labelString: ylabel
                        },
                        gridLines: {
                            display: true
                        },
                        stacked: isStacked

                    }],
                },
                tooltips: {
                    mode: 'label',
                    callbacks: {
                        label: function (tooltipItem, data) {
                            var corporation = data.datasets[tooltipItem.datasetIndex].label;
                            var valor = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                            var total = 0;
                            for (var i = 0; i < data.datasets.length; i++) {
                                total = parseInt(total) + parseInt(data.datasets[i].data[tooltipItem.index]);
                            }
                            if (tooltipItem.datasetIndex != data.datasets.length - 1) {
                                //return corporation + " : " + parseFloat(valor).toFixed(0).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                            } else {
                                //return [corporation + " : " + parseFloat(valor).toFixed(0).replace(/(\d)(?=(\d{3})+\.)/g, '$1,'), "Total : " + total];
                                return ["Total : " + total];
                            }

                        }
                    }
                },
                legend: {
                    display: isLegend,
                    position: 'bottom',
                    //labels: {
                    //    filter: function (legendItem, chartData) {
                    //        // if no data for this dataset, do not show the legend item.
                    //        return chartData[legendItem.datasetIndex].data.length;
                    //    }
                    //},
                },
                // onAnimationComplete: _Callback
                onClick: function (e) {
                    var activePoint = CTSBarChart.getElementAtEvent(e)[0];
                    if (typeof (activePoint) != "undefined") {
                        var data = activePoint._chart.data;
                        var datasetIndex = activePoint._datasetIndex;
                        var label = data.datasets[datasetIndex].label;
                        var value = data.datasets[datasetIndex].data[activePoint._index];
                        //alert(label + value);
                    }
                    //var activePoints = .getElementsAtXAxis(e);
                    //var selectedIndex = activePoints[0]._index;
                    //alert(this.data.datasets[0].data[selectedIndex]);

                },
            }
        });

    };

    var horizantalBarChart = function (ctx, dataSource, xlabel, chartTitle) {

        var CTSBarChart = new Chart(ctx, {
            type: 'horizontalBar',
            data: dataSource,
            options: {
                incidentNos: "2,546454,adfasdfa",
                layout: {
                    padding: {
                        top: 10,
                        right: 20,
                        left: 20

                    }
                },
                title: {
                    display: true,
                    text: chartTitle,
                    position: 'top',
                    lineHeight: 2,
                    padding: 10
                },
                responsive: true,
                scales: {
                    xAxes: [{
                        gridLines: {
                            display: false
                        },
                        ticks: {
                            maxTicksLimit: 7
                        },
                        scaleLabel: {
                            display: true,
                            labelString: xlabel
                        }
                    }],
                    yAxes: [{
                        type: 'category',
                        position: 'left',
                        display: true,
                        ticks: {
                            min: 6,
                            maxTicksLimit: 6,
                            reverse: true
                        },
                        barPercentage: .5,
                        scaleLabel: {
                            display: false,
                        },
                        gridLines: {
                            display: true
                        }
                    }],
                },
                legend: {
                    display: false,
                    position: 'right',
                },
                onClick: function (e) {
                    var activePoints = CTSBarChart.getElementsAtEvent(e);
                    var selectedIndex = activePoints[0]._index;
                    //alert(this.data.datasets[0].data[selectedIndex]);

                }
            },
            plugins: [{
                afterInit: function (chart) {
                    chart.data.labels.forEach(function (e, i, a) {
                        if (e.length > 25) {
                            a[i] = e.substring(0, 25) + "..."
                        }
                    })
                }
            }]

        });

    };

    var linechart = function (ctx, dataSource, ylabel) {
        var CTSLineChart = new Chart(ctx, {
            type: 'line',
            data: dataSource,
            options: {
                scales: {
                    xAxes: [{
                        time: {
                            unit: 'date'
                        },
                        gridLines: {
                            display: false
                        },
                        ticks: {
                            maxTicksLimit: 8
                        }
                    }],
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: ylabel
                        },
                        ticks: {
                            min: 0,
                            maxTicksLimit: 5
                        },
                        gridLines: {
                            color: "rgba(0, 0, 0, .125)",
                        }
                    }],
                },
                onClick: function (e) {
                    var activePoint = CTSLineChart.getElementAtEvent(e)[0];
                    if (typeof (activePoint) != "undefined") {
                        var data = activePoint._chart.data;
                        var datasetIndex = activePoint._datasetIndex;
                        var label = data.datasets[datasetIndex].label;
                        var value = data.datasets[datasetIndex].data[activePoint._index];
                        //alert(label + value);
                    }

                },
                legend: {
                    display: true,
                    position: 'top',
                }
            }
        });
    };

    var piechart = function (ctx, dataSource, ylabel) {
        var CTSPieChart = new Chart(ctx, {
            type: 'pie',
            data: dataSource,
            options: {
                legend: {
                    display: true,
                    position: 'right',
                },
                onClick: function (e) {
                    var activePoints = CTSPieChart.getElementsAtEvent(e);
                    var selectedIndex = activePoints[0]._index;
                    //alert(this.data.datasets[0].data[selectedIndex]);

                },

            },
        });
    };

    var barstackedChart = function (ctx, dataSource, ylabel, isStacked) {

        var CTSBarChart = new Chart(ctx, {
            type: 'bar',
            data: dataSource,
            options: {
                layout: {
                    padding: {
                        top: 20
                    }
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            display: false
                        },
                        ticks: {
                            maxTicksLimit: 6
                        },
                        barPercentage: 0.3,
                        stacked: isStacked

                    }],
                    yAxes: [{
                        ticks: {
                            min: 0,
                            maxTicksLimit: 6
                        },
                        scaleLabel: {
                            display: true,
                            labelString: ylabel
                        },
                        gridLines: {
                            display: true
                        },
                        stacked: isStacked
                    }],
                },
                tooltips: {
                    mode: 'label',
                    callbacks: {
                        label: function (tooltipItem, data) {
                            var corporation = data.datasets[tooltipItem.datasetIndex].label;
                            var valor = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                            var total = 0;
                            for (var i = 0; i < data.datasets.length; i++) {
                                total = parseInt(total) + parseInt(data.datasets[i].data[tooltipItem.index]);
                            }
                            if (tooltipItem.datasetIndex != data.datasets.length - 1) {
                            } else {
                                return ["Total : " + total];
                            }

                        }
                    }
                },
                plugins: {
                    datalabels: {
                        display: function (context) {
                            return context.dataset.data[context.dataIndex] > 0;
                        },
                        formatter: Math.round
                    }
                },
                legend: {
                    display: true,
                    position: 'bottom',
                    onClick: function (e) {
                        e.stopPropagation();
                    }
                }
            }
        });

    };


    return {
        Load: function () {
            chartDataLabel();
        },
        Bar: function (chart, dataSource, ylabel, isStacked, xbarPercentage, isXAxes, isLegend, chartTitle) {
            barChart(chart, dataSource, ylabel, isStacked, xbarPercentage, isXAxes, isLegend, chartTitle);
        },
        Line: function (chart, dataSource, ylabel) {
            linechart(chart, dataSource, ylabel);
        },
        Pie: function (chart, dataSource, ylabel) {
            piechart(chart, dataSource, ylabel);
        },
        HorizantalBar: function (chart, dataSource, xlabel, chartTitle) {
            horizantalBarChart(chart, dataSource, xlabel, chartTitle);
        },
        BarStacked: function (chart, dataSource, ylabel, isStacked) {
            barstackedChart(chart, dataSource, ylabel, isStacked);
        }

    }
})();


$(document).ready(function () {
    charts.Load();

});