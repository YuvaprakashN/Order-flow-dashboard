var inrHelperClass = (function () {
    var pageLoad = function () { 
         try{
    	   document.getElementById("statusEffTime").defaultValue = document.getElementById("ststm").innerHTML;
    	   document.getElementById("lastUpdateTime").defaultValue = document.getElementById("lut").innerHTML;
       }  catch (e) {
		// TODO: handle exception
		
	}
       
        $('#inrIndex1').DataTable({ "aaSorting": [] });
        $('#inrIndex2').DataTable({ "aaSorting": [] });
        $('#inrIndex3').DataTable({ "aaSorting": [] });
        $('#inrIndex4').DataTable({ "aaSorting": [] });
        
        $('#inrIndex5').DataTable({ "aaSorting": [] });
        $('#inrIndex6').DataTable({ "aaSorting": [] });
        $('#inrIndex7').DataTable({ "aaSorting": [] });
        $('#inrIndex8').DataTable({ "aaSorting": [] });
         
        
    };
    return {
        load: function () {        
            pageLoad();
        }
    }
})();

$(document).ready(function () {
    inrHelperClass.load();
});