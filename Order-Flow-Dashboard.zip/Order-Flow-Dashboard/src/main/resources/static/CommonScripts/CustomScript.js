﻿
var documentOnReady = (function () {

	 var pageLoad = function () {
	        //disableWSR();
	            
	     //   Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
	     //   Chart.defaults.global.defaultFontColor = '#292b2c';
	     //   disableLoader();
	     //   loadSubTowerDDL();
	        dateSelectorControl();     

	    };


    var initializEventHandlder = function () {

       

        var width_mql = window.matchMedia("(min-width: 785px)");

        width_mql.addListener(setup_for_width);

        setup_for_width(width_mql);
        

        $('#browse').click(function (e) {
            enableLoader();
        });
        $('#dashboard_link').click(function (e) {
            enableLoader();
        });

    };

    var setup_for_width = function (mql) {
        if (mql.matches) {
            $("#App_Title").text(" | Order Flow Management");
        } else {
            $("#App_Title").text(" | Order Flow Management");
        }
    }; 


    var dateSelectorControl = function () {

        //var start = moment().subtract(1, 'month').startOf('month');
        //var start = moment().startOf('month');
       //var end = moment().endOf('month');
       
       var start = moment().subtract(89, 'days').startOf('day');
       var end = moment().startOf('day');
        $('#dateSelector').daterangepicker({
            "showDropdowns": true,
            "timePicker": true,
            "timePicker24Hour": true,
            startDate: start,
            endDate: end,
            "opens": "right",
            locale: {
                format: 'YYYY/MM/DD hh:mm A'
            },
            ranges: {
                'Today': [moment().startOf('day'), moment().endOf('day')],
                'Yesterday': [moment().subtract(1, 'days').startOf('day'), moment().subtract(1, 'days').endOf('day')],
                'Last 7 Days': [moment().subtract(6, 'days').startOf('day'), moment().endOf('day')],
                'Last 30 Days': [moment().subtract(29, 'days').startOf('day'), moment().endOf('day')],
                'This Month': [moment().startOf('month').startOf('day'), moment().endOf('month').endOf('day')],
                'Last Month': [moment().subtract(1, 'month').startOf('month').startOf('day'), moment().subtract(1, 'month').endOf('month').endOf('day')],
                'Last 6 Months': [moment().subtract(6, 'month').startOf('month').startOf('day'), moment().endOf('month').endOf('day')],
                'Quater': [moment().startOf('Q').startOf('day'), moment().endOf('Q').endOf('day')],
                'Prev Quater': [moment().subtract(1, 'Q').startOf('Q').startOf('day'), moment().subtract(1, 'Q').endOf('Q').endOf('day')],

                'Current Year': [moment().startOf('year').startOf('day'), moment().endOf('year').endOf('day')]
            }
        }, setDefaultDate);

    };

    var setDefaultDate = function (start, end) {
        $('#dateSelector').val(start + ' - ' + end);
    };
   

    var enableLoader = function () {
        $("#navbarAccordion").block({ message: null });
        $("#mainNav").block({ message: null });
        $.blockUI({
            css: {
                border: 'none',
                padding: '15px',
                backgroundColor: '#000',
                '-webkit-border-radius': '10px',
                '-moz-border-radius': '10px',
                opacity: .5,
                color: '#fff'
            }
        });

    };


    var disableLoader = function () {
        $("#navbarAccordion").unblock({ message: null });
        $("#mainNav").unblock({ message: null });
        $.unblockUI();
    };


    return {

        load: function () {
        	 pageLoad();
            initializEventHandlder();
        },
        Enable_Loader: function () {
            enableLoader();
        },
        Disable_Loader: function () {
            disableLoader();
        }
    }

})();


$(document).ready(function () {
    documentOnReady.load();
//alert(window.location.href);
var url=window.location.href;
if(url.includes("finance")){
	//alert("finance page");
	$("#finance-nav").css("background-color", "#626b70");
}else if( url.includes("demandManagement")){
	$("#dm-nav").css("background-color", "#626b70");
	
}
else if(url.includes("demandFulfillment")){
	$("#df-nav").css("background-color", "#626b70");
}else if(url.includes("dashboard")){
	
	$("#dashboard-nav").css("background-color", "#626b70");
	
}

}

);







