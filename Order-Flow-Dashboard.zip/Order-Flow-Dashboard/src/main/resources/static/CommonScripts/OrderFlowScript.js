var orderFlowHelperClass = (function() {


	var eventsInitilization = function() {
dateSelectorControl();


		$("#search").click(function () {

			//  alert(date);
			var date = $('#orderFlowDateSelector').val();
			let startDate= date.split('-')[0];
			let endDate= date.split('-')[1];


			window.location.href = '/orderFlow/filter?fromDate=' + startDate + '&toDate=' + endDate;

		});



		}

	var dateSelectorControl = function () {
		//var start = moment().subtract(1, 'month').startOf('month');
		//var start = moment().startOf('month');
		//var end = moment().endOf('month');
		var start = moment().subtract(89, 'days').startOf('day');
		var end = moment().startOf('day');
		$('#orderFlowDateSelector').daterangepicker({
			"showDropdowns": true,
			"timePicker": true,
			"timePicker24Hour": true,
			startDate: start,
			endDate: end,
			"opens": "right",
			locale: {
				format: 'YYYY/MM/DD hh:mm A'
			},
			ranges: {
				'Today': [moment().startOf('day'), moment().endOf('day')],
				'Yesterday': [moment().subtract(1, 'days').startOf('day'), moment().subtract(1, 'days').endOf('day')],
				'Last 7 Days': [moment().subtract(6, 'days').startOf('day'), moment().endOf('day')],
				'Last 30 Days': [moment().subtract(29, 'days').startOf('day'), moment().endOf('day')],
				'This Month': [moment().startOf('month').startOf('day'), moment().endOf('month').endOf('day')],
				'Last Month': [moment().subtract(1, 'month').startOf('month').startOf('day'), moment().subtract(1, 'month').endOf('month').endOf('day')],
				'Last 6 Months': [moment().subtract(6, 'month').startOf('month').startOf('day'), moment().endOf('month').endOf('day')],
				'Quater': [moment().startOf('Q').startOf('day'), moment().endOf('Q').endOf('day')],
				'Prev Quater': [moment().subtract(1, 'Q').startOf('Q').startOf('day'), moment().subtract(1, 'Q').endOf('Q').endOf('day')],

				'Current Year': [moment().startOf('year').startOf('day'), moment().endOf('year').endOf('day')]
			}
		}, setDefaultDate);

	};

	var setDefaultDate = function (start, end) {
		$('#dateSelector').val(start + ' - ' + end);
	};
	return {
		load : function() {

			eventsInitilization();

		}
	}

})();

$(document).ready(function() {
	orderFlowHelperClass.load();
});