
var DashboardHelperClass = (function () {


    var pageLoad = function () {
    	//alert("Dashboard");
        loadGraph();

    };
       var loadGraph = function () {       
    	   var hrefCurrent=window.location.pathname;
    	 //  alert(hrefCurrent);
    	 
    	   if(hrefCurrent.includes("dashboard")){
        $('#finance_PieChart').remove();
        $('#Container_finance_BarChart').append(' <canvas id="finance_PieChart" width="100" height="50"></canvas>');
        $('#dm_BarChart').remove();
        $('#Container_dm_BarChart').append(' <canvas id="dm_BarChart" width="100" height="50"></canvas>');
        $('#df_BarChart').remove();
        $('#Container_df_BarChart').append(' <canvas id="df_BarChart" width="100" height="50"></canvas>');
        documentOnReady.Enable_Loader();

        $.ajax({
            type: 'GET',
            url: '/dashboard/dashboard_charts',
            dataType: 'json',
            success: function (data) {
         //   alert("SUCCESS");
            console.log(data);
		
                documentOnReady.Disable_Loader();
                financeStatus(data.financeHoldPieChartData);
                dmStatus(data.demandManagementExceptionBarChartData);
                dfStatus(data.demandFulfilmentBarChartData);

            },
            error: function (ex) {
                alert("error");
                alert('Failed to retrieve Tower.' + ex);
                documentOnReady.Disable_Loader();
            }
        });
        
    	   }
    };

        
     var financeStatus = function (sourceData) {
        var ctx = document.getElementById("finance_PieChart");
        charts.Pie(ctx, sourceData, "Order Count");
    };
    
     var dmStatus = function (sourceData) {
    console.log(sourceData);
        var ctx = document.getElementById("dm_BarChart");
        charts.Bar(ctx, sourceData, "Order Count", false, 0.9, true, true, "");
    };
    
    var dfStatus = function (sourceData) {
    console.log(sourceData);
        var ctx = document.getElementById("df_BarChart");
        charts.Bar(ctx, sourceData, "Order Count", false, 0.9, true, true, "");
    };
    
    

     
    var Chart = function (canvasDiv) {
           $(canvasDiv).parent().parent().parent().find('canvas').get(0).toBlob(function (blob) {
            saveAs(blob, "chart.png");
        });
    };
    return {
        Load: function () {
            pageLoad();
          
        }
    }
})();

$(document).ready(function () {
    DashboardHelperClass.Load();

});
