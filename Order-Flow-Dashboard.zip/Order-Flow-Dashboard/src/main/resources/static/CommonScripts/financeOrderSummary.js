var financeHelperClass = (function () {
	
   
    var eventsInitilization = function () {
    	        
        
  $('#financeBusinessExceptionsTable').on('click', 'td.details-control', function () {
    var table = $('#financeBusinessExceptionsTable').DataTable();
      var tr = $(this).closest('tr');
       var row = table.row(tr);
    
     if (row.child.isShown()) {
       tr.next('tr').removeClass('details-row');
       row.child.hide();
       tr.removeClass('shown');
     }
     else {
       row.child(innerTable(row.data())).show();
       tr.next('tr').addClass('details-row');
       tr.addClass('shown');
     }
    
  });
    	
    	
    $('#financeITExceptionsTable').on('click', 'td.details-control', function () {
    var table = $('#financeITExceptionsTable').DataTable();
      var tr = $(this).closest('tr');
       var row = table.row(tr);
    
     if (row.child.isShown()) {
       tr.next('tr').removeClass('details-row');
       row.child.hide();
       tr.removeClass('shown');
     }
     else {
       row.child(innerTable(row.data())).show();
       tr.next('tr').addClass('details-row');
       tr.addClass('shown');
     }
    
  });
  
  
        $("#search").click(function () {
        	var date = $('#dateSelector').val();
        	
         // alert("Search");
        //  alert(date);
            loadFinanceBusinessExceptionsSummary();   
            loadFinanceITExceptionsSummary();  
        });
        
    	
    };
    
    function innerTable (data) {
    	 var date = $('#dateSelector').val();
  	   let startDate= date.split('-')[0];
  	   let endDate= date.split('-')[1]; 
  	   
    var len = data.categoryLvl2List.length;
    var categoryLvl2Data = null;
     var htmlCode =  '<div class="details-container" >'+
          '<table cellpadding="5" cellspacing="0" border="0" class="details-table" width="100%" >'+
          '	<thead><tr><th>Name</th><th>Description</th><th>Order Line Count</th><th>SOP</th></tr></thead>';
    for (let i = 0; i < len; i++) {
    categoryLvl2Data = data.categoryLvl2List[i];
    htmlCode  = htmlCode+'<tr>'+
                
                  '<td style="background-color: #e83c76" class="badge badge-pill badge-danger">'+categoryLvl2Data.ord_flow_sum_dsc+':'+categoryLvl2Data.ord_flow_rsn_dsc+'</td>'+
                  '<td>'+categoryLvl2Data.ord_flow_stat_dsc+'</td>'+
                  '<td><a href="/orderDetails/'+categoryLvl2Data.orderFlowStatId+'?startDate='
					+ startDate + '&endDate=' + endDate+'">'+categoryLvl2Data.totOrderLineCnt+'</a></td>'+
                  '<td><a href="/SOP/Sample.docx" download>Test1</a></td>'
              '</tr>';
  }
htmlCode  = htmlCode+ '</table>'+
        '</div>';
console.log(htmlCode);
return htmlCode;
  };
    
    var loadFinanceBusinessExceptionsSummary=function(){
  // alert("loadFinanceBusinessExceptionsSummary");
   
   var date = $('#dateSelector').val();
        	   let startDate= date.split('-')[0];
        	   let endDate= date.split('-')[1]; 
        	  
        	
    
    $
    				.ajax({
    					type : 'GET',
    					
    					url : '/loadFinanceBusinessExceptionsTable?startDate='
    							+ startDate + '&endDate=' + endDate,
    					dataType : 'json',
    					success : function(dataSet) {
    					console.log(dataSet);
    						loadFinanceBusinessExceptionsTable(dataSet); 
    						documentOnReady.Disable_Loader();
    					},
    					error : function(ex) {
    						alert("fetch error occurred");
    						documentOnReady.Disable_Loader();
    					}
    				});

    
    };
    
     var loadFinanceITExceptionsSummary=function(){
   // alert("loadFinanceITExceptionsSummary");
      var date = $('#dateSelector').val();
        	   let startDate= date.split('-')[0];
        	   let endDate= date.split('-')[1]; 
        	   
        
		documentOnReady.Enable_Loader();
    $
    				.ajax({
    					type : 'GET',
    					
    					url : '/loadFinanceITExceptionsTable?startDate='
    							+ startDate + '&endDate=' + endDate,
    					dataType : 'json',
    					success : function(dataSet) {
    					console.log(dataSet);
    						loadFinanceITExceptionsTable(dataSet); 
    						documentOnReady.Disable_Loader();
    					},
    					error : function(ex) {
    						alert("fetch error occurred");
    						documentOnReady.Disable_Loader();
    					}
    				});

    
    };
    
        var loadFinanceBusinessExceptionsTable=function(dataset){
       
       
      
if ($.fn.dataTable.isDataTable("#financeBusinessExceptionsTable")) {
  $('#financeBusinessExceptionsTable').DataTable().destroy();
} 

        $('#financeBusinessExceptionsTable').DataTable({

    			data : dataset,
    			 columns : [
      {
        className      : 'details-control',
        defaultContent : '',
        data           : null,
        orderable      : false
      },
      { "data": "categoryLvl1Name", 
       "render": function(data, type, row) { return '<a href="#" class="badge badge-pill badge-danger" title="This is my tooltip content for:'+data+'" data-toggle="tooltip">'+data+'</a>'} },
       {data: 'categoryLvl1Desc'},
      {data : 'categoryLvl1Cnt'}
    ],    			
    			pagingType : 'full_numbers' 		});

      
    
        };
        
        var loadFinanceITExceptionsTable=function(dataset){   
        if ($.fn.dataTable.isDataTable("#financeITExceptionsTable")) {
  $('#financeITExceptionsTable').DataTable().destroy();
} 
        
      $('#financeITExceptionsTable').DataTable({

    			data : dataset,
    			 columns : [
      {
        className      : 'details-control rowexpand',
        defaultContent : '',
        data           : null,
        orderable      : false
      },
      {data : 'categoryLvl1Name'},
      {data: 'categoryLvl1Desc'},
      {data : 'categoryLvl1Cnt'}
    ],    			
    			pagingType : 'full_numbers' 		});
        
       }
    	
    return {
        load: function () {
            
            eventsInitilization();
            loadFinanceBusinessExceptionsSummary();   
            loadFinanceITExceptionsSummary();             
        }
    }
    
    
    
})();

$(document).ready(function () {
    financeHelperClass.load();
});