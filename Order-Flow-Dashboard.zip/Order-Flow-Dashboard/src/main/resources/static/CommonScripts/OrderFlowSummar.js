var financeHelperClass = (function() {

	var eventsInitilization = function() {

	}

	return {
		load : function() {

			eventsInitilization();
			loadDFBusinessExceptionsSummary();
			loadDFITExceptionsSummary();
		}
	}

})();

$(document).ready(function() {
	financeHelperClass.load();
});