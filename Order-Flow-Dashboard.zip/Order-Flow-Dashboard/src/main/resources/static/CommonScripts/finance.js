var financeHelperClass = (function () {
	
    var pageLoad = function () {   
    	
       try{
    	   
//    	   document.getElementById("statusEffTime").defaultValue = document.getElementById("financeDetail").innerHTML;
//    	   document.getElementById("lastUpdateTime").defaultValue = document.getElementById("lut").innerHTML;
//    	   document.getElementById("dateSelector").defaultValue=document.getElementById("ststm").innerHTML+" - "+document.getElementById("lut").innerHTML;
//    	   
    //	   var table = $('#financeDetail').DataTable();
    	   var date = $('#dateSelector').val();
    	   let startDate= date.split('-')[0];
    	   let endDate= date.split('-')[1];
    	  // alert("PageLoad");
    	   //alert(date);
       }  catch (e) {
		// TODO: handle exception
	}
    };
    
    var eventsInitilization = function () {
    	/*$("#financeHoldOrderOutflowCount").click(function(){
    		fecthRiskHoldOutFlowOrders(true);
    	});*/

        $("#search").click(function () {
        	var date = $('#dateSelector').val();
        	
         // alert("Search");
          alert(date);
          fecthRiskHoldOrders();
          fecthRiskHoldOutFlowOrders();
        });
        
        
        $("#test").click(function () {
        	
        	var date = $('#dateSelector').val();
        	
        alert(date);
        });
        
        
  $('#rowExpandExample').on('click', 'td.details-control', function () {
    alert("onclick");
    var table = $('#rowExpandExample').DataTable();
      var tr = $(this).closest('tr');
      alert(tr);
       var row = table.row(tr);
         alert(row);
    
     if (row.child.isShown()) {
       alert("if");
       tr.next('tr').removeClass('details-row');
       row.child.hide();
       tr.removeClass('shown');
     }
     else {
     alert("else");
       row.child(format1(row.data())).show();
       tr.next('tr').addClass('details-row');
       tr.addClass('shown');
     }
    
  });
    	
    };
    
    function format1 (data) {
    alert("format1");
      return '<div class="details-container">'+
          '<table cellpadding="5" cellspacing="0" border="0" class="details-table">'+
              '<tr>'+
                  '<td class="title">Person ID:</td>'+
                  '<td>'+data.firstName+'</td>'+
              '</tr>'+
            
          '</table>'+
        '</div>';
  };
    
    var fetchRowExpandData=function(){
    
    $
    				.ajax({
    					type : 'GET',
    					url : '/fetchRowExpandData',
    					dataType : 'json',
    					success : function(dataSet) {
    					alert("fetch success");
    						loadRowExpandTable(dataSet); 						

    						documentOnReady.Disable_Loader();
    					},
    					error : function(ex) {
    						alert("fetch error occurred");
    						documentOnReady.Disable_Loader();
    					}
    				});

    
    };
    
    var fetchFinanceOrderInflowDetail=function() {
  
    		  var date = $('#dateSelector').val();
        	   let startDate= date.split('-')[0];
        	   let endDate= date.split('-')[1]; 
    	
        	   console.log("SENDING RED to fetchFinanceOrderInflowDetail");
    		
    		
    		
    		const element = document.getElementById("financeInflowInnerDiv");
        	element.remove();
        	const finDiv=document.createElement("div");
        	finDiv.setAttribute("id","financeInflowInnerDiv");
        	const tabl=document.createElement("table");
        	tabl.setAttribute("id","financeInflowDetail");
        	tabl.setAttribute("class","table table-striped table-bordered");
        	finDiv.appendChild(tabl);
        	document.getElementById("financeOrderInflowTable").style.width="100%";
        	document.getElementById("financeOrderInflowTable").appendChild(finDiv);
    		documentOnReady.Enable_Loader();
    		$
    				.ajax({
    					type : 'GET',
    					url : '/FinanceInflowOrderDetails?startDate='
    							+ startDate + '&endDate=' + endDate,
    					dataType : 'json',
    					success : function(dataSet) {
    					//	alert("fecthRiskHoldOutFlowOrders - SUCCESS");
    						//   alert("SUCCESS");
    						//console.log(dataSet);
    						document.getElementById("financeInflowOrderCount").innerHTML = dataSet.length;
    						//if(isUpdateTable){
    						console.log("financeInflowCount updated");
    						loadFinanceInflowflowDetailTable(dataSet);//}
    						
    						console.log("loadFinanceOutflowDetailTable Binded");

    						documentOnReady.Disable_Loader();
    					},
    					error : function(ex) {
    						//alert("fecthRiskHoldOutFlowOrders - FAILED");
    					//	alert("error");
    					//	alert('Failed to retrieve Tower.' + ex);
    						documentOnReady.Disable_Loader();
    					}
    				});

    	};
    
    
    

        var loadRowExpandTable=function(dataset){
        console.log("Inside loadRowExpandTable");
        console.log(dataset);
        $('#rowExpandExample').DataTable({

    			data : dataset,
    			 columns : [
      {
        className      : 'details-control',
        defaultContent : '',
        data           : null,
        orderable      : false
      },
      {data : 'firstName'},
      {data : 'lastName'},
      {data : 'email'}
    ],    			
    			pagingType : 'full_numbers',
    
    // Localization
    language : {
      emptyTable     : 'Virhe! Haku epäonnistui.',
      zeroRecords    : 'Ei hakutuloksia.',
      thousands      : ',',
      processing     : 'Prosessoidaan...',
      loadingRecords : 'Ladataan...',
      info           : 'Sivu _PAGE_ / _PAGES_',
      infoEmpty      : 'Sivu 0 / 0',
      infoFiltered   : '(rajattu _MAX_ hakutuloksesta)',
      infoPostFix    : '',
      lengthMenu     : 'Rivien määrä _MENU_',
      search         : 'Hae:',
      paginate       : {
        first    : 'Ensimmäinen',
        last     : 'Viimeinen',
        next     : 'Seuraava',
        previous : 'Edellinen'
      },
      aria : {
        sortAscending  : ' aktivoi järjestääksesi sarake nousevasti',
        sortDescending : ' aktivoi järjestääksesi saraka laskevasti'
      }
      }  		});
        
        };
        var loadFinanceInflowflowDetailTable= function(dataSet){
        	
        	console.log("Inside loadFinanceInflowflowDetailTable");
        	
        	document.getElementById("financeInflowDetail").innerHTML='';
        	console.log("Binding Datatable: loadFinanceInflowflowDetailTable: ");
        	$('#financeInflowDetail').DataTable({

    			data : dataSet,
    			columns : [

    			{
    				title : 'Order#',
    				data : 'orderNumber'
    			}, {
    				title : 'Order Line#',
    				data : 'orderLineNumber'
    			}, {
    				title : 'Account number',
    				data : 'accountNumber'
    			}, {
    				title : 'Item number',
    				data : 'itemNumber'
    			},{
    				title : 'Order Date',
    				data : 'orderDate'
    			}, {
    				title : 'Finance Entered Date',
    				data : 'insertedTimestamp'
    			}, {
    				title : 'Last Updated Date',
    				data : 'lastUpdatedDate'
    			}, {
    				title : 'Current status',
    				data : 'ordmlineStatus'
    			}, ],
    		});
        };
        
    	
    	
    	
    
    
    
    var loadFinanceOutflowDetailTable= function(dataSet){
//    	var table=('#financeDetail').Datatable();
//    	table.draw();
    	
    	console.log("Inside loadFinanceOutflowDetailTable");
    	
    	document.getElementById("riskHoldOrderOutflowDetail").innerHTML='';
    	console.log("Binding Datatable: loadFinanceOutflowDetailTable: ");
    	//$("#riskHoldOrderOutflowDetail tr").remove();
    	$('#riskHoldOrderOutflowDetail').DataTable({

			data : dataSet,
			columns : [

			{
				title : 'Order#',
				data : 'orderNumber'
			}, {
				title : 'Order Line#',
				data : 'orderLineNumber'
			}, {
				title : 'Account number',
				data : 'accountNumber'
			}, {
				title : 'Item number',
				data : 'itemNumber'
			},{
				title : 'Order Date',
				data : 'orderDate'
			}, {
				title : 'Finance Entered Date',
				data : 'insertedTimestamp'
			}, {
				title : 'Last Updated Date',
				data : 'lastUpdatedDate'
			}, {
				title : 'Current status',
				data : 'ordmlineStatus'
			}, ],
		});
    };
    
    
    var loadFinanceDetailTable= function(dataSet){
//    	var table=('#financeDetail').Datatable();
//    	table.draw();
    	console.log("Inside loadFinanceDetailTables: "+dataSet.length);
    //	document.getElementById("financeDetail").innerHTML='';
    	
    	//var table = $('#financeDetail').DataTable();
    	//table.destroy();
    //	 $('#financeDetail').empty();
    	 
    	 
    	
    	/*const element = document.getElementById("financeDetail");
    	element.remove();
    	
    	const tabl=document.createElement("table");
    	tabl.setAttribute("id","financeDetail");

    	tabl.setAttribute("class","table table-striped table-bordered");
    	
    	document.getElementById("financeDetailDiv").appendChild(tabl);*/
    //	$("#financeDetail tr").remove(); 
    //	table.destroy();
   	// $('#financeDetail').empty();
    	console.log("Binding Datatable: loadFinanceDetailTable");
    //table=	
    	const element = document.getElementById("finDiv");
    	element.remove();
    	const finDiv=document.createElement("div");
    	finDiv.setAttribute("id","finDiv");
    	const tabl=document.createElement("table");
    	tabl.setAttribute("id","financeDetail");
    	tabl.setAttribute("class","table table-striped table-bordered");
    	finDiv.appendChild(tabl);
    	document.getElementById("financeDetailDiv").appendChild(finDiv);
    	$('#financeDetail').DataTable({

			data : dataSet,
			columns :
				/* [

						{
							title : 'Order#',
							data : 'orderNumber'
						}, {
							title : 'Order Line#',
							data : 'orderLineNumber'
						}, {
							title : 'Account number',
							data : 'accountNumber'
						}, {
							title : 'Item number',
							data : 'itemNumber'
						},{
							title : 'Order Date',
							data : 'orderDate'
						}, {
							title : 'Finance Entered Date',
							data : 'insertedTimestamp'
						}, {
							title : 'Last Updated Date',
							data : 'lastUpdatedDate'
						}, {
							title : 'Current status',
							data : 'ordmlineStatus'
						}, ],*/
			[

			{
				title : 'Order#',
				data : 'orderNumber'
			}, {
				title : 'Order Line#',
				data : 'orderLineNumber'
			}, {
				title : 'AOL LUT',
				data : 'aolLastUpdatedDate'
			}, {
				title : 'OL LUT',
				data : 'olLastUpdatedDate'
			}, {
				title : 'Status Eff TMS',
				data : 'statusEffTimestamp'
			}, {
				title : 'AOL Order status',
				data : 'activeOrdLnStatus'
			}, {
				title : 'OL Order status',
				data : 'ordmlineStatus'
			}, ],
		});
    };
    
    
    var fecthRiskHoldOutFlowOrders=function() {
	/*	var statEffTms = document.getElementById("statusEffTime").value;
		var lastUpdTms = document.getElementById("lastUpdateTime").value;*/
//		var table = $('#financeDetail').DataTable();
//
//		table.destroy();
		//$("#riskHoldOrderOutflowDetail").ajax.reload();
		  var date = $('#dateSelector').val();
    	   let startDate= date.split('-')[0];
    	   let endDate= date.split('-')[1]; 
		/*   alert(statEffTms);
		  alert(lastUpdTms);
		 */
    	   console.log("SENDING RED to fecthRiskHoldOutFlowOrders");
	//	alert(date);
		
		
		
		const element = document.getElementById("financeOtflowInnerDiv");
    	element.remove();
    	const finDiv=document.createElement("div");
    	finDiv.setAttribute("id","financeOtflowInnerDiv");
    	const tabl=document.createElement("table");
    	tabl.setAttribute("id","riskHoldOrderOutflowDetail");
    	tabl.setAttribute("class","table table-striped table-bordered");
    	finDiv.appendChild(tabl);
    	document.getElementById("financeDetailOutFlowDiv").appendChild(finDiv);
		documentOnReady.Enable_Loader();
		$
				.ajax({
					type : 'GET',
					url : '/FinanceHoldStuckOrderOutflowflowDetails?startDate='
							+ startDate + '&endDate=' + endDate,
					dataType : 'json',
					success : function(dataSet) {
					//	alert("fecthRiskHoldOutFlowOrders - SUCCESS");
						//   alert("SUCCESS");
						//console.log(dataSet);
						document.getElementById("financeHoldOrderOutflowCount").innerHTML = dataSet.length;
						//if(isUpdateTable){
						console.log("financeHoldOrderOutflowCount updated");
						loadFinanceOutflowDetailTable(dataSet);//}
						
						console.log("loadFinanceOutflowDetailTable Binded");

						documentOnReady.Disable_Loader();
					},
					error : function(ex) {
						//alert("fecthRiskHoldOutFlowOrders - FAILED");
					//	alert("error");
					//	alert('Failed to retrieve Tower.' + ex);
						documentOnReady.Disable_Loader();
					}
				});

	};
    
    
	var fecthRiskHoldOrders=function() {
	/*	var statEffTms = document.getElementById("statusEffTime").value;
		var lastUpdTms = document.getElementById("lastUpdateTime").value;
*/
		
		  var date = $('#dateSelector').val();
    	   let startDate= date.split('-')[0];
    	   let endDate= date.split('-')[1]; 
		/*   alert(statEffTms);
		  alert(lastUpdTms);
		 */
    	   console.log ("SENDING REQ to fecthRiskHoldOrders");
	//	alert(date);
		documentOnReady.Enable_Loader();
		$
				.ajax({
					type : 'GET',
					url : '/FinanceHoldStuckOrderDetails?startDate='
							+ startDate + '&endDate=' + endDate,
					dataType : 'json',
					success : function(dataSet) {
					//	   alert("FinanceHoldStuckOrderDetails SUCCESS");
						//console.log(dataSet);
						document.getElementById("financeHoldCount").innerHTML = dataSet.length;
						console.log("financeHoldCount Updated");
//loadFinanceDetailTable(dataSet);
						loadFinanceDetailTable(dataSet);
						setOnclickFunctions();
						console.log("Finance hold binding updated");

						documentOnReady.Disable_Loader();
					},
					error : function(ex) {
						alert("error");
						alert('Failed to retrieve Tower.' + ex);
						documentOnReady.Disable_Loader();
					}
				});

	};
    return {
        load: function () {
            pageLoad();
            eventsInitilization();
            fetchRowExpandData();
            
            //fecthRiskHoldOrders();
            //fetchFinanceOrderInflowDetail();
          //fecthRiskHoldOutFlowOrders(false);
        }
    }
    
    
    
})();

$(document).ready(function () {
    financeHelperClass.load();
});