package com.qvc.orderflowdashboard.vo;

import java.math.BigDecimal;

public class FinanceHoldChartData {
	private String ordFlowSumDsc;
	private BigDecimal statusId;

	private BigDecimal totalOrders;

	public String getOrdFlowSumDsc() {
		return ordFlowSumDsc;
	}

	public void setOrdFlowSumDsc(String ordFlowSumDsc) {
		this.ordFlowSumDsc = ordFlowSumDsc;
	}

	public BigDecimal getStatusId() {
		return statusId;
	}

	public void setStatusId(BigDecimal statusId) {
		this.statusId = statusId;
	}

	public BigDecimal getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(BigDecimal totalOrders) {
		this.totalOrders = totalOrders;
	}

	@Override
	public String toString() {
		return "\nFinanceHoldChartData [ordFlowSumDsc=" + ordFlowSumDsc + ", statusId=" + statusId + ", totalOrders="
				+ totalOrders + "]";
	}
	
	
	
	
}
