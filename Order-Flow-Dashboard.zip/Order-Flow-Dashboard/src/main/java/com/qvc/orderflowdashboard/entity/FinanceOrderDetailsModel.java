package com.qvc.orderflowdashboard.entity;

import java.util.Date;

public class FinanceOrderDetailsModel {
	
	private String orderNumber;
	private Integer orderLineNumber;
	private Date aolLastUpdatedDate;
	private Date olLastUpdatedDate;
	
	private Date statusEffTimestamp;
	
	private String activeOrdLnStatus;
	private String ordmlineStatus;

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}

	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}

	
	

	public Date getStatusEffTimestamp() {
		return statusEffTimestamp;
	}

	public void setStatusEffTimestamp(Date statusEffTimestamp) {
		this.statusEffTimestamp = statusEffTimestamp;
	}

	public String getActiveOrdLnStatus() {
		return activeOrdLnStatus;
	}

	public void setActiveOrdLnStatus(String activeOrdLnStatus) {
		this.activeOrdLnStatus = activeOrdLnStatus;
	}

	public Date getAolLastUpdatedDate() {
		return aolLastUpdatedDate;
	}

	public void setAolLastUpdatedDate(Date aolLastUpdatedDate) {
		this.aolLastUpdatedDate = aolLastUpdatedDate;
	}

	public Date getOlLastUpdatedDate() {
		return olLastUpdatedDate;
	}

	public void setOlLastUpdatedDate(Date olLastUpdatedDate) {
		this.olLastUpdatedDate = olLastUpdatedDate;
	}

	public String getOrdmlineStatus() {
		return ordmlineStatus;
	}

	public void setOrdmlineStatus(String ordmlineStatus) {
		this.ordmlineStatus = ordmlineStatus;
	}

	@Override
	public String toString() {
		return "\nFinanceOrderDetailsModel [orderNumber=" + orderNumber + ", orderLineNumber=" + orderLineNumber
				+ ", aolLastUpdatedDate=" + aolLastUpdatedDate + ", olLastUpdatedDate=" + olLastUpdatedDate
				+ ", statusEffTimestamp=" + statusEffTimestamp + ", activeOrdLnStatus=" + activeOrdLnStatus
				+ ", ordmlineStatus=" + ordmlineStatus + "]";
	}

	
	
		
}
