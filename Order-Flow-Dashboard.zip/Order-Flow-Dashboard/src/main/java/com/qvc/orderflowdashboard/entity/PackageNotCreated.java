package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;
import java.util.Date;

public class PackageNotCreated {

	
	private String ordNbr;
	private BigDecimal ordLnNbr;
	private BigDecimal ordFlowStatId;
	private Integer orderlineQty;
	private Date ordDt;
    private String acctNbr;
	
	
	
	
	
	public PackageNotCreated() {
		super();
	}





	public String getOrdNbr() {
		return ordNbr;
	}





	public void setOrdNbr(String ordNbr) {
		this.ordNbr = ordNbr;
	}





	public BigDecimal getOrdLnNbr() {
		return ordLnNbr;
	}





	public void setOrdLnNbr(BigDecimal ordLnNbr) {
		this.ordLnNbr = ordLnNbr;
	}





	public BigDecimal getOrdFlowStatId() {
		return ordFlowStatId;
	}





	public void setOrdFlowStatId(BigDecimal ordFlowStatId) {
		this.ordFlowStatId = ordFlowStatId;
	}





	public Integer getOrderlineQty() {
		return orderlineQty;
	}





	public void setOrderlineQty(Integer oRDERLINE_QTY) {
		orderlineQty = oRDERLINE_QTY;
	}





	public Date getOrdDt() {
		return ordDt;
	}





	public void setOrdDt(Date ordDt) {
		this.ordDt = ordDt;
	}





	public String getAcctNbr() {
		return acctNbr;
	}





	public void setAcctNbr(String aCCT_NBR) {
		acctNbr = aCCT_NBR;
	}





	@Override
	public String toString() {
		return "\nPackageNotCreated [ordNbr=" + ordNbr + ", ordLnNbr=" + ordLnNbr + ", ordFlowStatId=" + ordFlowStatId
				+ ", ORDERLINE_QTY=" + orderlineQty + ", ordDt=" + ordDt + ", ACCT_NBR=" + acctNbr + "]";
	}
	
	
}
