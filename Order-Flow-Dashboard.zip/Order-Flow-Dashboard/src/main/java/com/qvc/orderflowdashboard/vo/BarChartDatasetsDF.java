package com.qvc.orderflowdashboard.vo;

import java.util.ArrayList;
import java.util.List;

public class BarChartDatasetsDF
    {
        private String label;
        private String backgroundColor;
        private String borderColor;
        private String borderWidth="2";
        private List<String> data =new ArrayList<String>();
		public BarChartDatasetsDF(String label, String backgroundColor, String borderColor,
				String borderWidth, List<String> data) {
			super();
			this.label = label;
			this.backgroundColor = backgroundColor;
			this.borderColor = borderColor;
			this.borderWidth = borderWidth;
			this.data = data;
		}
		public BarChartDatasetsDF() {
			super();
			data=new  ArrayList<>();
		}
		public String getLabel() {
			return label;
		}
		public void setLabel(String label) {
			this.label = label;
		}
		public String getBackgroundColor() {
			return backgroundColor;
		}
		public void setBackgroundColor(String backgroundColor) {
			this.backgroundColor = backgroundColor;
		}
		public String getBorderColor() {
			return borderColor;
		}
		public void setBorderColor(String borderColor) {
			this.borderColor = borderColor;
		}
		public String getBorderWidth() {
			return borderWidth;
		}
		public void setBorderWidth(String borderWidth) {
			this.borderWidth = borderWidth;
		}
		public List<String> getData() {
			return data;
		}
		public void setData(List<String> data) {
			this.data = data;
		}
		@Override
		public String toString() {
			return "BarChart_Datasets [label=" + label + ", backgroundColor=" + backgroundColor + ", borderColor="
					+ borderColor + ", borderWidth=" + borderWidth + ", data=" + data + "]";
		}
		
        
        
		
    }