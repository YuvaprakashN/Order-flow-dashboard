package com.qvc.orderflowdashboard.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.qvc.orderflowdashboard.dao.DMDAOImpl;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.qvc.orderflowdashboard.dao.FinanceDAOImpl;
import com.qvc.orderflowdashboard.model.OrderFlowModel;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.vo.PieChart;
import com.qvc.orderflowdashboard.vo.PieChartDatasets;

@Service
public class FinanceService {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(FinanceService.class);
	private final FinanceDAOImpl finanaceDaoImpl;


	private  final DMDAOImpl dmdao;

	
	
	public FinanceService(FinanceDAOImpl finanaceDaoImpl,DMDAOImpl dmdao) {
		super();
		this.finanaceDaoImpl = finanaceDaoImpl;
		this.dmdao=dmdao;
	}

	public List<OrderFlowModel> getFinanceITExceptions(Date startDate, Date endDate) {
		log.info("Finance IT Exception Service:");
		List<OrderFlowExceptions> financeITExceptionsList = finanaceDaoImpl.getITExceptions(startDate, endDate);		
			
		return constructExceptionsMap(financeITExceptionsList);
		}
		
	public List<OrderFlowModel> getFinanceBusinessExceptions(Date startDate, Date endDate) {
		log.info("Finance Business Exception Service:");
		List<OrderFlowExceptions> financeBusinessExceptionsList = finanaceDaoImpl.getBusinessExceptions(startDate, endDate);
		return constructExceptionsMap(financeBusinessExceptionsList);
		}
		
	
	private List<OrderFlowModel> constructExceptionsMap(List exceptionsList) {
		List<OrderFlowModel>  orderFlowModelList = new ArrayList();
		List<OrderFlowExceptions>  orderFlowModelLvl2List = null;
		OrderFlowModel orderFlowModelTemp = null;

		OrderFlowModel model = null;

		Iterator businessExpIter = exceptionsList.iterator();		
		while(businessExpIter.hasNext()) {
			OrderFlowExceptions orderFlowException = (OrderFlowExceptions)businessExpIter.next();
			
			String key = orderFlowException.getBusn_acty_typ_dsc() != null? orderFlowException.getBusn_acty_typ_dsc().trim(): null;
			if(orderFlowModelList.size()> 0) {
			 orderFlowModelTemp = orderFlowModelList.stream()
					  .filter(orderFlowModel -> key.equals(orderFlowModel.getCategoryLvl1Name()))
					  .findAny()
					  .orElse(null);
			}
			
			if(orderFlowModelTemp != null) {
				int index = orderFlowModelList.indexOf(orderFlowModelTemp);
				model=orderFlowModelList.get(index);		
						
						
						
				List tempLvl2ExpList = (ArrayList)orderFlowModelTemp.getCategoryLvl2List();
				tempLvl2ExpList.add(orderFlowException);
				orderFlowModelTemp.setCategoryLvl2List(tempLvl2ExpList);
				orderFlowModelTemp.setCategoryLvl1Cnt(model.getCategoryLvl1Cnt()+orderFlowException.getTotOrderLineCnt());
				orderFlowModelList.remove(index);
				orderFlowModelList.add(index, orderFlowModelTemp);
			}else {				
					
				    model = new OrderFlowModel();
				    orderFlowModelLvl2List = new ArrayList();
				    orderFlowModelLvl2List.add(orderFlowException);				    
				    model.setCategoryLvl2List(orderFlowModelLvl2List);
					model.setCategoryLvl1Cnt(orderFlowException.getTotOrderLineCnt());
					model.setCategoryLvl1Name(key);
					model.setCategoryLvl1Desc(orderFlowException.getOrd_flow_stat_dsc());
					orderFlowModelList.add(model);

			}

			
	
		}	
		
		return orderFlowModelList;
	}
	

	public Date convertJSDateToDate(String date) throws ParseException {
		DateFormat formatter =new SimpleDateFormat("yyyy/MM/dd hh:mm a");// new SimpleDateFormat("dd-mm-yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		if (date==null) {
			cal.add(Calendar.DATE, -365);
			return cal.getTime();

		}

		return formatter.parse(date);
	}

	
	public List<OrderDetailsModel> getorderDetailsJSON(int status,Date startDate, Date endDate) {
		log.info("Get Order Details JSON :");
		if(status==2470000)
			return dmdao.getpackageNotCreatedOrderDetails(startDate, endDate);
		List<OrderDetailsModel> orderDetails = finanaceDaoImpl.getorderDetailsJSON(status,startDate, endDate);
		return orderDetails;
		}
	
	public OrderFlowStatVWModel getOrderFlowStatusVW(String status) {
		log.info("Get Order Flow Status VW:");
		OrderFlowStatVWModel orderFlowStatVWModel = finanaceDaoImpl.getOrderFlowStatusVW(status);
		return orderFlowStatVWModel;
		}
	
	
	
	
	public PieChart financeHoldPieChartData() throws ParseException {

				List<String> lables = new ArrayList<>();

				List<String> data = new ArrayList<>();
				List<String> backgroundColor = new ArrayList<>();

				/*lables.add("Fraud Outbound");
				data.add(String.valueOf(finanaceDaoImpl.getFinancePieChartOutFlow()));
				backgroundColor.add("#32a852");*/

				lables.add("Fraud Inbound");
				data.add(String.valueOf(finanaceDaoImpl.getFinancePieChartInflowCount()));
				backgroundColor.add("#3360e8");

				lables.add("Fraud Released ");
				data.add(String.valueOf(finanaceDaoImpl.getFinancePieChartReleaseCount()));
				backgroundColor.add("#ffc107");

				DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm a");// new SimpleDateFormat("dd-mm-yyyy HH:mm");
				Calendar cal = Calendar.getInstance();
				cal.setTime(new Date());
				Date endDate=cal.getTime();
				cal.add(Calendar.DATE, -30);
				Date startDate=cal.getTime();
				
				lables.add("Fraud Hold");
				data.add(String.valueOf(finanaceDaoImpl.financeHoldOrderCount(startDate,endDate)));
				backgroundColor.add("#dc3545");

				


				PieChartDatasets pieChart_Datasets = new PieChartDatasets();
				pieChart_Datasets.setBackgroundColor(backgroundColor);
				pieChart_Datasets.setData(data);

				List<PieChartDatasets> dataSets = new ArrayList<>();
				dataSets.add(pieChart_Datasets);
				PieChart pieChart = new PieChart(lables, dataSets);

				return pieChart;
			}
}
