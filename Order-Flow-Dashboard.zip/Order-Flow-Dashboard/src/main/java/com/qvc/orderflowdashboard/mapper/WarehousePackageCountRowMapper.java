package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.WarehousePackageCountModel;

public class WarehousePackageCountRowMapper implements RowMapper<WarehousePackageCountModel>{

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(WarehousePackageCountRowMapper.class);
	@Override
	public WarehousePackageCountModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		WarehousePackageCountModel warehousePackageCountModel=new WarehousePackageCountModel();
		try {
			warehousePackageCountModel.setWarehouseName(rs.getString("Warehouse"));
			warehousePackageCountModel.setColorFlag(rs.getString("arrowColor"));
			warehousePackageCountModel.setCount(rs.getBigDecimal("count"));
			
			
		} catch (Exception e) {
			log.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return warehousePackageCountModel;
	}

}
