package com.qvc.orderflowdashboard.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.qvc.orderflowdashboard.dao.DMDAOImpl;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.model.OrderFlowModel;
import com.qvc.orderflowdashboard.vo.BarChartDF;
import com.qvc.orderflowdashboard.vo.BarChartDatasetsDF;

@Service
public class DMService {
	
	private final DMDAOImpl demandMaangementDaoImpl;

	private final DashboardService dashboardService;
	
	public DMService(DMDAOImpl demandMaangementDaoImpl, DashboardService dashboardService) {
		super();
		this.demandMaangementDaoImpl = demandMaangementDaoImpl;
		this.dashboardService = dashboardService;
	}


	public List<OrderFlowModel> getDMITExceptions(Date startDate, Date endDate) {
		System.out.println("DM IT Exception Service:");
		List<OrderFlowExceptions> financeITExceptionsList = demandMaangementDaoImpl.getITExceptions(startDate,endDate);		
			OrderFlowExceptions packageNotCreated = demandMaangementDaoImpl.getpackageNotCreated(startDate,endDate);
			if(packageNotCreated!=null) {
				if(packageNotCreated.getTotOrderLineCnt()>0)
				financeITExceptionsList.add(packageNotCreated);
			}
		List<OrderFlowModel> constructExceptionsMap = constructExceptionsMap(financeITExceptionsList);
		System.out.println("a========================================================DM IT Exception: "+ constructExceptionsMap);
		return constructExceptionsMap;
		}
		
		
	public List<OrderFlowModel> getDMBusinessExceptions(Date startDate, Date endDate) {
		System.out.println("DM Business Exception Service:");
		List<OrderFlowExceptions> financeBusinessExceptionsList = demandMaangementDaoImpl.getBusinessExceptions(startDate,endDate);
		return constructExceptionsMap(financeBusinessExceptionsList);
		}
		
	
	private List<OrderFlowModel> constructExceptionsMap(List exceptionsList) {
		List<OrderFlowModel>  orderFlowModelList = new ArrayList();
		List<OrderFlowExceptions>  orderFlowModelLvl2List = null;

		OrderFlowModel model = null;
		if(exceptionsList == null)
			return null;
		System.out.println("EXCEPTION LIST: "+exceptionsList);
		Iterator businessExpIter = exceptionsList.iterator();		
		while(businessExpIter.hasNext()) {
			OrderFlowExceptions orderFlowException = (OrderFlowExceptions)businessExpIter.next();
			System.out.println("ORDER FLOW EXCEPTION: "+orderFlowException);
			if(orderFlowException !=null) {
			String key = orderFlowException.getBusn_acty_typ_dsc().trim();
			
			OrderFlowModel orderFlowModelTemp = orderFlowModelList.stream()
					  .filter(orderFlowModel -> key.equals(orderFlowModel.getCategoryLvl1Name()))
					  .findAny()
					  .orElse(null);
			
			if(orderFlowModelTemp != null) {
				int index = orderFlowModelList.indexOf(orderFlowModelTemp);
				model=orderFlowModelList.get(index);
				List tempLvl2ExpList = (ArrayList)orderFlowModelTemp.getCategoryLvl2List();
				tempLvl2ExpList.add(orderFlowException);
				orderFlowModelTemp.setCategoryLvl2List(tempLvl2ExpList);
				orderFlowModelTemp.setCategoryLvl1Cnt(model.getCategoryLvl1Cnt()+orderFlowException.getTotOrderLineCnt());
				orderFlowModelList.remove(index);
				orderFlowModelList.add(index, orderFlowModelTemp);
			}else {				
					
				    model = new OrderFlowModel();
				    orderFlowModelLvl2List = new ArrayList();
				    orderFlowModelLvl2List.add(orderFlowException);				    
				    model.setCategoryLvl2List(orderFlowModelLvl2List);
					model.setCategoryLvl1Cnt(orderFlowException.getTotOrderLineCnt());
					model.setCategoryLvl1Name(key);	
					model.setCategoryLvl1Desc(orderFlowException.getOrd_flow_stat_dsc());

					orderFlowModelList.add(model);

			}
			}
			
	}
		
		return orderFlowModelList;
	}
	


	
	
	public BarChartDF demandManagementExceptionBarChartData() {
		
		Date end=new Date();
		Date start=null;
		Calendar cal = Calendar.getInstance();
		 cal.setTime(new Date());
		 
		cal.add(Calendar.DATE, -90);
			start= cal.getTime();

		
		List<OrderFlowModel> dmitExceptions = getDMITExceptions(start, end);
	
		
		
		
		
		BarChartDF barChart = new BarChartDF();

		List<String> labels = new ArrayList<>();

		List<BarChartDatasetsDF> datasets = new ArrayList<>();

		List<String> bgColor = new ArrayList<>();
		List<String> borderColor = new ArrayList<>();
		List<String> data = new ArrayList<>();
		dmitExceptions.forEach(e -> {
			BarChartDatasetsDF dataSet = new BarChartDatasetsDF();
			OrderFlowExceptions ofm=((ArrayList<OrderFlowExceptions>)e.getCategoryLvl2List()).get(0);
			dataSet.setLabel(e.getCategoryLvl1Name());
			dataSet.setBorderColor("#000");
			dataSet.setBackgroundColor(dashboardService.getBGColor(String.valueOf(ofm.getOrderFlowStatId())));
			labels.add(e.getCategoryLvl1Name());
			bgColor.add(dashboardService.getBGColor(String.valueOf(ofm.getOrderFlowStatId())));
			borderColor.add("#000");
			dataSet.getData().add(String.valueOf(e.getCategoryLvl1Cnt()));
			datasets.add(dataSet);
		});

		barChart.setLabels(labels);
		barChart.setDatasets(datasets);
		return barChart;
	}
}
