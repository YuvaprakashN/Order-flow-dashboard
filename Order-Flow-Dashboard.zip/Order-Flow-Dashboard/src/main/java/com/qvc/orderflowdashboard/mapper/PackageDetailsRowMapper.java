package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.PackageDetailsModel;

public class PackageDetailsRowMapper implements RowMapper<PackageDetailsModel>{

	@Override
	public PackageDetailsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		PackageDetailsModel model=new  PackageDetailsModel();
		try {
			
			model.setBoxNumber(rs.getInt("BOX_NBR"));
			model.setInvoiceNumber(rs.getInt("INVC_NBR"));
			model.setPackageId(rs.getInt("pkg_id"));
			model.setPackageLastUpdatedDate(rs.getTimestamp("package_last_UPD_TMS"));
			
			model.setItemNumber(rs.getString("ITEM_NBR"));
			model.setOrderLastUpdatedDate(rs.getTimestamp("order_last_UPD_TMS"));
			model.setOrderDate(rs.getDate("ORD_DT"));
			model.setOrderLineNumber(rs.getInt("ORD_LN_NBR"));
			model.setOrderNumber(rs.getString("ORD_NBR"));;
 

			model.setWhseName(rs.getString("LEGACY_WHSE_NBR"));
			model.setWhseNbr(rs.getString("DC_DSC"));
			
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}
		
		
		
		return model;
	}

}
