package com.qvc.orderflowdashboard.vo;

import java.util.List;

public class PieChartDatasets
    {
        private List<String> data;
        private List<String> backgroundColor;
		public PieChartDatasets() {
			super();
		}
		public List<String> getData() {
			return data;
		}
		public void setData(List<String> data) {
			this.data = data;
		}
		public List<String> getBackgroundColor() {
			return backgroundColor;
		}
		public void setBackgroundColor(List<String> backgroundColor) {
			this.backgroundColor = backgroundColor;
		}
		@Override
		public String toString() {
			return "PieChart_Datasets [data=" + data + ", backgroundColor=" + backgroundColor + "]";
		}
		
        
        
    }