package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;

public class CellDataPoint {

	private String colorCode;
	private BigDecimal value;
	
	
	public CellDataPoint() {
		super();
	}
	
	
	
	
	public CellDataPoint(BigDecimal value) {
		super();
		this.value = value;
	}




	@Override
	public String toString() {
		return "cellDataPoint [colorCode=" + colorCode + ", value=" + value + "]";
	}




	public String getColorCode() {
		return colorCode;
	}
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	public BigDecimal getValue() {
		return value;
	}
	public void setValue(BigDecimal value) {
		this.value = value;
	}
	
	
	
	
}
