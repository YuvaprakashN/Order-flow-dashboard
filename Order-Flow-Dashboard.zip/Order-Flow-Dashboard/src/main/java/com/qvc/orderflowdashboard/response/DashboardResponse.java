package com.qvc.orderflowdashboard.response;

public class DashboardResponse {
	
	private FinanceHoldData financeHold;
	private DemandManagementData demandManagement;
	private DemandFulfilmentData demandFulfilment;
	public FinanceHoldData getFinanceHold() {
		return financeHold;
	}
	public void setFinanceHold(FinanceHoldData financeHold) {
		this.financeHold = financeHold;
	}
	public DemandManagementData getDemandManagement() {
		return demandManagement;
	}
	public void setDemandManagement(DemandManagementData demandManagement) {
		this.demandManagement = demandManagement;
	}
	public DemandFulfilmentData getDemandFulfilment() {
		return demandFulfilment;
	}
	public void setDemandFulfilment(DemandFulfilmentData demandFulfilment) {
		this.demandFulfilment = demandFulfilment;
	}
	@Override
	public String toString() {
		return "DashboardResponse [financeHold=" + financeHold + ", demandManagement=" + demandManagement
				+ ", demandFulfilment=" + demandFulfilment + "]";
	}
	
	
	
	
	

}



