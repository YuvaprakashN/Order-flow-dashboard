package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderDetailsModel;

public class OrderDetailsModelRowMapper implements RowMapper<OrderDetailsModel> {
	public static final String LAST_UPD_TMS = "LAST_UPD_TMS";
	public OrderDetailsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderDetailsModel orderDetailsModel = new OrderDetailsModel();

			orderDetailsModel.setOrderNumber(rs.getString("ORD_NBR"));
			orderDetailsModel.setOrderLineNumber(rs.getInt("ORD_LN_NBR"));
			orderDetailsModel.setOrderaccountNumber(rs.getString("ACCT_NBR"));
			orderDetailsModel.setItemNumber(rs.getString("ITEM_NBR"));
			orderDetailsModel.setOrderDate(rs.getDate("ORD_DT"));
			orderDetailsModel.setLastUpdatedDate(rs.getTimestamp(LAST_UPD_TMS));
			
			orderDetailsModel.setStatusEffTimestamp(rs.getTimestamp(LAST_UPD_TMS));
			orderDetailsModel.setEstDeliveryDate(rs.getTimestamp(LAST_UPD_TMS));
			orderDetailsModel.setShipByDate(rs.getTimestamp(LAST_UPD_TMS));

		return orderDetailsModel;
	}

}
