package com.qvc.orderflowdashboard.vo;

import java.util.ArrayList;
import java.util.List;

public class BarChartDF {
	private List<String> labels;
	private List<BarChartDatasetsDF> datasets;

	public BarChartDF(List<String> labels, List<BarChartDatasetsDF> datasets) {
		super();
		this.labels = labels;
		this.datasets = datasets;
	}

	public BarChartDF() {
		super();
		this.datasets = new ArrayList<BarChartDatasetsDF>();
	}

	public List<String> getLabels() {
		return labels;
	}

	public void setLabels(List<String> labels) {
		this.labels = labels;
	}

	public List<BarChartDatasetsDF> getDatasets() {
		return datasets;
	}

	public void setDatasets(List<BarChartDatasetsDF> datasets) {
		this.datasets = datasets;
	}

	@Override
	public String toString() {
		return "\nBarChart [labels=" + labels + ", datasets=" + datasets + "]";
	}

}