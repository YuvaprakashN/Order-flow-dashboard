package com.qvc.orderflowdashboard.entity;

import java.util.Date;

public class PackageDetailModel {
	
	public Integer packageId;
	public Integer invoiceNumber;
	public Integer boxNumber;
	public Integer packageStatus;
	private Date packageLastUpdatedDate;
	
	
	
	public PackageDetailModel() {
		super();
	}



	public Integer getPackageId() {
		return packageId;
	}


	public void setPackageId(Integer packageId) {
		this.packageId = packageId;
	}


	public Integer getInvoiceNumber() {
		return invoiceNumber;
	}


	public void setInvoiceNumber(Integer invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}


	public Integer getBoxNumber() {
		return boxNumber;
	}


	public void setBoxNumber(Integer boxNumber) {
		this.boxNumber = boxNumber;
	}


	public Integer getPackageStatus() {
		return packageStatus;
	}


	public void setPackageStatus(Integer packageStatus) {
		this.packageStatus = packageStatus;
	}


	public Date getPackageLastUpdatedDate() {
		return packageLastUpdatedDate;
	}


	public void setPackageLastUpdatedDate(Date packageLastUpdatedDate) {
		this.packageLastUpdatedDate = packageLastUpdatedDate;
	}


	@Override
	public String toString() {
		return "\nPackageDetailsModel [packageId=" + packageId + ", invoiceNumber=" + invoiceNumber + ", boxNumber="
				+ boxNumber + ", packageStatus=" + packageStatus + ", packageLastUpdatedDate=" + packageLastUpdatedDate
				+ "]";
	}



}
