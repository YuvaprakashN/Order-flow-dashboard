package com.qvc.orderflowdashboard.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.qvc.orderflowdashboard.service.DFService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qvc.orderflowdashboard.entity.DashboardHomeResponse;
import com.qvc.orderflowdashboard.entity.FinanceOrderStatusModel;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.entity.OrderStatusModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;
import com.qvc.orderflowdashboard.entity.PackageStatusModel;
import com.qvc.orderflowdashboard.service.DMService;
import com.qvc.orderflowdashboard.service.DashboardService;
import com.qvc.orderflowdashboard.service.FinanceService;
import com.qvc.orderflowdashboard.vo.BarChartDF;
import com.qvc.orderflowdashboard.vo.PieChart;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
public class DashboardRESTController {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(DashboardRESTController.class);
	private static final String SHARED_MASTERPAGE = "shared/Masterpage";
	private static final int NUMBER_OF_CYCLES = 6;


	private final DashboardService dashboardService;
	
	private final FinanceService financeService;
	
	private final	DMService dMService;
	private final DFService dFService;
	
	
	public DashboardRESTController(DashboardService dashboardService,FinanceService financeService,DMService dMService,DFService dFService) {
		this.dashboardService = dashboardService;
		this.dMService = dMService;
		this.financeService=financeService;
		this.dFService=dFService;
	}
	

	@Value("${dashboard.page.name}")
	private String dashboardPage;

	@Value("${finance.page.name}")
	private String financePage;

	@Value("${demandManagement.page.name}")
	private String demandManagementPage;
	
	@Value("${demandFulfillment.orderdetails.page.name2}")
	private String demandFulfillmentOrderFlowDetailsPage;

	@Value("${demandFulfillment.page.name}")
	private String demandFulfillmentPage;
	
	@Value("${orderFlow.page.name}")
	private String orderFlowPage;
	
	@Value("${demandManagement.orderdetails.page.name}")
	private String demandManagementOrderDetailsPage;
	@Value("${demandFulfillment.orderdetails.page.name}")
	private String demandFulfillmentOrderDetailsPage;


	
	@GetMapping(path = { "/dashboard", "/" })
	public String getdashboardResponse(Model model) {
		model.addAttribute("page", dashboardPage);
		// Include yuva code
		return SHARED_MASTERPAGE;
	}

	@GetMapping(path = { "/dashboard/dashboard_charts", "chart" })
	@ResponseBody
	public DashboardHomeResponse dasboardCharts() throws ParseException {
		BarChartDF demandFulfilmentBarChartData = dashboardService.demandFulfilmentBarChartData();
		PieChart financeHoldPieChartData = financeService.financeHoldPieChartData();
		BarChartDF demandManagementExceptionBarChartData = dMService.demandManagementExceptionBarChartData();
		DashboardHomeResponse dashboardHomeResponse = new DashboardHomeResponse();

		dashboardHomeResponse.setFinanceHoldPieChartData(financeHoldPieChartData);
		dashboardHomeResponse.setDemandManagementExceptionBarChartData(demandManagementExceptionBarChartData);
		dashboardHomeResponse.setDemandFulfilmentBarChartData(demandFulfilmentBarChartData);
		return dashboardHomeResponse;
	}
	
	

	@GetMapping("/orderflow/{service}")
	public String getOrderResponse(@PathVariable String service, Model model,
			@RequestParam(required = false) String statusEffTime, @RequestParam(required = false) String lastUpdateTime)
			throws ParseException, JsonProcessingException {

		List<OrderStatusModel> orderStatusModels = null;
		List<FinanceOrderStatusModel> financeOrderStatusModel = null;
		List<PackageStatusModel> demandFulfilmentInHours = null;

		if (service.equals("finance")) {

			
		
			model.addAttribute("page", financePage);
		}
		if (service.equals("demandManagement")) {
		
			model.addAttribute("page", demandManagementPage);

		
			
		}
		if (service.equals("demandFulfillment")) {

			model.addAttribute("page", demandFulfillmentPage);

		}
		
	if (service.equals("orderFlow")) {

			Date fromDate=dFService.getDefaultOrderFlowStartDate();
			Date endDate=new Date();
		DateFormat formatter =new SimpleDateFormat("yyyy/MM/dd hh:mm a");
		demandFulfilmentInHours = dashboardService.demandFulfilmentInHours(fromDate,endDate);
		//model.addAttribute("fromDate", formatter.format( fromDate));
		//model.addAttribute("endDate", formatter.format( endDate));
		model.addAttribute("orderStatusModels", demandFulfilmentInHours);
		model.addAttribute("page", orderFlowPage);

		}
		
		return SHARED_MASTERPAGE;
	}


	@GetMapping("/orderFlow/filter")
	public String getOrderFlowWithTimeFrame(@RequestParam String fromDate, @RequestParam String toDate, ModelMap model) throws ParseException {
		Date startDate=dashboardService.convertJSDateToDate(fromDate);
		Date endDate=dashboardService.convertJSDateToDate(toDate);

		List<PackageStatusModel>  demandFulfilmentInHours = dashboardService.demandFulfilmentInHours(startDate,endDate);
		model.addAttribute("orderStatusModels", demandFulfilmentInHours);
		model.addAttribute("page", orderFlowPage);
		model.addAttribute("fromDate",  fromDate);
		model.addAttribute("endDate",  toDate);

		return SHARED_MASTERPAGE;
	}
	
	
	@GetMapping("/packageDFDetailsJSON/{dc}/{status}/{field}/{value}")
	@ResponseBody
	public List<PackageDetailsModel> packageDetailsJSON(@PathVariable String status, @PathVariable String field, @PathVariable String dc,
			@PathVariable String value,@RequestParam(required = false) String fromDate,
														@RequestParam(required = false) String toDate) throws ParseException {
		log.info("PACKAGE DT JSON");
		List<PackageDetailsModel> packageDetails=null;
		if((!fromDate.isBlank()) && (!toDate.isBlank())){
		Date startDate=dashboardService.convertJSDateToDate(fromDate);
		Date endDate=dashboardService.convertJSDateToDate(toDate);
			packageDetails=dashboardService.packageDetails(status, dc, startDate,endDate);
		}
		else {
			 packageDetails = dashboardService.packageDetails(status, dc, field, value);
		}
		return packageDetails;
	}
	
	@GetMapping("/packageDetails/{dc}/{status}/{field}/{value}")
	public String packageDetails(@PathVariable String status, @PathVariable String field, @PathVariable String dc,
			@PathVariable String value, Model model,@RequestParam(required = false) String fromDate,
								 @RequestParam(required = false) String endDate) {

	/*	if(fromDate==null && endDate==null){
			DateFormat formatter =new SimpleDateFormat("yyyy/MM/dd hh:mm a");
			 fromDate=formatter.format(dFService.getDefaultOrderFlowStartDate());
			 endDate=formatter.format(new Date());

		}*/

		OrderFlowStatVWModel orderFlowStatusVW = financeService.getOrderFlowStatusVW(status);
		log.info("orderFlowStatusVW: "+ orderFlowStatusVW);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("page", demandFulfillmentOrderFlowDetailsPage);
		model.addAttribute("warehouse", dc);
		model.addAttribute("statusId", status);
		model.addAttribute("hour", value);
		model.addAttribute("field", field);
		model.addAttribute("orderFlowStatusVW", orderFlowStatusVW);
		return SHARED_MASTERPAGE;

	}
	
	@GetMapping("/orderDetailsJSON/{status}/{field}/{value}")
	@ResponseBody
	public List<OrderDetailsModel> getorderDetailsJSON(@PathVariable String status, @PathVariable String field, @PathVariable String value,
			@RequestParam(required = false) boolean isInvHold, Model model) {
		log.info("ORDER DT JSON");
		List<OrderDetailsModel> orderDetails = dashboardService.orderDetails(status, field, value, false);
		log.info("ORDER DT JSON ::: " , orderDetails);
		return orderDetails;
		
	}
	
	@GetMapping("/financeOrderDetailsJSON/{field}/{value}")
	@ResponseBody
	public List<OrderDetailsModel> getorderDetailsJSON( @PathVariable String field, @PathVariable String value,
			@RequestParam(required = false) boolean isInvHold) {
		log.info("ORDER DT JSON");
		List<OrderDetailsModel> orderDetails = dashboardService.finaceReleaseOrderDetails(field, value);
		log.info("ORDER DT JSON :::" , orderDetails);
		return orderDetails;
		
	}

	@GetMapping("/orderDetails/{status}/{field}/{value}")
	public String getorderDetails(@PathVariable String status, @PathVariable String field, @PathVariable String value,
			@RequestParam(required = false) boolean isInvHold, Model model)  {

		model.addAttribute("page", demandManagementOrderDetailsPage);
		model.addAttribute("statusId", status);
		model.addAttribute("field", field);
		model.addAttribute("hour", value);
model.addAttribute("isInvHold", isInvHold);
		return SHARED_MASTERPAGE;

	}

	
	@GetMapping("/fetchRowExpandData")
	@ResponseBody
	public List fetchRowExpandData()  {
		List list = new ArrayList();
		Map dataMap = null;
		
		for(int i = 0;i<NUMBER_OF_CYCLES;i++) {
			dataMap = new HashMap();
			dataMap.put("firstName", "firstName"+i);
			dataMap.put("lastName", "lastName"+i);
			dataMap.put("email", "email"+i);
			list.add(dataMap);
			
		}
		
		return list;
		

	}

	
	
}
