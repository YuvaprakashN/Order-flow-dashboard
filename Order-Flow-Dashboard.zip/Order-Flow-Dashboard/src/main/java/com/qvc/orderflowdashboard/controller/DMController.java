package com.qvc.orderflowdashboard.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qvc.orderflowdashboard.model.OrderFlowModel;
import com.qvc.orderflowdashboard.service.DMService;
import com.qvc.orderflowdashboard.service.DashboardService;

//@RestController
@Controller
public class DMController {

	private final DashboardService dashboardService;
	private final DMService dMService;

	public DMController( DashboardService dashboardService, DMService dMService) {
		this.dashboardService = dashboardService;
		this.dMService = dMService;
	}

	@GetMapping("/loadDMBusinessExceptionsTable")
	@ResponseBody
	public List<OrderFlowModel> loadDMBusinessExceptionsTable(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		Date stsEffTm = dashboardService.convertJSDateToDate(startDate);
		Date updTimeStamp = dashboardService.convertJSDateToDate(endDate);

		return dMService.getDMBusinessExceptions(stsEffTm, updTimeStamp);
	}

	@GetMapping("/loadDMITExceptionsTable")
	@ResponseBody
	public List<OrderFlowModel> loadDMITExceptionsTable(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		Date stsEffTm = dashboardService.convertJSDateToDate(startDate);
		Date updTimeStamp = dashboardService.convertJSDateToDate(endDate);
		return dMService.getDMITExceptions(stsEffTm, updTimeStamp);
	}

}
