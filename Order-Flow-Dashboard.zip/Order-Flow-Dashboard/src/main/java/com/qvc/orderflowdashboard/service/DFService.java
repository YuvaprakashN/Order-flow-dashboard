package com.qvc.orderflowdashboard.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.qvc.orderflowdashboard.dao.OrderFlowDAO;
import com.qvc.orderflowdashboard.model.OrderFlowModel;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;

@Service
public class DFService {
	
	@Autowired
	@Qualifier("DFDAO")
	OrderFlowDAO demandFulfilmentDaoImpl;
	
	
	public List<PackageDetailsModel> getPackageDetails(String status,Date startDate, Date endDate) {
		System.out.println("DF Package details:");
		List<PackageDetailsModel> packageDetailsModels = demandFulfilmentDaoImpl.getPackageDetails(status, startDate, endDate);
		return packageDetailsModels;
		}
	
	
	public List<PackageDetailsModel> getDFBusinessExceptions(String status,Date startDate, Date endDate) {
		System.out.println("DM Business Exception Service:");
		List<PackageDetailsModel> financeBusinessExceptionsList = demandFulfilmentDaoImpl.getPackageDetails(status, startDate, endDate);
		return financeBusinessExceptionsList;
		}
		
	
	public List<OrderFlowModel> getDFITExceptions(Date startDate, Date endDate) {
		System.out.println("DM IT Exception Service:");
		List<OrderFlowExceptions> financeITExceptionsList = demandFulfilmentDaoImpl.getITExceptions(startDate,endDate);		
		return constructExceptionsMap(financeITExceptionsList);
		}
		
		
	public List<OrderFlowModel> getDFBusinessExceptions(Date startDate, Date endDate) {
		System.out.println("DM Business Exception Service:");
		List<OrderFlowExceptions> financeBusinessExceptionsList = demandFulfilmentDaoImpl.getBusinessExceptions(startDate,endDate);
		return constructExceptionsMap(financeBusinessExceptionsList);
		}
		
	
	private List<OrderFlowModel> constructExceptionsMap(List exceptionsList) {
		List<OrderFlowModel>  orderFlowModelList = new ArrayList();
		List<OrderFlowExceptions>  orderFlowModelLvl2List = null;

		OrderFlowModel model = null;
		if(exceptionsList == null)
			return null;
		Iterator businessExpIter = exceptionsList.iterator();		
		while(businessExpIter.hasNext()) {
			OrderFlowExceptions orderFlowException = (OrderFlowExceptions)businessExpIter.next();
			
			
			
			String key = orderFlowException.getBusn_acty_typ_dsc().trim();
			
			OrderFlowModel orderFlowModelTemp = orderFlowModelList.stream()
					  .filter(orderFlowModel -> key.equals(orderFlowModel.getCategoryLvl1Name()))
					  .findAny()
					  .orElse(null);
			
			if(orderFlowModelTemp != null) {
				int index = orderFlowModelList.indexOf(orderFlowModelTemp);
				model=orderFlowModelList.get(index);
				List tempLvl2ExpList = (ArrayList)orderFlowModelTemp.getCategoryLvl2List();
				tempLvl2ExpList.add(orderFlowException);
				orderFlowModelTemp.setCategoryLvl2List(tempLvl2ExpList);
				orderFlowModelTemp.setCategoryLvl1Cnt(model.getCategoryLvl1Cnt()+orderFlowException.getTotOrderLineCnt());
				orderFlowModelTemp.setCategoryLvl1PkgCnt(model.getCategoryLvl1PkgCnt()+orderFlowException.getTotPkgCnt());
				orderFlowModelList.remove(index);
				orderFlowModelList.add(index, orderFlowModelTemp);
			}else {				
					
				    model = new OrderFlowModel();
				    orderFlowModelLvl2List = new ArrayList();
				    orderFlowModelLvl2List.add(orderFlowException);				    
				    model.setCategoryLvl2List(orderFlowModelLvl2List);
					model.setCategoryLvl1Cnt(orderFlowException.getTotOrderLineCnt());
					model.setCategoryLvl1PkgCnt(orderFlowException.getTotPkgCnt());
					model.setCategoryLvl1Name(key);	
					model.setCategoryLvl1Desc(orderFlowException.getOrd_flow_stat_dsc());

					orderFlowModelList.add(model);

			}

			
	}
		
		return orderFlowModelList;
	}
	
public Date getDefaultOrderFlowStartDate(){
	Calendar cal=Calendar.getInstance();
	cal.setTime(new Date());
	cal.add(Calendar.DATE, -90);
	return cal.getTime();
}

	public OrderFlowDAO getFinanaceDaoImpl() {
		return demandFulfilmentDaoImpl;
	}

	public void setFinanaceDaoImpl(OrderFlowDAO finanaceDaoImpl) {
		this.demandFulfilmentDaoImpl = finanaceDaoImpl;
	}
}
