package com.qvc.orderflowdashboard.entity;

import com.qvc.orderflowdashboard.vo.BarChartDF;
import com.qvc.orderflowdashboard.vo.PieChart;

public class DashboardHomeResponse {

	private BarChartDF demandFulfilmentBarChartData;
	private PieChart financeHoldPieChartData ;
	private BarChartDF demandManagementExceptionBarChartData ;
	public DashboardHomeResponse() {
		super();
	}
	
	
	public DashboardHomeResponse(BarChartDF demandFulfilmentBarChartData, PieChart financeHoldPieChartData,
			BarChartDF demandManagementExceptionBarChartData) {
		super();
		this.demandFulfilmentBarChartData = demandFulfilmentBarChartData;
		this.financeHoldPieChartData = financeHoldPieChartData;
		this.demandManagementExceptionBarChartData = demandManagementExceptionBarChartData;
	}


	public BarChartDF getDemandFulfilmentBarChartData() {
		return demandFulfilmentBarChartData;
	}
	public void setDemandFulfilmentBarChartData(BarChartDF demandFulfilmentBarChartData) {
		this.demandFulfilmentBarChartData = demandFulfilmentBarChartData;
	}
	public PieChart getFinanceHoldPieChartData() {
		return financeHoldPieChartData;
	}
	public void setFinanceHoldPieChartData(PieChart financeHoldPieChartData) {
		this.financeHoldPieChartData = financeHoldPieChartData;
	}
	public BarChartDF getDemandManagementExceptionBarChartData() {
		return demandManagementExceptionBarChartData;
	}
	public void setDemandManagementExceptionBarChartData(BarChartDF demandManagementExceptionBarChartData) {
		this.demandManagementExceptionBarChartData = demandManagementExceptionBarChartData;
	}
	@Override
	public String toString() {
		return "DashboardHomeResponse [demandFulfilmentBarChartData=" + demandFulfilmentBarChartData
				+ ", financeHoldPieChartData=" + financeHoldPieChartData + ", demandManagementExceptionBarChartData="
				+ demandManagementExceptionBarChartData + "]";
	}
	
	
	
}
