package com.qvc.orderflowdashboard.entity;

import java.util.Date;

public class PackageDetailsModel {
	
	public Integer packageId;
	public Integer invoiceNumber;
	public Integer boxNumber;
	private Date packageLastUpdatedDate;
	private String whseNbr;
	private String whseName;
	
	
	private String orderNumber;
	private Integer orderLineNumber;
	private String itemNumber;
	private String accNumber;
	private Date orderDate;
	private Date orderLastUpdatedDate;
	
	
	public PackageDetailsModel() {
		super();
	}


	public Integer getPackageId() {
		return packageId;
	}


	public void setPackageId(Integer packageId) {
		this.packageId = packageId;
	}


	public Integer getInvoiceNumber() {
		return invoiceNumber;
	}


	public void setInvoiceNumber(Integer invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}


	public Integer getBoxNumber() {
		return boxNumber;
	}


	public void setBoxNumber(Integer boxNumber) {
		this.boxNumber = boxNumber;
	}


	public Date getPackageLastUpdatedDate() {
		return packageLastUpdatedDate;
	}


	public void setPackageLastUpdatedDate(Date packageLastUpdatedDate) {
		this.packageLastUpdatedDate = packageLastUpdatedDate;
	}


	public String getWhseNbr() {
		return whseNbr;
	}


	public void setWhseNbr(String whseNbr) {
		this.whseNbr = whseNbr;
	}


	public String getWhseName() {
		return whseName;
	}


	public void setWhseName(String whseName) {
		this.whseName = whseName;
	}


	public String getOrderNumber() {
		return orderNumber;
	}


	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}


	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}


	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}


	public String getItemNumber() {
		return itemNumber;
	}


	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}


	public String getAccNumber() {
		return accNumber;
	}


	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}


	public Date getOrderLastUpdatedDate() {
		return orderLastUpdatedDate;
	}


	public void setOrderLastUpdatedDate(Date orderLastUpdatedDate) {
		this.orderLastUpdatedDate = orderLastUpdatedDate;
	}


	@Override
	public String toString() {
		return "PackageDetailsModel [packageId=" + packageId + ", invoiceNumber=" + invoiceNumber + ", boxNumber="
				+ boxNumber + ", packageLastUpdatedDate=" + packageLastUpdatedDate + ", whseNbr=" + whseNbr
				+ ", whseName=" + whseName + ", orderNumber=" + orderNumber + ", orderLineNumber=" + orderLineNumber
				+ ", itemNumber=" + itemNumber + ", accNumber=" + accNumber + ", orderDate=" + orderDate
				+ ", orderLastUpdatedDate=" + orderLastUpdatedDate + "]";
	}


}
