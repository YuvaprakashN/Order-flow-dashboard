package com.qvc.orderflowdashboard.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ch.qos.logback.core.net.SyslogOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.qvc.orderflowdashboard.dao.DashboardDAO;
import com.qvc.orderflowdashboard.entity.FinanceOrderDetailsModel;
import com.qvc.orderflowdashboard.entity.FinanceOrderStatusModel;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderStatusCountModel;
import com.qvc.orderflowdashboard.entity.OrderStatusModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;
import com.qvc.orderflowdashboard.entity.PackageStatusModel;
import com.qvc.orderflowdashboard.entity.WarehousePackageCountModel;
import com.qvc.orderflowdashboard.model.FinanceOrderDetail;
import com.qvc.orderflowdashboard.response.DashboardResponse;
import com.qvc.orderflowdashboard.response.DemandFulfilmentData;
import com.qvc.orderflowdashboard.response.DemandManagementData;
import com.qvc.orderflowdashboard.response.FinanceHoldData;
import com.qvc.orderflowdashboard.util.OrderFlowConstants;
import com.qvc.orderflowdashboard.vo.BarChartDF;
import com.qvc.orderflowdashboard.vo.BarChartDatasetsDF;

@Service
public class DashboardService {

	public static final String STATUS_630000 = "630000";
	public static final String STATUS_670000 = "670000";
	public static final String STATUS_680000 = "680000";
	public static final String STATUS_725000 = "725000";
	public static final String STATUS_725100 = "725100";
	public static final String STATUS_780000 = "780000";
	public static final String STATUS_790000 = "790000";
	public static final String LAST_0_24 = "last0-24";
	public static final String FINANCE_HOLD = "financeHold";
	public static final String LAST_24_48 = "last24-48";
	public static final String ABOVE_72 = "above72";
	public static final String DEMAND_MANAGEMENT = "demandManagement";
	public static final String LAST_48_72 = "last48-72";
	public static final String DEMAND_FULFILMENT = "demandFulfilment";
	public static final String DC_3545 = "#dc3545";
	public static final String COLOR_198754 = "#198754";
	public static final String COLOR_FD7E14 = "#fd7e14";
	public static final String ABOVE = "above";
	private final DashboardDAO dashboardDAO;
private final DFService dFService;

	public DashboardService(DashboardDAO dashboardDAO, DFService dFService) {
		super();
		this.dashboardDAO = dashboardDAO;
		this.dFService = dFService;
	}

	@Value("${colorFlag.red}")
	private final String colorFlagRed = "#EC7063";
	@Value("${colorFlag.yellow}")
	private final String colorFlagYellow = "#F4d03F";
	@Value("${colorFlag.green}")
	private final String colorFlagGreen = "#58D68D";

	@Value("${financeHold.red}")
	int financeHoldRed;
	@Value("${financeHold.yellow}")
	int financeHoldYellow;
	@Value("${demandManagement.red}")
	int demandManagementRed;
	@Value("${demandManagement.yellow}")
	int demandManagementYellow;
	@Value("${demandFulfilment.red}")
	int demandFulfilmentRed;
	@Value("${demandManagement.yellow}")
	int demandFulfilmentYellow;






	public BarChartDF demandFulfilmentBarChartData() {

		Optional<String> dcNbr = Optional.ofNullable(null);
		Date fromDate=dFService.getDefaultOrderFlowStartDate();
		Date endDate=new Date();
		List<PackageStatusModel> demandFulfilmentInHours = demandFulfilmentInHours(fromDate,endDate);
		BarChartDF barChart = new BarChartDF();

		List<String> labels = new ArrayList<>();

		List<BarChartDF> datasets = new ArrayList<>();

		new BarChartDF();
		BarChartDatasetsDF selection = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(630000) + "(630000)", getBGColor(STATUS_630000), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));
		BarChartDatasetsDF released = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(670000) + "(670000)", getBGColor(STATUS_670000), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));
		BarChartDatasetsDF wavePending = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(680000) + "(680000)", getBGColor(STATUS_680000), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));
		BarChartDatasetsDF dcReciptConfirmed1 = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(780000) + "(780000)", getBGColor(STATUS_780000), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));
		BarChartDatasetsDF dcReciptConfirmed2 = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(790000) + "(790000)", getBGColor(STATUS_790000), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));
		BarChartDatasetsDF sendToDropship = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(725000) + "(725000)", getBGColor(STATUS_725000), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));
		BarChartDatasetsDF dropshipReciptConfirmed = new BarChartDatasetsDF(OrderFlowConstants.StatusDescMap.get(725100) + "(725100)", getBGColor(STATUS_725100), "#000", "2",
				new ArrayList(Arrays.asList("", "", "", "", "")));

		demandFulfilmentInHours.forEach(e -> {
			if (!labels.contains(e.getWareHouseName()))
				labels.add(e.getWareHouseName());

			switch (String.valueOf(e.getStatusId())) {
				case STATUS_630000: {
					selection.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}
				case STATUS_670000: {
					released.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}
				case STATUS_680000: {
					wavePending.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}
				case STATUS_725000: {
					dcReciptConfirmed1.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}
				case STATUS_725100: {
					dcReciptConfirmed2.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}
				case STATUS_780000: {
					sendToDropship.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}
				case STATUS_790000: {
					dropshipReciptConfirmed.getData().add(getwarehouseIndex(e.getWareHouseName()),
							String.valueOf(e.getGreaterThan72Hour().getValue()));
					break;
				}

				default:
					break;
			}

		});
		barChart.setLabels(labels);
		barChart.getDatasets().add(selection);
		barChart.getDatasets().add(released);
		barChart.getDatasets().add(wavePending);
		barChart.getDatasets().add(dcReciptConfirmed1);
		barChart.getDatasets().add(dcReciptConfirmed2);
		barChart.getDatasets().add(sendToDropship);
		barChart.getDatasets().add(dropshipReciptConfirmed);
		// //System.out.println("BARCHART: " + barChart);
		return barChart;

	}

	public DashboardResponse dashboardHome() {

		List<OrderStatusCountModel> orderInFinanceHold = null;
		List<OrderStatusCountModel> orderInDMHold = null;
		List<WarehousePackageCountModel> warehousePackageCountModels = null;
		DashboardResponse dashboardResponse = new DashboardResponse();
		try {
			orderInFinanceHold = dashboardDAO.orderInFinanceHoldCount();
			orderInDMHold = dashboardDAO.ordersInDMEventRetreiverCount();
			warehousePackageCountModels = dashboardDAO.packageInDemandFulfilmentCount();
			DemandManagementData demandManagementData = new DemandManagementData();
			demandManagementData.setDemandManagement(orderInDMHold);

			if (orderInDMHold.stream().anyMatch(o -> o.getColorFlag().equals(colorFlagRed))) {
				demandManagementData.setColorFlag(colorFlagRed);
			} else if (orderInDMHold.stream().anyMatch(o -> o.getColorFlag().equals(colorFlagYellow))) {
				demandManagementData.setColorFlag(colorFlagYellow);
			} else {
				demandManagementData.setColorFlag(colorFlagGreen);
			}

			FinanceHoldData financeHoldData = new FinanceHoldData();
			financeHoldData.setFinanceHold(orderInFinanceHold);
			if (orderInFinanceHold.stream().anyMatch(o -> o.getColorFlag().equals(colorFlagRed))) {
				financeHoldData.setColorFlag(colorFlagRed);
			} else if (orderInFinanceHold.stream().anyMatch(o -> o.getColorFlag().equals(colorFlagYellow))) {
				financeHoldData.setColorFlag(colorFlagYellow);
			} else {
				financeHoldData.setColorFlag(colorFlagGreen);
			}
			DemandFulfilmentData demandFulfilmentData = new DemandFulfilmentData();
			demandFulfilmentData.setDemandFulfilment(warehousePackageCountModels);
			if (warehousePackageCountModels.stream().anyMatch(o -> o.getColorFlag().equals(colorFlagRed))) {
				demandFulfilmentData.setColorFlag(colorFlagRed);
			} else if (warehousePackageCountModels.stream().anyMatch(o -> o.getColorFlag().equals(colorFlagYellow))) {
				demandFulfilmentData.setColorFlag(colorFlagYellow);
			} else {
				demandFulfilmentData.setColorFlag(colorFlagGreen);
			}

			dashboardResponse.setDemandManagement(demandManagementData);
			dashboardResponse.setFinanceHold(financeHoldData);
			dashboardResponse.setDemandFulfilment(demandFulfilmentData);
		} catch (Exception e) {
		}

		return dashboardResponse;
	}

	public List<OrderDetailsModel> financeCheckReprocessOrders() {

		List<OrderDetailsModel> financeCheckOrderDetails = dashboardDAO.financeCheckOrderDetails();
		return financeCheckOrderDetails;
	}


	//Finance - Availableyu
	/*public List<FinanceOrderDetailsModel> getFinanceHoldStuckOrderDetails(Date startDate, Date endDate)
			throws ParseException {


		List<FinanceOrderDetailsModel> financeHoldOrderDetails = dashboardDAO.financeHoldOrderDetails(startDate,
				endDate);

		return financeHoldOrderDetails;
	}*/
	//Finance - Available
	public List<FinanceOrderDetail> financeHoldStuckOrderOutflowflowDetails(Date startDate, Date endDate)
			throws ParseException {


		List<FinanceOrderDetail> financeHoldOrderDetails = dashboardDAO.financeOrderOutflowflowDetails(startDate,
				endDate);


		return financeHoldOrderDetails;
	}


	//Finance
	public List<FinanceOrderDetail> financeReleasedOrderDetails(Date startDate, Date endDate) throws ParseException {


		List<FinanceOrderDetail> financeHoldOrderDetails = dashboardDAO.financeReleasedOrderaDetails(startDate,
				endDate);


		return financeHoldOrderDetails;
	}

	//Finance Avaialble
	public List<FinanceOrderDetail> financeInflowOrderDetails(Date startDate, Date endDate) throws ParseException {

		//	Date statusEffDate = getStatusEffTimeStamp(statusEffTime);
		//Date ludTimeStamp = getLastUPDTimeStamp(lastUpdateTime);

//			List<FinanceOrderDetailsModel> financeHoldOrderDetails = dashboardDAO.financeHoldStuckOrderOutflowflowDetails(startDate,endDate);

		List<FinanceOrderDetail> financeHoldOrderDetails = dashboardDAO.financeOrderInflowDetails(startDate,endDate);


		return financeHoldOrderDetails;
	}

	public Date convertJSDateToDate(String date) throws ParseException {
		DateFormat formatter =new SimpleDateFormat("yyyy/MM/dd hh:mm a");// new SimpleDateFormat("dd-mm-yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		if (date==null) {
			cal.add(Calendar.DATE, -365);
			return cal.getTime();

		}

		return formatter.parse(date);
	}

	public Date getLastUPDTimeStamp(String date) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");//new SimpleDateFormat("dd-mm-yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		if (date==null) {
			cal.add(Calendar.DATE, -190);
			return cal.getTime();

		}

		return formatter.parse(date);
	}



	public List<FinanceOrderStatusModel> financeHoldInHours() {
		List<FinanceOrderStatusModel> financeHoldInHours = dashboardDAO.getFinanceHoldInHours();

		return financeHoldInHours;
	}

	public List<FinanceOrderStatusModel> financeOrderRelease() {
		List<FinanceOrderStatusModel> financeHoldInHours = dashboardDAO.financeOrderRelease();
		//	System.out.println("FINANCE ORDER RELEASE: >>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + financeHoldInHours);
		final StringBuffer color = new StringBuffer(colorFlagGreen);
		financeHoldInHours.stream().forEach(o -> {

			o.getLst1Hour().setColorCode(
					getColorCode(FINANCE_HOLD, o.getStatusId().toString(), LAST_0_24, o.getLst1Hour().getValue()));
			o.getLst24To48Hour().setColorCode(getColorCode(FINANCE_HOLD, o.getStatusId().toString(),
					LAST_24_48,
					o.getLst24To48Hour().getValue()));
			o.getAbv72Hour().setColorCode(
					getColorCode(FINANCE_HOLD, o.getStatusId().toString(),
							ABOVE_72, o.getAbv72Hour().getValue()));



		});
		return financeHoldInHours;
	}
	//AVAIL
	public List<OrderStatusModel> demandManagementInHours() {
		List<OrderStatusModel> demandManagementInHours = dashboardDAO.demandManagementNoInventoryInHours();
		// demandManagementInHours.addAll(dashboardDAO.demandManagementExceptionInHours());
		final StringBuffer color = new StringBuffer(colorFlagGreen);
		demandManagementInHours.stream().forEach(o -> {
			o.getLst24Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT
					, o.getStatusId().toString(), LAST_0_24,
					o.getLst24Hour().getValue()));
			o.getLst24To48Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_24_48,
					o.getLst24To48Hour().getValue()));
			o.getAbv72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), ABOVE_72,
					o.getAbv72Hour().getValue()));

			if (o.getLst24Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagRed)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagRed)) {
				// color.delete(0, color.length() - 1).append(colorFlagRed);
				o.setColorCode(colorFlagRed);
			} else if (o.getLst24Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagYellow)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagYellow)) {
				// color.delete(0, color.length() - 1).append(colorFlagYellow);
				o.setColorCode(colorFlagYellow);
			} else {
				o.setColorCode(colorFlagGreen);
			}

		});
		return demandManagementInHours;
	}


	public List<OrderStatusModel> demandManagementRealInventoryHoldInHours() {
		List<OrderStatusModel> demandManagementInHours = dashboardDAO.demandManagementRealInventoryHoldInHours();
		// demandManagementInHours.addAll(dashboardDAO.demandManagementExceptionInHours());
		final StringBuffer color = new StringBuffer(colorFlagGreen);
		demandManagementInHours.stream().forEach(o -> {
			o.getLst24Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_0_24,
					o.getLst24Hour().getValue()));
			o.getLst24To48Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_24_48,
					o.getLst24To48Hour().getValue()));
			o.getLst48To72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(),
					LAST_48_72,
					o.getLst24To48Hour().getValue()));
			o.getAbv72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), ABOVE_72,
					o.getAbv72Hour().getValue()));

			if (o.getLst24Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst48To72Hour().getColorCode().equals(colorFlagRed)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagRed)) {
				// color.delete(0, color.length() - 1).append(colorFlagRed);
				o.setColorCode(colorFlagRed);
			} else if (o.getLst24Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst48To72Hour().getColorCode().equals(colorFlagYellow)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagYellow)) {
				// color.delete(0, color.length() - 1).append(colorFlagYellow);
				o.setColorCode(colorFlagYellow);
			} else {
				o.setColorCode(colorFlagGreen);
			}

		});
		return demandManagementInHours;
	}


	public List<OrderStatusModel> demandManagementStuckOrderInHours() {
		List<OrderStatusModel> demandManagementInHours = dashboardDAO.demandManagementStuckOrderInHours();
		// demandManagementInHours.addAll(dashboardDAO.demandManagementExceptionInHours());
		final StringBuffer color = new StringBuffer(colorFlagGreen);
		demandManagementInHours.stream().forEach(o -> {
			o.getLst24Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_0_24,
					o.getLst24Hour().getValue()));
			o.getLst24To48Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_24_48,
					o.getLst24To48Hour().getValue()));
			o.getLst48To72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_48_72,
					o.getLst24To48Hour().getValue()));
			o.getAbv72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), ABOVE_72,
					o.getAbv72Hour().getValue()));

			if (o.getLst24Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst48To72Hour().getColorCode().equals(colorFlagRed)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagRed)) {
				// color.delete(0, color.length() - 1).append(colorFlagRed);
				o.setColorCode(colorFlagRed);
			} else if (o.getLst24Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst48To72Hour().getColorCode().equals(colorFlagYellow)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagYellow)) {
				// color.delete(0, color.length() - 1).append(colorFlagYellow);
				o.setColorCode(colorFlagYellow);
			} else {
				o.setColorCode(colorFlagGreen);
			}

		});
		return demandManagementInHours;
	}

	public List<OrderStatusModel> demandManagementExceptionInHours() {
		List<OrderStatusModel> demandManagementInHours = dashboardDAO.demandManagementExceptionInHours();
		// demandManagementInHours.addAll(dashboardDAO.demandManagementExceptionInHours());
		final StringBuffer color = new StringBuffer(colorFlagGreen);
		demandManagementInHours.stream().forEach(o -> {
			o.getLst24Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_0_24,
					o.getLst24Hour().getValue()));
			o.getLst24To48Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_24_48,
					o.getLst24To48Hour().getValue()));
			o.getLst48To72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), LAST_48_72,
					o.getLst48To72Hour().getValue()));
			o.getAbv72Hour().setColorCode(getColorCode(DEMAND_MANAGEMENT, o.getStatusId().toString(), ABOVE_72,
					o.getAbv72Hour().getValue()));

			if (o.getLst24Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst48To72Hour().getColorCode().equals(colorFlagRed)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagRed)) {
				// color.delete(0, color.length() - 1).append(colorFlagRed);
				o.setColorCode(colorFlagRed);
			} else if (o.getLst24Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst48To72Hour().getColorCode().equals(colorFlagRed)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagYellow)) {
				// color.delete(0, color.length() - 1).append(colorFlagYellow);
				o.setColorCode(colorFlagYellow);
			} else {
				o.setColorCode(colorFlagGreen);
			}

		});
		return demandManagementInHours;
	}

	public List<OrderStatusModel> demandFulfilmentExceptionInHours() {
		List<OrderStatusModel> demandFulfilmentInHours = dashboardDAO.getDemandFulfilmentExceptionInHours();
		// demandManagementInHours.addAll(dashboardDAO.demandManagementExceptionInHours());
		final StringBuffer color = new StringBuffer(colorFlagGreen);
		demandFulfilmentInHours.stream().forEach(o -> {
			o.getLst24Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), LAST_0_24,
					o.getLst24Hour().getValue()));
			o.getLst24To48Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), LAST_24_48,
					o.getLst24To48Hour().getValue()));
			o.getAbv72Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), ABOVE_72,
					o.getAbv72Hour().getValue()));

			if (o.getLst24Hour().getColorCode().equals(colorFlagRed)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagRed)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagRed)) {
				// color.delete(0, color.length() - 1).append(colorFlagRed);
				o.setColorCode(colorFlagRed);
			} else if (o.getLst24Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLst24To48Hour().getColorCode().equals(colorFlagYellow)
					|| o.getAbv72Hour().getColorCode().equals(colorFlagYellow)) {
				// color.delete(0, color.length() - 1).append(colorFlagYellow);
				o.setColorCode(colorFlagYellow);
			} else {
				o.setColorCode(colorFlagGreen);
			}

		});
		return demandFulfilmentInHours;
	}

	public List<PackageStatusModel> demandFulfilmentInHours(Date fromDate,Date endDate) {
		List<PackageStatusModel> demandFulfilmentInHours = dashboardDAO.getDemandFulfilmentInHours(fromDate, endDate);
		demandFulfilmentInHours.stream().forEach(o -> {

			o.getLast1Hour().setColorCode(
					getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), "last1", o.getLast1Hour().getValue()));
			o.getLast1To3Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), "last1-3",
					o.getLast1To3Hour().getValue()));
			o.getLast3To6Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), "last3-6",
					o.getLast3To6Hour().getValue()));
			o.getLast6To24Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), "last6-24",
					o.getLast6To24Hour().getValue()));
			o.getLast24To48Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), LAST_24_48,
					o.getLast24To48Hour().getValue()));

			o.getLast48To72Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(), LAST_48_72,
					o.getLast48To72Hour().getValue()));
			o.getGreaterThan72Hour().setColorCode(getColorCode(DEMAND_FULFILMENT, o.getStatusId().toString(),
					ABOVE_72, o.getGreaterThan72Hour().getValue()));

			if (o.getLast1Hour().getColorCode().equals(colorFlagRed)
					|| o.getLast1To3Hour().getColorCode().equals(colorFlagRed)
					|| o.getLast3To6Hour().getColorCode().equals(colorFlagRed)
					|| o.getLast6To24Hour().getColorCode().equals(colorFlagRed)
					|| o.getLast24To48Hour().getColorCode().equals(colorFlagRed)
					|| o.getLast48To72Hour().getColorCode().equals(colorFlagRed)
					|| o.getGreaterThan72Hour().getColorCode().equals(colorFlagRed)) {
				// color.delete(0, color.length() - 1).append(colorFlagRed);
				o.setColorCode(colorFlagRed);
			} else if (o.getLast1Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLast1To3Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLast3To6Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLast6To24Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLast24To48Hour().getColorCode().equals(colorFlagYellow)
					|| o.getLast48To72Hour().getColorCode().equals(colorFlagYellow)
					|| o.getGreaterThan72Hour().getColorCode().equals(colorFlagYellow)) {
				// color.delete(0, color.length() - 1).append(colorFlagYellow);
				o.setColorCode(colorFlagYellow);
			} else {
				o.setColorCode(colorFlagGreen);
			}


		});
		return demandFulfilmentInHours;
	}

	public String getBGColor(String status) {
		Map<String, String> map = Stream.of(new AbstractMap.SimpleEntry<>("320000",
						DC_3545),
				new AbstractMap.SimpleEntry<>("340000", COLOR_198754), new AbstractMap.SimpleEntry<>("2190000", DC_3545),
				new AbstractMap.SimpleEntry<>("2210000", "#ffc107"),
				new AbstractMap.SimpleEntry<>("2230000", COLOR_198754),
				new AbstractMap.SimpleEntry<>("2250000", "#0d6efd"),
				new AbstractMap.SimpleEntry<>("31660000", COLOR_FD7E14),
				new AbstractMap.SimpleEntry<>("3170000", COLOR_FD7E14),
				new AbstractMap.SimpleEntry<>("3140000", "#6f42c1"),
				new AbstractMap.SimpleEntry<>("2270000", COLOR_198754),
				// new AbstractMap.SimpleEntry<>("3140000", "#da3575"),
				new AbstractMap.SimpleEntry<>(STATUS_630000, DC_3545), new AbstractMap.SimpleEntry<>(STATUS_670000, COLOR_FD7E14),
				new AbstractMap.SimpleEntry<>(STATUS_680000, "#ffc107"), new AbstractMap.SimpleEntry<>(STATUS_780000, "#0dcaf0"),
				new AbstractMap.SimpleEntry<>(STATUS_790000, COLOR_198754), new AbstractMap.SimpleEntry<>(STATUS_725000, "#6f42c1"),
				new AbstractMap.SimpleEntry<>(STATUS_725100, COLOR_FD7E14)

		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		String color = map.get(status);
		if(color==null) {
			System.out.println("NO COLOR FOUND for "+status);
			color="#eb4034";
		}
		if (color.isEmpty())
			return "black";
		else
			return color;

	}

	public int getwarehouseIndex(String status) {
		Map<String, Integer> map = Stream.of(new AbstractMap.SimpleEntry<>("BETHLEHEM", 0),
				new AbstractMap.SimpleEntry<>("DROP SHIP", 1), new AbstractMap.SimpleEntry<>("FLORENCE", 2),
				new AbstractMap.SimpleEntry<>("ONTARIO", 3), new AbstractMap.SimpleEntry<>("SUFFOLK", 4)

		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

		Integer index = map.get(String.valueOf(status));
		return index;
	}

	public String getColorCode(String service, String status, String time, BigDecimal value) {
		// String value="financeHold.320000.last0-24.max";
		String k = service + "." + status + "." + time;
		Map<String, Integer> map = Stream.of(new AbstractMap.SimpleEntry<>("financeHold.320000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("financeHold.320000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("financeHold.320000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("financeHold.320000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("financeHold.320000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("financeHold.320000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("financeHold.340000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("financeHold.340000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("financeHold.340000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("financeHold.340000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("financeHold.340000.above72.min", 20000),
				new AbstractMap.SimpleEntry<>("financeHold.340000.above72.max", 40000),

				new AbstractMap.SimpleEntry<>("demandManagement.420000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.420000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.460000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.500000.above72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.500010.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.500010.last48-72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.500500.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.last48-72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.500500.last48-72.max", 1101),



				new AbstractMap.SimpleEntry<>("demandManagement.500020.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.above72.min", 1),
				new AbstractMap.SimpleEntry<>("demandManagement.500020.above72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.470000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.470000.last48-72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.3175500.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.last48-72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3175500.last48-72.max", 1101),



				new AbstractMap.SimpleEntry<>("demandManagement.3178000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.above72.min", 1),
				new AbstractMap.SimpleEntry<>("demandManagement.3178000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.400000.last48-72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.3150000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.last48-72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3150000.last48-72.max", 1101),



				new AbstractMap.SimpleEntry<>("demandManagement.490000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.above72.min", 1),
				new AbstractMap.SimpleEntry<>("demandManagement.490000.above72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.430000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.430000.above72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.380000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.380000.last48-72.max", 2101),

				new AbstractMap.SimpleEntry<>("demandManagement.390000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.last48-72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.390000.last48-72.max", 1101),



				new AbstractMap.SimpleEntry<>("demandManagement.410000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.last48-72.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.last48-72.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.above72.min", 1),
				new AbstractMap.SimpleEntry<>("demandManagement.410000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3160000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandManagement.2190000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.2190000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.2210000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.2230000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.last0-24.min", 150),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.last0-24.max", 600),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.last24-48.min", 601),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.last24-48.max", 1100),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.2250000.above72.max", 2101),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3166000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3170000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.last0-24.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3140000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.2270000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandManagement.2290000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.2290000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3177000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.last48-72.min", 10),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.last48-72.max", 1000),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandManagement.3176500.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.above72.min", 100),
				new AbstractMap.SimpleEntry<>("demandFulfilment.630000.above72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.670000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.680000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.780000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.790000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.725100.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1040000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.1050000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last1.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last1.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last1-3.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last1-3.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last3-6.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last3-6.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last6-24.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last6-24.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last24-48.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last24-48.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last48-72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.last48-72.max", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.above72.min", 1101),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2190000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2320000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2320000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2320000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2320000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2320000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2320000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2350000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2350000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2350000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2350000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2350000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2350000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2410000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2410000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2410000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2410000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2410000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2410000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2380000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2380000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2380000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2380000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2380000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2380000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2530000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2530000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2530000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2530000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2530000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2530000.above72.max", 1101),

				new AbstractMap.SimpleEntry<>("demandFulfilment.2440000.last0-24.min", 0),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2440000.last0-24.max", 25),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2440000.last24-48.min", 10),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2440000.last24-48.max", 1000),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2440000.above72.min", 1001),
				new AbstractMap.SimpleEntry<>("demandFulfilment.2440000.above72.max", 1101)

				// 2350000,2380000,2410000,2320000,2530000,2440000

				// '630000','670000','680000','7250000','7215000',780000,790000
		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));


		Integer min = map.get(k + "." + "min");
		Integer max = map.get(k + "." + "max");

		if (value.compareTo(new BigDecimal(max)) > 0) {
			return colorFlagRed;
		} else if ((value.compareTo(new BigDecimal(min)) > 0) && (value.compareTo(new BigDecimal(max)) < 0)) {
			return colorFlagYellow;
		}

		return colorFlagGreen;

	}


	public List<OrderDetailsModel> finaceReleaseOrderDetails( String field, String value) {

		// List<Date> dates = addHoursToJavaUtilDate(field, value);

		String qs = null;
		int start = 0;
		int end = 0;

		if (value.startsWith("last")) {

			String[] split = value.replace("last", "").split("-");
			start = Integer.parseInt(split[0]);
			end = Integer.parseInt(split[1]);
		} else {
			String split = value.replace(ABOVE, "");
			start = Integer.parseInt(split);
		}

		return dashboardDAO.financeReleaeOrderDetails(field, start, end);
	}


	public List<OrderDetailsModel> orderDetails(String status, String field, String value, boolean isInvHold) {

		// List<Date> dates = addHoursToJavaUtilDate(field, value);

		String qs = null;
		int start = 0;
		int end = 0;

		if (value.startsWith("last")) {

			String[] split = value.replace("last", "").split("-");
			start = Integer.parseInt(split[0]);
			end = Integer.parseInt(split[1]);
		} else {
			String split = value.replace(ABOVE, "");
			start = Integer.parseInt(split);
		}

		return dashboardDAO.orderDetails(status, field, start, end, isInvHold);
	}

	public List<PackageDetailsModel> packageDetails(String status, String whse, Date fromDate,Date endDate){
		int dcId = getWarehouseId(whse);
		return dashboardDAO.packageDetailsWithDateFilter(status, dcId,  fromDate, endDate);
	}
	public List<PackageDetailsModel> packageDetails(String status, String whse, String field, String value) {

		// List<Date> dates = addHoursToJavaUtilDate(field, value);

		String qs = null;
		int start = 0;
		int end = 0;

		if (value.startsWith("last")) {

			String[] split = value.replace("last", "").split("-");
			start = Integer.parseInt(split[0]);
			end = Integer.parseInt(split[1]);
		}else if(value.startsWith("all")){
			start=0;
			end=90*24;
		}
		else {
			String split = value.replace(ABOVE, "");
			start = Integer.parseInt(split);
			end=90*24;
		}
		int dcId = getWarehouseId(whse);

			return dashboardDAO.packageDetails(status, dcId, field, start, end);
	}

	public int getWarehouseId(String whse) {

		switch (whse) {
			case "BETHLEHEM":
				return 9;
			case "ONTARIO":
				return 6;
			case "FLORENCE":
				return 5;
			case "ROCKY":
				return 4;
			case "LANCASTER":
				return 3;
			case "SUFFOLK":
				return 1;
			case "DROP SHIP":
				return 0;
			default:
				break;
		}
		return 9;

	}

	public List<Date> addHoursToJavaUtilDate(String field, String value) {
		int start = 0;
		int end = 0;

		if (value.startsWith("last")) {
			String[] split = value.replace("last", "").split("-");
			start = Integer.parseInt(split[0]);
			end = Integer.parseInt(split[1]);
		} else {
			String split = value.replace(ABOVE, "");
			start = Integer.parseInt(split);
		}
		Date startDate = null;
		Date endDate = null;
		List<Date> dates = new ArrayList<>();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());

		if (field.equals("hour")) {
			calendar.add(Calendar.HOUR_OF_DAY, (start * -1));
			startDate = calendar.getTime();
			calendar.setTime(new Date());
			calendar.add(Calendar.HOUR_OF_DAY, (end * -1));
			endDate = calendar.getTime();
		} else {
			calendar.add(Calendar.DAY_OF_MONTH, (start * -1));
			startDate = calendar.getTime();
			calendar.setTime(new Date());
			calendar.add(Calendar.DAY_OF_MONTH, (end * -1));
			endDate = calendar.getTime();
		}
		if (value.startsWith(ABOVE))
			endDate = null;

		dates.add(startDate);
		dates.add(endDate);
		return dates;
	}

	public int demandManagementOrdersWithNoEDDandShpByDT() {

		return dashboardDAO.demandManagementOrdersWithNoEDDandShpByDT();
	}

	public int dmOrdersNotReleased() {

		return dashboardDAO.getDmOrdersNotReleased();
	}

	public int dmOrdersWithPastEDD() {

		return dashboardDAO.getDmOrdersWithPastEDD();
	}

	public List<OrderDetailsModel> demandManagementOrdersWithNoEDDandShpByDTOrderDetails() {

		return dashboardDAO.demandManagementOrdersWithNoEDDandShpByDTOrderDetails();
	}

	public List<OrderDetailsModel> dmOrdersNotReleasedOrderDetails() {

		return dashboardDAO.dmOrdersNotReleasedOrderDetails();
	}

	public List<OrderDetailsModel> dmOrdersWithPastEDDOrderDetails() {

		return dashboardDAO.dmOrdersWithPastEDDOrderDetails();
	}
}
