package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.PackageNotCreated;

public class PackageNotCreatedRowMapper implements RowMapper<PackageNotCreated>{

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(PackageNotCreated.class);
	@Override
	public PackageNotCreated mapRow(ResultSet rs, int rowNum) throws SQLException {
		PackageNotCreated packageNotCreated=new PackageNotCreated();
		try {
			packageNotCreated.setOrdNbr(rs.getString("ORD_NBR"));
			packageNotCreated.setOrdLnNbr(rs.getBigDecimal("ORD_LN_NBR"));
			packageNotCreated.setOrdFlowStatId(rs.getBigDecimal("ORD_FLOW_STAT_ID"));
			packageNotCreated.setOrdDt(rs.getDate("ORD_DT"));
			packageNotCreated.setOrderlineQty(rs.getInt("ORDERLINE_QTY"));
			packageNotCreated.setAcctNbr(rs.getString("ACCT_NBR"));
			
		} catch (Exception e) {
			log.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return packageNotCreated;
	}

}
