package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;

public class OrderFlowRowMapper implements RowMapper<OrderFlowExceptions> {

	public OrderFlowExceptions mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderFlowExceptions orderFlowExceptions = new OrderFlowExceptions();
		try {
			orderFlowExceptions.setOrd_flow_stat_dsc(rs.getString("ord_flow_stat_dsc"));
			orderFlowExceptions.setOrderFlowStatId(rs.getLong("ord_flow_stat_id"));
			orderFlowExceptions.setBusn_proc_typ_dsc(rs.getString("busn_proc_typ_dsc"));
			orderFlowExceptions.setBusn_acty_typ_dsc(rs.getString("busn_acty_typ_dsc"));

			orderFlowExceptions.setOrd_flow_lvl_dsc(rs.getString("ord_flow_lvl_dsc"));
			orderFlowExceptions.setIs_oscrol_ind((rs.getString("is_oscrol_ind")));
			orderFlowExceptions.setIs_oscrpkq_ind((rs.getString("is_oscrpkq_ind")));
			orderFlowExceptions.setIs_oscrpkd_ind((rs.getString("is_oscrpkd_ind")));
			orderFlowExceptions.setOrd_flow_sum_dsc(rs.getString("ord_flow_sum_dsc"));
			orderFlowExceptions.setOrd_flow_rsn_dsc(rs.getString("ord_flow_rsn_dsc"));
			orderFlowExceptions.setTotOrderLineCnt(rs.getLong("TOT_ORD_LN_CNT"));
			orderFlowExceptions.setTotPkgCnt(rs.getLong("TOT_PKG_CNT"));

		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

		return orderFlowExceptions;
	}
}
