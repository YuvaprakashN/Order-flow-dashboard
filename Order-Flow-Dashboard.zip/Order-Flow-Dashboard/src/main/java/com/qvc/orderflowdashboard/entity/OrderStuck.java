package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;
import java.util.Date;

public class OrderStuck {

	
	private String ordNbr;
	private BigDecimal ordLnNbr;
	private BigDecimal ordFlowStatId;
	private String itemNbr;
	private String colorNbr;
	private String sizeNbr;
	private Date ordDt;
	private BigDecimal pkgId;
	private BigDecimal pkgOrdFlowStatId;
	private Integer invcNbr;
	private BigDecimal boxNbr;
	private Date lastUpdTms;
	private BigDecimal dcPartnNbr;
	private BigDecimal dcId;
	private String legacyWhseNbr;
	private String dcTransConfgCd;
	private String dcDsc;
	
	
	
	public OrderStuck() {
		super();
	}
	public String getOrdNbr() {
		return ordNbr;
	}
	public void setOrdNbr(String ordNbr) {
		this.ordNbr = ordNbr;
	}
	public BigDecimal getOrdLnNbr() {
		return ordLnNbr;
	}
	public void setOrdLnNbr(BigDecimal ordLnNbr) {
		this.ordLnNbr = ordLnNbr;
	}
	public BigDecimal getOrdFlowStatId() {
		return ordFlowStatId;
	}
	public void setOrdFlowStatId(BigDecimal ordFlowStatId) {
		this.ordFlowStatId = ordFlowStatId;
	}
	public String getItemNbr() {
		return itemNbr;
	}
	public void setItemNbr(String itemNbr) {
		this.itemNbr = itemNbr;
	}
	public String getColorNbr() {
		return colorNbr;
	}
	public void setColorNbr(String colorNbr) {
		this.colorNbr = colorNbr;
	}
	public String getSizeNbr() {
		return sizeNbr;
	}
	public void setSizeNbr(String sizeNbr) {
		this.sizeNbr = sizeNbr;
	}
	public Date getOrdDt() {
		return ordDt;
	}
	public void setOrdDt(Date ordDt) {
		this.ordDt = ordDt;
	}
	public BigDecimal getPkgId() {
		return pkgId;
	}
	public void setPkgId(BigDecimal pkgId) {
		this.pkgId = pkgId;
	}
	public BigDecimal getPkgOrdFlowStatId() {
		return pkgOrdFlowStatId;
	}
	public void setPkgOrdFlowStatId(BigDecimal pkgOrdFlowStatId) {
		this.pkgOrdFlowStatId = pkgOrdFlowStatId;
	}
	public Integer getInvcNbr() {
		return invcNbr;
	}
	public void setInvcNbr(Integer invcNbr) {
		this.invcNbr = invcNbr;
	}
	public BigDecimal getBoxNbr() {
		return boxNbr;
	}
	public void setBoxNbr(BigDecimal boxNbr) {
		this.boxNbr = boxNbr;
	}
	public Date getLastUpdTms() {
		return lastUpdTms;
	}
	public void setLastUpdTms(Date lastUpdTms) {
		this.lastUpdTms = lastUpdTms;
	}
	public BigDecimal getDcPartnNbr() {
		return dcPartnNbr;
	}
	public void setDcPartnNbr(BigDecimal dcPartnNbr) {
		this.dcPartnNbr = dcPartnNbr;
	}
	public BigDecimal getDcId() {
		return dcId;
	}
	public void setDcId(BigDecimal dcId) {
		this.dcId = dcId;
	}
	public String getLegacyWhseNbr() {
		return legacyWhseNbr;
	}
	public void setLegacyWhseNbr(String legacyWhseNbr) {
		this.legacyWhseNbr = legacyWhseNbr;
	}
	public String getDcTransConfgCd() {
		return dcTransConfgCd;
	}
	public void setDcTransConfgCd(String dcTransConfgCd) {
		this.dcTransConfgCd = dcTransConfgCd;
	}
	public String getDcDsc() {
		return dcDsc;
	}
	public void setDcDsc(String dcDsc) {
		this.dcDsc = dcDsc;
	}
	@Override
	public String toString() {
		return "\nOrderStuckInTransmission [ordNbr=" + ordNbr + ", ordLnNbr=" + ordLnNbr + ", ordFlowStatId="
				+ ordFlowStatId + ", itemNbr=" + itemNbr + ", colorNbr=" + colorNbr + ", sizeNbr=" + sizeNbr
				+ ", ordDt=" + ordDt + ", pkgId=" + pkgId + ", pkgOrdFlowStatId=" + pkgOrdFlowStatId + ", invcNbr="
				+ invcNbr + ", boxNbr=" + boxNbr + ", lastUpdTms=" + lastUpdTms + ", dcPartnNbr=" + dcPartnNbr
				+ ", dcId=" + dcId + ", legacyWhseNbr=" + legacyWhseNbr + ", dcTransConfgCd=" + dcTransConfgCd
				+ ", dcDsc=" + dcDsc + "]";
	}
	
	
	
}
