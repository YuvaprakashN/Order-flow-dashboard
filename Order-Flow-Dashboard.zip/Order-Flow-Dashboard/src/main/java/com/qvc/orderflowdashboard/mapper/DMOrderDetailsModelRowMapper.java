package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderDetailsModel;

public class DMOrderDetailsModelRowMapper implements RowMapper<OrderDetailsModel> {
	public OrderDetailsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderDetailsModel orderDetailsModel = new OrderDetailsModel();
		try {

			orderDetailsModel.setItemNumber(rs.getString("ITEM_NBR"));

			orderDetailsModel.setLastUpdatedDate(rs.getTimestamp("LAST_UPD_TMS"));
			orderDetailsModel.setOrderaccountNumber("ACCT_NBR");
			orderDetailsModel.setOrderDate(rs.getDate("ORD_DT"));
			orderDetailsModel.setOrderLineNumber(rs.getInt("ORD_LN_NBR"));
			orderDetailsModel.setOrderNumber(rs.getString("ORD_NBR"));
			orderDetailsModel.setEstDeliveryDate(rs.getTimestamp("REVSD_ESTDELVRY_DT"));
			orderDetailsModel.setShipByDate(rs.getTimestamp("SHIP_BY_DT"));

		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

		return orderDetailsModel;
	}

}
