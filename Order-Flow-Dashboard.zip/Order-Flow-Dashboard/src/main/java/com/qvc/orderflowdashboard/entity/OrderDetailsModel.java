package com.qvc.orderflowdashboard.entity;

import java.util.Date;

public class OrderDetailsModel {
	
	private String orderNumber;
	private Integer orderLineNumber;
	private String orderaccountNumber;
	private String itemNumber;
	private Date orderDate;
	private Date lastUpdatedDate;
	
	private Date statusEffTimestamp;
	private Date estDeliveryDate;
	private Date shipByDate;
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}
	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}
	public String getOrderaccountNumber() {
		return orderaccountNumber;
	}
	public void setOrderaccountNumber(String orderaccountNumber) {
		this.orderaccountNumber = orderaccountNumber;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public Date getStatusEffTimestamp() {
		return statusEffTimestamp;
	}
	public void setStatusEffTimestamp(Date statusEffTimestamp) {
		this.statusEffTimestamp = statusEffTimestamp;
	}
	public Date getEstDeliveryDate() {
		return estDeliveryDate;
	}
	public void setEstDeliveryDate(Date estDeliveryDate) {
		this.estDeliveryDate = estDeliveryDate;
	}
	public Date getShipByDate() {
		return shipByDate;
	}
	public void setShipByDate(Date shipByDate) {
		this.shipByDate = shipByDate;
	}
	@Override
	public String toString() {
		return "\nOrderDetailsModel [orderNumber=" + orderNumber + ", orderLineNumber=" + orderLineNumber
				+ ", orderaccountNumber=" + orderaccountNumber + ", itemNumber=" + itemNumber + ", orderDate="
				+ orderDate + ", lastUpdatedDate=" + lastUpdatedDate + ", statusEffTimestamp=" + statusEffTimestamp
				+ ", estDeliveryDate=" + estDeliveryDate + ", shipByDate=" + shipByDate + "]";
	}
	
	
	
	
}
