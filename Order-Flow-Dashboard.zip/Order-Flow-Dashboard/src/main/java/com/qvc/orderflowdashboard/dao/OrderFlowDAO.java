package com.qvc.orderflowdashboard.dao;

import java.util.Date;
import java.util.List;

import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;

public interface OrderFlowDAO {
	
	public List<OrderFlowExceptions> getBusinessExceptions(Date startDate, Date endDate);
	public List<OrderFlowExceptions> getITExceptions(Date startDate, Date endDate);
	public List<OrderDetailsModel> getorderDetailsJSON(int status,Date startDate, Date endDate);
	public OrderFlowStatVWModel getOrderFlowStatusVW(String status) ;
	public List<PackageDetailsModel> getPackageDetails(String status,Date startDate, Date endDate);
	public OrderFlowExceptions getpackageNotCreated(Date startDate,Date endDate);
}
