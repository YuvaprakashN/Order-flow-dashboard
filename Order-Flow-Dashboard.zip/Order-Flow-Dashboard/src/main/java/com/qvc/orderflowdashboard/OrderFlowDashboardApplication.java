package com.qvc.orderflowdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication(scanBasePackages = "com.qvc.orderflowdashboard")
public class OrderFlowDashboardApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(OrderFlowDashboardApplication.class);
	}
	public static void main(String[] args) {
		SpringApplication.run(OrderFlowDashboardApplication.class, args);
	}

}
