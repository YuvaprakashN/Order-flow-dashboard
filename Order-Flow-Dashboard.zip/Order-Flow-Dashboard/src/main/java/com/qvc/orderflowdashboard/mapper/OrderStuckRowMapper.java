package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderStuck;

public class OrderStuckRowMapper implements RowMapper<OrderStuck>{

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(OrderStuckRowMapper.class);
	@Override
	public OrderStuck mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderStuck orderStuckInTransmission=new OrderStuck();
		try {
			orderStuckInTransmission.setOrdNbr(rs.getString("ORD_NBR"));
			orderStuckInTransmission.setOrdLnNbr(rs.getBigDecimal("ORD_LN_NBR"));
			orderStuckInTransmission.setOrdFlowStatId(rs.getBigDecimal("ORD_FLOW_STAT_ID"));
			orderStuckInTransmission.setItemNbr(rs.getString("ITEM_NBR"));
			orderStuckInTransmission.setColorNbr(rs.getString("COLOR_NBR"));
			orderStuckInTransmission.setSizeNbr(rs.getString("SIZE_NBR"));
			orderStuckInTransmission.setOrdDt(rs.getDate("ORD_DT"));
			orderStuckInTransmission.setPkgId(rs.getBigDecimal("PKG_ID"));
			orderStuckInTransmission.setPkgOrdFlowStatId(rs.getBigDecimal("PKG_ORD_FLOW_STAT_ID"));
			orderStuckInTransmission.setInvcNbr(rs.getInt("INVC_NBR"));
			orderStuckInTransmission.setLastUpdTms(rs.getTimestamp("LAST_UPD_TMS"));
			orderStuckInTransmission.setDcPartnNbr(rs.getBigDecimal("DC_PARTN_NBR"));
		orderStuckInTransmission.setDcId(rs.getBigDecimal("DC_ID"));	
			orderStuckInTransmission.setBoxNbr(rs.getBigDecimal("BOX_NBR"));
			orderStuckInTransmission.setOrdNbr(rs.getString("ORD_NBR"));
			orderStuckInTransmission.setDcDsc(rs.getString("DC_DSC"));
			orderStuckInTransmission.setDcTransConfgCd(rs.getString("DC_TRANS_CONFG_CD"));
			orderStuckInTransmission.setLegacyWhseNbr(rs.getString("LEGACY_WHSE_NBR"));
		} catch (Exception e) {
			log.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return orderStuckInTransmission;
	}

}
