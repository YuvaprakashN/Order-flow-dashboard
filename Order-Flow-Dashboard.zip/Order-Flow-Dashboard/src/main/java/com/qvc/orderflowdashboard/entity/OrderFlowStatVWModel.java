package com.qvc.orderflowdashboard.entity;

public class OrderFlowStatVWModel {

	
private long orderFlowStatId;
	private String busn_proc_typ_dsc;
	private String busn_acty_typ_dsc;
	private String ord_flow_sum_dsc;
	private String ord_flow_rsn_dsc;
	private String ord_flow_stat_dsc;
	public long getOrderFlowStatId() {
		return orderFlowStatId;
	}
	public void setOrderFlowStatId(long orderFlowStatId) {
		this.orderFlowStatId = orderFlowStatId;
	}
	public String getBusn_proc_typ_dsc() {
		return busn_proc_typ_dsc;
	}
	public void setBusn_proc_typ_dsc(String busn_proc_typ_dsc) {
		this.busn_proc_typ_dsc = busn_proc_typ_dsc;
	}
	public String getBusn_acty_typ_dsc() {
		return busn_acty_typ_dsc;
	}
	public void setBusn_acty_typ_dsc(String busn_acty_typ_dsc) {
		this.busn_acty_typ_dsc = busn_acty_typ_dsc;
	}
	public String getOrd_flow_sum_dsc() {
		return ord_flow_sum_dsc;
	}
	public void setOrd_flow_sum_dsc(String ord_flow_sum_dsc) {
		this.ord_flow_sum_dsc = ord_flow_sum_dsc;
	}
	public String getOrd_flow_rsn_dsc() {
		return ord_flow_rsn_dsc;
	}
	public void setOrd_flow_rsn_dsc(String ord_flow_rsn_dsc) {
		this.ord_flow_rsn_dsc = ord_flow_rsn_dsc;
	}
	public String getOrd_flow_stat_dsc() {
		return ord_flow_stat_dsc;
	}
	public void setOrd_flow_stat_dsc(String ord_flow_stat_dsc) {
		this.ord_flow_stat_dsc = ord_flow_stat_dsc;
	}
	@Override
	public String toString() {
		return "\nOrderFlowStatVWModel [orderFlowStatId=" + orderFlowStatId + ", busn_proc_typ_dsc=" + busn_proc_typ_dsc
				+ ", busn_acty_typ_dsc=" + busn_acty_typ_dsc + ", ord_flow_sum_dsc=" + ord_flow_sum_dsc
				+ ", ord_flow_rsn_dsc=" + ord_flow_rsn_dsc + ", ord_flow_stat_dsc=" + ord_flow_stat_dsc + "]";
	}
	
	
	
	
}
