package com.qvc.orderflowdashboard.model;

import java.util.Collection;

public class OrderFlowModel {

	private String categoryLvl1Name;
	private long categoryLvl1Cnt;
	private long categoryLvl1PkgCnt;
	private Collection categoryLvl2List;
	private String categoryLvl1Desc;
	
	public long getCategoryLvl1PkgCnt() {
		return categoryLvl1PkgCnt;
	}
	public void setCategoryLvl1PkgCnt(long categoryLvl1PkgCnt) {
		this.categoryLvl1PkgCnt = categoryLvl1PkgCnt;
	}
	public String getCategoryLvl1Name() {
		return categoryLvl1Name;
	}
	public void setCategoryLvl1Name(String categoryLvl1Name) {
		this.categoryLvl1Name = categoryLvl1Name;
	}
	public long getCategoryLvl1Cnt() {
		return categoryLvl1Cnt;
	}
	public void setCategoryLvl1Cnt(long categoryLvl1Cnt) {
		this.categoryLvl1Cnt = categoryLvl1Cnt;
	}
	public Collection getCategoryLvl2List() {
		return categoryLvl2List;
	}
	public void setCategoryLvl2List(Collection categoryLvl2List) {
		this.categoryLvl2List = categoryLvl2List;
	}
	
	public String getCategoryLvl1Desc() {
		return categoryLvl1Desc;
	}
	public void setCategoryLvl1Desc(String categoryLvl1Desc) {
		this.categoryLvl1Desc = categoryLvl1Desc;
	}
	@Override
	public String toString() {
		return "OrderFlowModel [categoryLvl1Name=" + categoryLvl1Name + ", categoryLvl1Cnt=" + categoryLvl1Cnt
				+ ", categoryLvl2List=" + categoryLvl2List + "]";
	}
	
	
	
}
