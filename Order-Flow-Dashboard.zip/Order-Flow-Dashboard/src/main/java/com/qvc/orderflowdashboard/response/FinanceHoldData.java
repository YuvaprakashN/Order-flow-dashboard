package com.qvc.orderflowdashboard.response;

import java.util.List;

import com.qvc.orderflowdashboard.entity.OrderStatusCountModel;

public class FinanceHoldData{
	private List<OrderStatusCountModel> financeHold;
	private String colorFlag;
	public List<OrderStatusCountModel> getFinanceHold() {
		return financeHold;
	}
	public void setFinanceHold(List<OrderStatusCountModel> financeHold) {
		this.financeHold = financeHold;
	}
	public String getColorFlag() {
		return colorFlag;
	}
	public void setColorFlag(String colorFlag) {
		this.colorFlag = colorFlag;
	}
	@Override
	public String toString() {
		return "financeHoldData [financeHold=" + financeHold + ", colorFlag=" + colorFlag + "]";
	}
	
}