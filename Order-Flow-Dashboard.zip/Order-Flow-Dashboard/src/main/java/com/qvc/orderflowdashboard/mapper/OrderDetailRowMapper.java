package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.model.BaseOrderDetail;

public class OrderDetailRowMapper implements RowMapper<BaseOrderDetail> {
	public BaseOrderDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
		BaseOrderDetail orderDetailsModel = new BaseOrderDetail();
		try {

			orderDetailsModel.setOrderNumber(rs.getString("ORD_NBR"));

		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

		return orderDetailsModel;
	}

}
