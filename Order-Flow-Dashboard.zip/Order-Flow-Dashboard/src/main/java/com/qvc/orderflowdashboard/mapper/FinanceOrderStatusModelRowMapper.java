package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.FinanceOrderStatusModel;
import com.qvc.orderflowdashboard.entity.CellDataPoint;

public class FinanceOrderStatusModelRowMapper implements RowMapper<FinanceOrderStatusModel> {

	public FinanceOrderStatusModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		System.out.println("Fnance Order Status model row mapper");
		FinanceOrderStatusModel orderStatusModel = new FinanceOrderStatusModel();
		try {

			orderStatusModel.setStatusId(rs.getBigDecimal("ORD_FLOW_STAT_ID"));

			orderStatusModel.setTotalOrders(rs.getBigDecimal("TOTAL_Orders"));

			orderStatusModel.setBusnActyTypDsc(rs.getString("busn_acty_typ_dsc").trim());
			orderStatusModel.setOrdFlowRsnDsc(rs.getString("ord_flow_rsn_dsc").trim());
			orderStatusModel.setOrdFlowStatDsc(rs.getString("ord_flow_stat_dsc").trim());
			orderStatusModel.setOrdFlowSumDsc(rs.getString("ord_flow_sum_dsc").trim());
			orderStatusModel.setService(rs.getString("busn_proc_typ_dsc").trim());

			orderStatusModel.setLst1Hour(new CellDataPoint(rs.getBigDecimal("LST_1_HRS")));
			orderStatusModel.setLst1To24Hour(new CellDataPoint(rs.getBigDecimal("LST_1_TO_24_HRS")));
			orderStatusModel.setLst24To48Hour(new CellDataPoint(rs.getBigDecimal("LST_24_TO_48_HRS")));
			orderStatusModel.setLst48To72Hour(new CellDataPoint(rs.getBigDecimal("LST_48_TO_72_HRS")));
			orderStatusModel.setAbv72Hour(new CellDataPoint(rs.getBigDecimal("GT_72_HRS")));
			orderStatusModel.setTotalOrders(rs.getBigDecimal("TOTAL_Orders"));

		} catch (Exception e) {
			System.out.println("Fnance Order Status model row mapper error" + e.getMessage());
			System.out.println(e);
		}
		System.out.println(orderStatusModel);
		return orderStatusModel;
	}

}
