package com.qvc.orderflowdashboard.dao;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.qvc.orderflowdashboard.model.BaseOrderDetail;
import com.qvc.orderflowdashboard.model.FinanceOrderDetail;
import com.qvc.orderflowdashboard.mapper.DMOrderDetailsModelRowMapper;
import com.qvc.orderflowdashboard.mapper.FinanceHoldChartRowMapper;
import com.qvc.orderflowdashboard.mapper.FinanceOrderDetailsModelRowMapper;
import com.qvc.orderflowdashboard.mapper.FinanceOrderStatusModelRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderFlowStatVWModelRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderDetailsModelRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderFlowRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderStatusModelRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderStatusRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderStuckRowMapper;
import com.qvc.orderflowdashboard.mapper.PackageDetailsRowMapper;
import com.qvc.orderflowdashboard.mapper.PackageNotCreatedRowMapper;
import com.qvc.orderflowdashboard.mapper.PackageStatusModelRowMapper;
import com.qvc.orderflowdashboard.mapper.WarehousePackageCountRowMapper;
import com.qvc.orderflowdashboard.mapper.finance.FinanceOrderDetailRowMapper;
import com.qvc.orderflowdashboard.entity.FinanceOrderDetailsModel;
import com.qvc.orderflowdashboard.entity.FinanceOrderStatusModel;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowEntity;
import com.qvc.orderflowdashboard.entity.OrderStatusCountModel;
import com.qvc.orderflowdashboard.entity.OrderStatusModel;
import com.qvc.orderflowdashboard.entity.OrderStuck;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;
import com.qvc.orderflowdashboard.entity.PackageNotCreated;
import com.qvc.orderflowdashboard.entity.PackageStatusModel;
import com.qvc.orderflowdashboard.entity.WarehousePackageCountModel;
import com.qvc.orderflowdashboard.vo.FinanceHoldChartData;

@Repository
public class DemandFulfillmentDAOImpl {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(DemandFulfillmentDAOImpl.class);
	private static final String COLUMN_REPLACE_CONST = "$COLUMN$";

	private static final String DATE_FORMAT = "E yyyy.MM.dd 'at' hh:mm:ss a zzz";

	@Autowired
	 @Qualifier("jdbcTemplate1")
	 private JdbcTemplate jdbcTemplate;
	 
	/* @Autowired
	 @Qualifier("jdbcTemplate2")
	 private JdbcTemplate jdbcTemplate2;*/

	String orderFlowQuery = "SELECT CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK' WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END WAREHOUSE, A.ORD_FLOW_STAT_ID, SUM(CASE WHEN DURATION_IN_HRS < 1 THEN NO_OF_PKGS ELSE 0 END) HRS_LT1_PKGS, SUM(CASE WHEN DURATION_IN_HRS >= 1 AND DURATION_IN_HRS < 3 THEN NO_OF_PKGS ELSE 0 END) HRS_1TO3_PKGS, SUM(CASE WHEN DURATION_IN_HRS >= 3 AND DURATION_IN_HRS < 6 THEN NO_OF_PKGS ELSE 0 END) HRS_3TO6_PKGS, SUM(CASE WHEN DURATION_IN_HRS >= 6 AND DURATION_IN_HRS < 24 THEN NO_OF_PKGS ELSE 0 END) HRS_6TO24_PKGS, SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_PKGS ELSE 0 END) HRS_24TO_48_PKGS, SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_PKGS ELSE 0 END) HRS_48TO_72_PKGS, SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_PKGS ELSE 0 END) HRS_GT72_PKGS, SUM(NO_OF_PKGS) as TOTAL_PKGS FROM ( SELECT AP.DC_PARTN_NBR, AP.ORD_FLOW_STAT_ID, DATEDIFF(hour,AP.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_PKGS FROM Q.ACTV_PKG AP WHERE AP.ORD_FLOW_STAT_ID IN (630000, 670000, 680000,780000,790000,725000,725100) AND AP.DC_PARTN_NBR IN (0, 1, 5, 6,9) GROUP BY AP.DC_PARTN_NBR, AP.ORD_FLOW_STAT_ID,DATEDIFF(hour,AP.STAT_EFF_TMS,CURRENT_TIMESTAMP) ) A GROUP BY CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK' WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END , A.ORD_FLOW_STAT_ID order by WAREHOUSE, A.ORD_FLOW_STAT_ID;";
	String packageNotCreated = "SELECT   ORD_NBR,ORD_LN_NBR,ACCT_NBR,ORD_FLOW_STAT_ID,ORDERLINE_QTY, ORD_DT FROM q.active_ord_ln aol WHERE    aol.ORD_FLOW_STAT_ID = '500000' AND      ORD_DT > '2020-01-01' AND      STAT_EFF_TMS < current timestamp - 24 hours AND not exists (select * from q.package_ol_rel por where por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR)";

	String packageNotCreatedSQL = "SELECT   ORD_NBR,ORD_LN_NBR,ACCT_NBR,ORD_FLOW_STAT_ID,ORDERLINE_QTY,ORD_DT FROM q.active_ord_ln aol WHERE    aol.ORD_FLOW_STAT_ID = '500000' AND      ORD_DT > '2022-01-01' AND      STAT_EFF_TMS < DATEADD(hh, -24, GETDATE()) AND      not exists (select * from q.package_ol_rel por where por.ORD_NBR = aol.ORD_NBR      AND por.ORD_LN_NBR = AOL.ORD_LN_NBR)";
	String orderStuckQuery = "SELECT aol.ORD_NBR,aol.ORD_LN_NBR,aol.ORD_FLOW_STAT_ID,aol.ITEM_NBR,aol.COLOR_NBR,aol.SIZE_NBR,aol.ORD_DT,ap.PKG_ID,ap.ORD_FLOW_STAT_ID PKG_ORD_FLOW_STAT_ID,ap.INVC_NBR,ap.BOX_NBR,ap.LAST_UPD_TMS,ap.DC_PARTN_NBR,dc.DC_ID,dc.LEGACY_WHSE_NBR,dc.DC_TRANS_CONFG_CD,dc.DC_DSC FROM q.active_ord_ln aol,Q.ACTV_PKG Ap,q.package_ol_rel por,q.DIST_CTR dc WHERE por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR AND ap.PKG_ID =por.PKG_ID AND ap.ORD_FLOW_STAT_ID = ? AND ap.DC_PARTN_NBR != 0 and ap.LAST_UPD_TMS < ? and aol.ITEM_NBR !='R9806' and aol.ORD_DT > '2016-01-01' AND ap.ACTV_IND = 'Y' and ap.SRCED_DC_ID=dc.DC_ID with UR";
	String q = "SELECT aol.ORD_NBR, aol.ORD_LN_NBR, aol.ORD_FLOW_STAT_ID, aol.ITEM_NBR, aol.COLOR_NBR, aol.SIZE_NBR, aol.ORD_DT, ap.PKG_ID, ap.ORD_FLOW_STAT_ID PKG_ORD_FLOW_STAT_ID, ap.INVC_NBR, ap.BOX_NBR,ap.LAST_UPD_TMS,ap.DC_PARTN_NBR,dc.DC_ID,dc.LEGACY_WHSE_NBR,dc.DC_TRANS_CONFG_CD,dc.DC_DSC FROM q.active_ord_ln aol, Q.ACTV_PKG Ap, q.package_ol_rel por,q.DIST_CTR dc WHERE por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR AND ap.PKG_ID =por.PKG_ID AND ap.ORD_FLOW_STAT_ID =? AND ap.DC_PARTN_NBR != 0 and ap.LAST_UPD_TMS < ? and aol.ITEM_NBR !='R9806' and aol.ORD_DT > '2016-01-01' AND ap.ACTV_IND = 'Y' and ap.SRCED_DC_ID=dc.DC_ID  fetch first 200 rows only with UR";

	String sql = "SELECT aol.ORD_NBR, aol.ORD_LN_NBR, aol.ORD_FLOW_STAT_ID, aol.ITEM_NBR, aol.COLOR_NBR, aol.SIZE_NBR, aol.ORD_DT, ap.PKG_ID, ap.ORD_FLOW_STAT_ID PKG_ORD_FLOW_STAT_ID, ap.INVC_NBR, ap.BOX_NBR,ap.LAST_UPD_TMS,ap.DC_PARTN_NBR,dc.DC_ID,dc.LEGACY_WHSE_NBR,dc.DC_TRANS_CONFG_CD,dc.DC_DSC FROM q.active_ord_ln aol, Q.ACTV_PKG Ap, q.package_ol_rel por,q.DIST_CTR dc WHERE por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR AND ap.PKG_ID =por.PKG_ID AND ap.ORD_FLOW_STAT_ID =? AND ap.DC_PARTN_NBR != 0 and ap.LAST_UPD_TMS < ? and aol.ITEM_NBR !='R9806' and aol.ORD_DT > '2016-01-01' AND ap.ACTV_IND = 'Y' and ap.SRCED_DC_ID=dc.DC_ID";

	public List<OrderFlowEntity> flowEntities() {
		return null;
	}

	@SuppressWarnings("deprecation")
	public List<OrderStuck> orderStuck(String orderFlowId, Date lastUpdateTime) {
		List<OrderStuck> orderStuck = new ArrayList<>();
		try {
			orderStuck = jdbcTemplate.query(sql, new Object[] { orderFlowId, lastUpdateTime },
					new OrderStuckRowMapper());
		} catch (Exception e) {
			log.error("Exception in orderStuck ::::" + e);
		}
		return orderStuck;
	}

	@SuppressWarnings("deprecation")
	public List<PackageNotCreated> packageNotCreated() {
		List<PackageNotCreated> packageNotCreateds = new ArrayList<>();
		try {
			packageNotCreateds = jdbcTemplate.query(packageNotCreatedSQL, new PackageNotCreatedRowMapper());
		} catch (Exception e) {
			log.error("Exception in packageNotCreated ::::" + e);
		}
		return packageNotCreateds;
	}

	@Value("${colorFlag.red}")
	private String colorFlagRed = "'#EC7063'";
	@Value("${colorFlag.yellow}")
	private String colorFlagYellow = "'#F4d03F'";
	@Value("${colorFlag.green}")
	private String colorFlagGreen = "'#58D68D'";
	public final String colorCodeSelection = "CASE WHEN count(*) > ? THEN " + colorFlagRed + " WHEN count(*) > ? THEN "
			+ colorFlagYellow + " ELSE " + colorFlagGreen + " END AS arrowColor ";
	public final String warehouseNaming = " CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK'  WHEN A.DC_PARTN_NBR = 3 THEN 'LANCASTER'  WHEN A.DC_PARTN_NBR = 4 THEN 'ROCKY' WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END  ";
	public final String orderSelectionQuery = "select aol.ord_flow_stat_id,count(*) as count ,"// + colorCodeSelection
			//+ ","
			+ "c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc  from q.active_ord_ln aol LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd   ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id 	 LEFT OUTER JOIN Q.ord_flow_stat b  ON aol.ord_flow_stat_id = b.ord_flow_stat_id               LEFT OUTER JOIN Q.busn_proc_typ bpt  ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd  LEFT OUTER JOIN Q.busn_acty_typ bat  ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd  AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd  LEFT OUTER JOIN Q.ord_flow_sum_typ AS c  ON b.ord_flow_sum_cd = c.ord_flow_sum_cd  LEFT OUTER JOIN Q.ord_flow_rsn_typ d   ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd ";
	public final String orderGroupByQuery = " AND ofsd.stat_viewer_id = 100 group by aol.ord_flow_stat_id,c.ord_flow_sum_dsc,bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc;  ";

	public final String ordersInFinanceHoldWhereQueryCount = " where aol.ORD_FLOW_STAT_ID in (320000,340000) ";
	public final String ordersInDMEventRetreivereQueryCount = " where aol.ord_flow_stat_id in (select ord_flow_stat_id from q.ord_flow_stat_attr where ORD_FLOW_ATTR_CD = 'DMEVN') and  ord_evnt_typ_cd in ('INVRL', 'ADTSV', 'ICXBO','DCXBO','UNPIK','DLPRD','CNCL','DCXWL','CX','DLSGZ','DLSRC','DLVEN','DLZIP','ICXWL') and EVENT_TMS < dateadd(hour,-4,current_timestamp)  and aol.ord_dt > '2022-01-01' ";

	public final String count = "count(*) as count";
	public final String demandFulfilmentQuery = "select " + warehouseNaming + "WAREHOUSE, " + count + ", "
			+ colorCodeSelection
			+ " from q.ACTV_PKG a where a.ord_flow_stat_id in ('630000','670000','680000','7250000','7215000') and a.actv_ind='Y' group by "
			+ warehouseNaming + " order by warehouse;";
	

	
	public final String financeHoldInMinutes="SELECT   A.ORD_FLOW_STAT_ID,\r\n" + 
			"trim(a.ord_flow_sum_dsc) as ord_flow_sum_dsc,\r\n" + 
			"trim(a.busn_proc_typ_dsc) as busn_proc_typ_dsc, \r\n" + 
			"trim(a.busn_acty_typ_dsc) as busn_acty_typ_dsc,\r\n" + 
			"trim(a.ord_flow_rsn_dsc) as ord_flow_rsn_dsc,\r\n" + 
			"trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc,\r\n" + 
			"SUM(CASE WHEN DURATION_IN_MINUTS < 2 THEN NO_OF_ORDERS ELSE 0 END) LST_2_MINUTS_ORDS,\r\n" + 
			"SUM(CASE WHEN DURATION_IN_MINUTS >= 2 AND DURATION_IN_MINUTS < 5 THEN NO_OF_ORDERS ELSE 0 END) LST_2TO5_MINUTS,\r\n" + 
			"SUM(CASE WHEN DURATION_IN_MINUTS >= 5 THEN NO_OF_ORDERS ELSE 0 END) GT_5_MINUTS,\r\n" + 
			"SUM(NO_OF_ORDERS) as TOTAL_Orders\r\n" + 
			"FROM     ( select aol.ord_flow_stat_id, DATEDIFF(minute,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_MINUTS, COUNT(*) NO_OF_ORDERS, c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from q.active_ord_ln aol \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat b ON aol.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.busn_proc_typ bpt ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.busn_acty_typ bat ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd where aol.ORD_FLOW_STAT_ID in (320000,340000)\r\n" + 
			"AND ofsd.stat_viewer_id = 100 \r\n" + 
			"group by aol.ord_flow_stat_id, c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc,DATEDIFF(minute,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)) a\r\n" + 
			"GROUP BY A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc, a.busn_proc_typ_dsc, \r\n" + 
			"a.busn_acty_typ_dsc, a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;";
	
	public final String financeOrderReleaseInHours="SELECT   A.ORD_FLOW_STAT_ID,\r\n" + 
			"trim(a.ord_flow_sum_dsc) as ord_flow_sum_dsc,\r\n" + 
			"trim(a.busn_proc_typ_dsc) as busn_proc_typ_dsc, \r\n" + 
			"trim(a.busn_acty_typ_dsc) as busn_acty_typ_dsc,\r\n" + 
			"trim(a.ord_flow_rsn_dsc) as ord_flow_rsn_dsc,\r\n" + 
			"trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc,\r\n" + 
"SUM(CASE WHEN DURATION_IN_HRS < 1 THEN NO_OF_ORDERS ELSE 0 END) LST_1_HRS,\r\n" + 
"SUM(CASE WHEN DURATION_IN_HRS >= 1 AND DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) LST_1_TO_24_HRS,\r\n" + 
"SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) LST_24_TO_48_HRS,\r\n" + 
"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_ORDERS ELSE 0 END) LST_48_TO_72_HRS,\r\n" + 
"SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) GT_72_HRS," + 
			"SUM(NO_OF_ORDERS) as TOTAL_Orders\r\n" + 
			"FROM     ( select aol.ord_flow_stat_id, DATEDIFF(HOUR,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS, c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from q.active_ord_ln aol \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat b ON aol.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.busn_proc_typ bpt ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.busn_acty_typ bat ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd where aol.ORD_FLOW_STAT_ID in (340000)\r\n" + 
			"AND ofsd.stat_viewer_id = 100 and aol.LAST_UPD_TMS>= dateadd(day,-365,current_timestamp)\r\n" + 
			"group by aol.ord_flow_stat_id, c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc,DATEDIFF(HOUR,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)) a\r\n" + 
			"GROUP BY A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc, a.busn_proc_typ_dsc, \r\n" + 
			"a.busn_acty_typ_dsc, a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;";
	
	
	 
	public final String financeHoldInHours = "select A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc as STATUS_NAME, CASE WHEN SUM(NO_OF_ORDERS) > ? THEN "
			+ colorFlagRed + " WHEN SUM(NO_OF_ORDERS) > ? THEN " + colorFlagYellow + " ELSE " + colorFlagGreen
			+ " END AS arrowColor, SUM(CASE WHEN DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) HRS_LT24_ORDS, SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) HRS_24TO48_ORDS, SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_GT72_ORDS, SUM(NO_OF_ORDERS) as TOTAL_Orders FROM ( select aol.ord_flow_stat_id, DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS, c.ord_flow_sum_dsc from q.active_ord_ln aol LEFT OUTER JOIN Q.ord_flow_stat b ON aol.ord_flow_stat_id = b.ord_flow_stat_id LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd where aol.ORD_FLOW_STAT_ID in (320000,340000) group by aol.ord_flow_stat_id,c.ord_flow_sum_dsc,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)) a group by A.ORD_FLOW_STAT_ID,a.ord_flow_sum_dsc;";

	public final String financeHoldStuckOrderDetails="SELECT    aol.ORD_NBR,aol.ORD_LN_NBR, aol.STAT_EFF_TMS,  aol.LAST_UPD_TMS as aol_LAST_UPD_TMS, aol.LAST_UPD_TMS as ol_LAST_UPD_TMS,aol.ORD_FLOW_STAT_ID as ol_ORD_FLOW_STAT_ID,aol.ORD_FLOW_STAT_ID as aol_ORD_FLOW_STAT_ID\r\n" + 
			"			FROM     q.active_ord_ln aol with (nolock) \r\n" + 
			"			         join q.ORD_LN_STAT_HIST olh with (nolock) on aol.ORD_NBR=olh.ORD_NBR and aol.ORD_LN_NBR=olh.ORD_LN_NBR\r\n" + 
			"			WHERE    aol.ord_flow_stat_id='320000' \r\n" + 
			"			AND      olh.ord_flow_stat_id='320000'\r\n" + 
			"			AND      olh.INSRT_TMS>=? \r\n" + 
			"			AND      olh.INSRT_TMS<=? ;" ;
	
	
	public String financeHoldStuckOrderDetailsFinal="SELECT    aol.ORD_NBR,aol.ORD_LN_NBR, aol.STAT_EFF_TMS,  aol.LAST_UPD_TMS as aol_LAST_UPD_TMS, aol.LAST_UPD_TMS as ol_LAST_UPD_TMS,aol.ORD_FLOW_STAT_ID as ol_ORD_FLOW_STAT_ID,aol.ORD_FLOW_STAT_ID as aol_ORD_FLOW_STAT_ID\r\n" + 
			"			FROM     q.active_ord_ln aol with (nolock) \r\n" + 
			"			         join q.ORD_LN_STAT_HIST olh with (nolock) on aol.ORD_NBR=olh.ORD_NBR and aol.ORD_LN_NBR=olh.ORD_LN_NBR\r\n" + 
			"			WHERE    aol.ord_flow_stat_id='320000' \r\n" + 
			"			AND      olh.ord_flow_stat_id='320000'\r\n" + 
			"			AND      aol.ord_nbr in ($orders$);" ;
	
	public final String financeHoldStuckOrderOutflowflowDetails="SELECT    aol.ORD_NBR,aol.ORD_LN_NBR, aol.STAT_EFF_TMS,  aol.LAST_UPD_TMS as aol_LAST_UPD_TMS, aol.LAST_UPD_TMS as ol_LAST_UPD_TMS,aol.ORD_FLOW_STAT_ID as ol_ORD_FLOW_STAT_ID,aol.ORD_FLOW_STAT_ID as aol_ORD_FLOW_STAT_ID\r\n" + 
			"			FROM     q.active_ord_ln aol with (nolock) \r\n" + 
			"			         join q.ORD_LN_STAT_HIST olh with (nolock) on aol.ORD_NBR=olh.ORD_NBR and aol.ORD_LN_NBR=olh.ORD_LN_NBR\r\n" + 
			"			WHERE    aol.ord_flow_stat_id<>'320000' \r\n" + 
			"			AND      olh.ord_flow_stat_id='320000'\r\n" + 
			"			AND      olh.INSRT_TMS>=? \r\n" + 
			"			AND      olh.INSRT_TMS<=? ;" ;
	
	
	public final String financeOutflowOrderQuery="SELECT    ol.ORD_NBR,\r\n" + 
			"         ol.ORD_LN_NBR,\r\n" + 
			"         ol.MBR_NBR,\r\n" + 
			"         ol.SKN_ID,\r\n" + 
			"         ol.LAST_UPD_TMS, olh.INSRT_TMS,\r\n" + 
			"         ol.ORDER_DATE,\r\n" + 
			"         ol.SHP_BY_DT,\r\n" + 
			"         ol.CURR_EST_DELVRY_DT,\r\n" + 
			"ol.ord_flow_stat_id,\r\n" + 
			"c.ord_flow_sum_dsc\r\n" + 
			", ofsd.ord_flow_stat_dsc\r\n" + 
			"FROM     qord.ordmline ol with (nolock) \r\n" + 
			"          join q.ORD_LN_STAT_HIST olh with (nolock) on ol.ORD_NBR=olh.ORD_NBR and ol.ORD_LN_NBR=olh.ORD_LN_NBR \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON ol.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat b with (nolock) ON ol.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_sum_typ AS c with (nolock) ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"         \r\n" + 
			"WHERE    ol.ord_flow_stat_id not in ('340000','320000')\r\n" + 
			"AND      olh.ord_flow_stat_id='320000'\r\n" + 
			"AND	  ofsd.stat_viewer_id = 100\r\n" + 
			"AND      olh.INSRT_TMS>= ?\r\n" + 
			"AND      olh.INSRT_TMS<= ?;" ;
	
	public final String financeInflowOrderQuery="SELECT    ol.ORD_NBR,\r\n" + 
			"         ol.ORD_LN_NBR,\r\n" + 
			"         ol.MBR_NBR,\r\n" + 
			"         ol.SKN_ID,\r\n" + 
			"         ol.LAST_UPD_TMS, olh.INSRT_TMS,\r\n" + 
			"         ol.ORDER_DATE,\r\n" + 
			"         ol.SHP_BY_DT,\r\n" + 
			"         ol.CURR_EST_DELVRY_DT,\r\n" + 
			"ol.ord_flow_stat_id,\r\n" + 
			"c.ord_flow_sum_dsc\r\n" + 
			", ofsd.ord_flow_stat_dsc\r\n" + 
			"FROM     qord.ordmline ol with (nolock) \r\n" + 
			"          join q.ORD_LN_STAT_HIST olh with (nolock) on ol.ORD_NBR=olh.ORD_NBR and ol.ORD_LN_NBR=olh.ORD_LN_NBR \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON ol.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat b with (nolock) ON ol.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_sum_typ AS c with (nolock) ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"         \r\n" + 
			"WHERE    olh.ord_flow_stat_id='320000'\r\n" + 
			"AND	  ofsd.stat_viewer_id = 100\r\n" + 
			"AND      olh.INSRT_TMS>= ?\r\n" + 
			"AND      olh.INSRT_TMS<= ?;" ;
	
	
	public final String financeReleasedOrderQuery="SELECT    ol.ORD_NBR,\r\n" + 
			"         ol.ORD_LN_NBR,\r\n" + 
			"         ol.MBR_NBR,\r\n" + 
			"         ol.SKN_ID,\r\n" + 
			"         ol.LAST_UPD_TMS, olh.INSRT_TMS,\r\n" + 
			"         ol.ORDER_DATE,\r\n" + 
			"         ol.SHP_BY_DT,\r\n" + 
			"         ol.CURR_EST_DELVRY_DT,\r\n" + 
			"ol.ord_flow_stat_id,\r\n" + 
			"c.ord_flow_sum_dsc\r\n" + 
			", ofsd.ord_flow_stat_dsc\r\n" + 
			"FROM     qord.ordmline ol with (nolock) \r\n" + 
			"          join q.ORD_LN_STAT_HIST olh with (nolock) on ol.ORD_NBR=olh.ORD_NBR and ol.ORD_LN_NBR=olh.ORD_LN_NBR \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON ol.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat b with (nolock) ON ol.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_sum_typ AS c with (nolock) ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"         \r\n" + 
			"WHERE    olh.ord_flow_stat_id='340000'\r\n" + 
			"AND	  ofsd.stat_viewer_id = 100\r\n" + 
			"AND      olh.INSRT_TMS>= ?\r\n" + 
			"AND      olh.INSRT_TMS<= ?;" ;
	
	
	public final String financeOrderReleaseDetails="SELECT    olh.ORD_NBR,aol.ORD_LN_NBR, olh.STAT_EFF_TMS,  olh.LAST_UPD_TMS as aol_LAST_UPD_TMS, olh.LAST_UPD_TMS as ol_LAST_UPD_TMS,olh.ORD_FLOW_STAT_ID as ol_ORD_FLOW_STAT_ID,olh.ORD_FLOW_STAT_ID as aol_ORD_FLOW_STAT_ID\r\n" + 
			"			FROM     q.ORD_LN_STAT_HIST olh with (nolock) " + 
			"			WHERE        olh.ord_flow_stat_id='340000'\r\n" + 
			"			AND      olh.INSRT_TMS>=? \r\n" + 
			"			AND      olh.INSRT_TMS<=? ;" ;
	
	//DASHBOARD FINANCE RELEASED PIECHART QUERY
	public final String financeReleasedOrderChart="select  COUNT(*) AS NO_OF_ORDERS from q.active_ord_ln aol \r\n" + 
			
			" where aol.ORD_FLOW_STAT_ID in (340000) and aol.STAT_EFF_TMS>=dateadd(day,-365,current_timestamp) ;";
	
	
	public final String financeHoldOrderChart="\r\n" + 
			"select count(*)\r\n" + 
			"FROM     q.ACTIVE_ORD_LN aol \r\n" + 
			"         inner join qord.ordmline ol on aol.ORD_NBR = ol.ord_nbr and aol.ORD_LN_NBR = ol.ord_ln_nbr\r\n" + 
			"WHERE    aol.ORD_FLOW_STAT_ID in (3175500, 320000)\r\n" + 
			"AND      aol.STAT_EFF_TMS >= dateadd(day,-365,current_timestamp)\r\n" + 
			"AND      ol.ORD_FLOW_STAT_ID = 320000";
	
	
	
	
	
	
	
	//DASHBOARD FINANCE hold PIECHART QUERY
	public final String financeHoldStuckOrderChart="SELECT   ol.ORD_NBR,\r\n" + 
			"         ol.ORD_LN_NBR,\r\n" + 
			"         aol.STAT_EFF_TMS,  aol.LAST_UPD_TMS as aol_LAST_UPD_TMS, ol.LAST_UPD_TMS as ol_LAST_UPD_TMS,"
			+ "ol.ORD_FLOW_STAT_ID as ol_ORD_FLOW_STAT_ID,aol.ORD_FLOW_STAT_ID as aol_ORD_FLOW_STAT_ID \r\n" + 
			"FROM     q.ACTIVE_ORD_LN aol \r\n" + 
			"         inner join qord.ordmline ol on aol.ORD_NBR = ol.ord_nbr and aol.ORD_LN_NBR = ol.ord_ln_nbr\r\n" + 
			"WHERE    aol.ORD_FLOW_STAT_ID in (3175500, 320000)\r\n" + 
			"AND      aol.STAT_EFF_TMS >= ?\r\n" + 
			"AND      ol.ORD_FLOW_STAT_ID = 320000" 			;
	
	public final String financeHoldStuckOrders="SELECT   ol.ORDER_DATE,\r\n" + 
			"         ol.ORD_NBR,\r\n" + 
			"         ol.ORD_LN_NBR,\r\n" + 
			"         ol.LN_STAT_CD,\r\n" + 
			"         ol.ORD_FLOW_STAT_ID as OL_STATUS,\r\n" + 
			"         aol.ORD_FLOW_STAT_ID as AOL_STATUS,\r\n" + 
			"         p.BILLED_AMT,\r\n" + 
			"         p.BILLED_TMS,\r\n" + 
			"         p.PAYMT_BILLSTAT_CD,\r\n" + 
			"         p.FUND_TRANSFER_ID\r\n" + 
			"FROM     Qord.ordmline ol with (nolock) \r\n" + 
			"         inner join q.active_ord_ln aol with (nolock) on ol.ord_nbr=aol.ord_nbr and ol.ord_ln_nbr=aol.ord_ln_nbr \r\n" + 
			"         inner join q.PAYMT p with (nolock) on ol.ORD_NBR=p.ORD_NBR and ol.ord_ln_nbr=p.ORD_LN_NBR\r\n" + 
			"WHERE    aol.ORD_FLOW_STAT_ID<>ol.ORD_FLOW_STAT_ID\r\n" + 
			"AND      ol.ORDER_DATE>'2022-05-01'\r\n" + 
			"AND      p.BILLED_TMS< dateadd(dd, -3, getdate())\r\n" + 
			"AND      (p.FUND_TRANSFER_ID is not null\r\n" + 
			"     OR  p.FUND_TRANSFER_ID <>0)\r\n" + 
			"AND      p.PAYMT_BILLSTAT_CD in ('AC','BC')\r\n" + 
			"AND      not exists (select * from Q.PACKAGE_OL_REL por where por.ORD_NBR=ol.ORD_NBR\r\n" + 
			"     AND por.ORD_LN_NBR=ol.ORD_LN_NBR)\r\n" + 
			"ORDER BY p.BILLED_TMS desc;";
	
	
	//aVAIL
	public final String demandManagementStuckOrderInHoursQuery="\r\n" + 
		"SELECT   A.ORD_FLOW_STAT_ID, \r\n" + 
		"			       \r\n" + 
		"			         trim(a.ord_flow_sum_dsc) as STATUS_NAME, \r\n" + 
		"			         trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc, \r\n" + 
		"			         \r\n" + 
		"			         SUM(CASE WHEN DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) HRS_LT24_ORDS, \r\n" + 
		"			         SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) HRS_24TO48_ORDS,\r\n" + 
		"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_48TO72_ORDS,\r\n" + 
		"			         SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_GT72_ORDS, \r\n" + 
		"			         SUM(CASE WHEN DURATION_IN_HRS IS NOT NULL THEN  NO_OF_ORDERS ELSE 0 END) as TOTAL_Orders \r\n" + 
		"			FROM     ( \r\n" + 
		"			 \r\n" + 
		"			select ofsd.ord_flow_stat_id, c.ord_flow_sum_dsc,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from Q.ord_flow_stat_dsc ofsd   \r\n" + 
		"			         LEFT OUTER JOIN q.active_ord_ln aol ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id  \r\n" + 
		"			         LEFT OUTER JOIN Q.ord_flow_stat b ON ofsd.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
		"			        \r\n" + 
		"			         LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd "
		+ "LEFT OUTER JOIN Q.ord_flow_sum_typ AS c  ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
		"\r\n" + 
		"where ofsd.ORD_FLOW_STAT_ID in  ('500000','500010','500020','500500' )\r\n" + 
		"			AND ofsd.stat_viewer_id = 100 \r\n" + 
		"AND ofsd.ord_flow_stat_id in (500000,500010,500020,500500) and  aol.last_upd_tms <=dateadd(hour,08,current_timestamp)\r\n" + 
		"and not exists (select * from q.package_ol_rel por where por.ord_nbr=aol.ord_nbr and por.ord_ln_nbr = aol.ord_ln_nbr)\r\n" + 
		"   \r\n" + 
		"			group by ofsd.ord_flow_stat_id,c.ord_flow_sum_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc ,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP) \r\n" + 
		"			 \r\n" + 
		"			) a \r\n" + 
		"			GROUP BY A.ORD_FLOW_STAT_ID,a.ord_flow_sum_dsc,  a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;";
	
	public final String demandManagementRealInventoryHoldInHoursQuery =
				"\r\n" + 
				"SELECT   A.ORD_FLOW_STAT_ID, \r\n" + 
				"			       \r\n" + 
				"			         trim(a.ord_flow_rsn_dsc) as STATUS_NAME, \r\n" + 
				"			         trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc, \r\n" + 
				"			         \r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) HRS_LT24_ORDS, \r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) HRS_24TO48_ORDS,\r\n" + 
				"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_48TO72_ORDS,\r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_GT72_ORDS, \r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS IS NOT NULL THEN  NO_OF_ORDERS ELSE 0 END) as TOTAL_Orders \r\n" + 
				"			FROM     ( \r\n" + 
				"			 \r\n" + 
				"			select ofsd.ord_flow_stat_id, DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from Q.ord_flow_stat_dsc ofsd   \r\n" + 
				"			         LEFT OUTER JOIN q.active_ord_ln aol ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id  \r\n" + 
				"			         LEFT OUTER JOIN Q.ord_flow_stat b ON ofsd.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
				"			        \r\n" + 
				"			         LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd where ofsd.ORD_FLOW_STAT_ID in  ('460000','470000','3175500','3178000','380000','390000','490000' )\r\n" + 
				"			AND ofsd.stat_viewer_id = 100 \r\n" + 
				"   \r\n" + 
				"			group by ofsd.ord_flow_stat_id, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc ,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP) \r\n" + 
				"			 \r\n" + 
				"			) a \r\n" + 
				"			GROUP BY A.ORD_FLOW_STAT_ID,  a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"";
	
	public final String demandManagementNoInventoryInHoursQuery =
				"\r\n" + 
				"SELECT   A.ORD_FLOW_STAT_ID, \r\n" + 
				"			       \r\n" + 
				"			         trim(a.ord_flow_rsn_dsc) as STATUS_NAME, \r\n" + 
				"			         trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc, \r\n" + 
				"			         \r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) HRS_LT24_ORDS, \r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) HRS_24TO48_ORDS,\r\n" + 
				"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_48TO72_ORDS,\r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_GT72_ORDS, \r\n" + 
				"			         SUM(CASE WHEN DURATION_IN_HRS IS NOT NULL THEN  NO_OF_ORDERS ELSE 0 END) as TOTAL_Orders \r\n" + 
				"			FROM     ( \r\n" + 
				"			 \r\n" + 
				"			select ofsd.ord_flow_stat_id, DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from Q.ord_flow_stat_dsc ofsd   \r\n" + 
				"			         LEFT OUTER JOIN q.active_ord_ln aol ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id  \r\n" + 
				"			         LEFT OUTER JOIN Q.ord_flow_stat b ON ofsd.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
				"			        \r\n" + 
				"			         LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd where ofsd.ORD_FLOW_STAT_ID in  ('410000','420000','400000','3150000','430000','3160000' )\r\n" + 
				"			AND ofsd.stat_viewer_id = 100 \r\n" + 
				"   \r\n" + 
				"			group by ofsd.ord_flow_stat_id, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc ,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP) \r\n" + 
				"			 \r\n" + 
				"			) a \r\n" + 
				"			GROUP BY A.ORD_FLOW_STAT_ID,  a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"";
	
	
	public final String demandFulfilmentInHours = "\r\n" + 		//AVAIL
			"\r\n" + 
			"SELECT \r\n" + 
			"CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END as WAREHOUSE, \r\n" +
			/*"CASE WHEN SUM(NO_OF_PKGS) > ? THEN "+
			colorFlagRed + " WHEN SUM(NO_OF_PKGS) > ? THEN " + colorFlagYellow + " ELSE " + colorFlagGreen
			+ " END AS arrowColor,"+*/
			"A.ORD_FLOW_STAT_ID, \r\n" + 
			"trim(a.ord_flow_sum_dsc) as ord_flow_sum_dsc,\r\n" + 
			"trim(a.busn_proc_typ_dsc) as busn_proc_typ_dsc,\r\n" + 
			"trim(a.busn_acty_typ_dsc) as busn_acty_typ_dsc,\r\n" + 
			"trim(a.ord_flow_rsn_dsc) as ord_flow_rsn_dsc,\r\n" + 
			"trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc,\r\n" + 
			"a.ord_flow_sum_dsc as STATUS_NAME,\r\n" + 
			" \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS < 1 THEN NO_OF_PKGS ELSE 0 END) HRS_LT1_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 1 AND DURATION_IN_HRS < 3 THEN NO_OF_PKGS ELSE 0 END) HRS_1TO3_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 3 AND DURATION_IN_HRS < 6 THEN NO_OF_PKGS ELSE 0 END) HRS_3TO6_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 6 AND DURATION_IN_HRS < 24 THEN NO_OF_PKGS ELSE 0 END) HRS_6TO24_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_PKGS ELSE 0 END) HRS_24TO_48_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_PKGS ELSE 0 END) HRS_48TO_72_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_PKGS ELSE 0 END) HRS_GT72_PKGS, \r\n" + 
			"SUM(NO_OF_PKGS) TOTAL_Orders \r\n" + 
			"FROM ( \r\n" + 
			"SELECT AP.DC_PARTN_NBR, AP.ORD_FLOW_STAT_ID, \r\n" + 
			"DATEDIFF(hour,AP.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, \r\n" + 
			"COUNT(*) NO_OF_PKGS,\r\n" + 
			"c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc \r\n" + 
			"FROM Q.ACTV_PKG AP \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON ap.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat b ON ap.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.busn_proc_typ bpt ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.busn_acty_typ bat ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd \r\n" + 
			"WHERE AP.ORD_FLOW_STAT_ID IN (630000, 670000, 680000,780000,790000,725000,725100,1040000,1050000) \r\n" + 
			"AND AP.ACTV_IND='Y'" + 
			
			"AND AP.DC_PARTN_NBR IN (0, 1, 5, 6,9) \r\n" + 
			"AND ofsd.stat_viewer_id = 100 \r\n" + 
			"GROUP BY AP.DC_PARTN_NBR, AP.ORD_FLOW_STAT_ID, c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc,DATEDIFF(hour,AP.STAT_EFF_TMS,CURRENT_TIMESTAMP) ) A \r\n" + 
			"GROUP BY \r\n" + 
			"CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END , \r\n" + 
			"A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc, a.busn_proc_typ_dsc, \r\n" + 
			"a.busn_acty_typ_dsc, a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc order by WAREHOUSE, A.ORD_FLOW_STAT_ID ;\r\n" + 
			"\r\n" + 
			"";
			
	
	public  final String dmOrderswithoutEDDandSHPbyDT="SELECT  $COLUMN$\r\n" + 
			"FROM     q.active_ord_ln aol\r\n" + 
			"JOIN Q.ord_flow_stat b  ON aol.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
			"JOIN Q.busn_proc_typ bpt  ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd\r\n" + 
			"WHERE    aol.SHIP_BY_DT is Null\r\n" + 
			"AND      aol.REVSD_ESTDELVRY_DT is null\r\n" + 
			 
			"AND     bpt.busn_proc_typ_dsc in ('Demand Management')\r\n" + 
			"AND	 aol.ord_evnt_typ_cd not in ('INVRL', 'ADTSV', 'ICXBO','DCXBO','UNPIK','DLPRD','CNCL','DCXWL','CX','DLSGZ','DLSRC','DLVEN','DLZIP','ICXWL')\r\n" + 
			"AND     ORD_DT > '2022-01-01';" ;
	
	
	public final String dmOrdersWithPastEDD="SELECT  $COLUMN$\r\n" + 
			"FROM     q.active_ord_ln aol\r\n" + 
			"JOIN Q.ord_flow_stat b  ON aol.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
			"JOIN Q.busn_proc_typ bpt  ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd \r\n" + 
			"WHERE    aol.SHIP_BY_DT is Null\r\n" + 
			"AND      aol.REVSD_ESTDELVRY_DT < dateadd(hour,-10,current_timestamp)\r\n" + 
			"--AND 	b.LEGACY_STAT_CD not in ('VS','CX')\r\n" + 
			"AND 	bpt.busn_proc_typ_dsc in ('Demand Management')\r\n" + 
			"AND	 aol.ord_evnt_typ_cd not in ('INVRL', 'ADTSV', 'ICXBO','DCXBO','UNPIK','DLPRD','CNCL','DCXWL','CX','DLSGZ','DLSRC','DLVEN','DLZIP','ICXWL')\r\n" + 
			"AND     ORD_DT > '2022-01-01';";
	
	public final String dmOrdersNotReleased="\r\n" + 
			"\r\n" + 
			"SELECT  $COLUMN$\r\n" + 
			"FROM     q.active_ord_ln aol\r\n" + 
			"JOIN Q.ord_flow_stat b  ON aol.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
			"JOIN Q.busn_proc_typ bpt  ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd\r\n" + 
			"where bpt.busn_proc_typ_dsc in ('Demand Management')\r\n" + 
			"AND     ORD_DT > '2020-01-01'\r\n" + 
			"AND EVENT_TMS < dateadd(hour,-4,current_timestamp)\r\n" + 
			"and aol.ord_evnt_typ_cd is not null\r\n" + 
			"AND aol.ord_evnt_typ_cd not in ('INVRL', 'ADTSV', 'ICXBO','DCXBO','UNPIK','DLPRD','CNCL','DCXWL','CX','DLSGZ','DLSRC','DLVEN','DLZIP','ICXWL');";
		
	public final String demandFulfilmentByWarehouseInHours = "SELECT \r\n" + //Demand Fulfilemtn in hrsAVAIL
			"CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END as WAREHOUSE, \r\n" + 
			"A.ORD_FLOW_STAT_ID, \r\n" + 
			"trim(a.ord_flow_sum_dsc) as ord_flow_sum_dsc,\r\n" + 
			"trim(a.busn_proc_typ_dsc) as busn_proc_typ_dsc,\r\n" + 
			"trim(a.busn_acty_typ_dsc) as busn_acty_typ_dsc,\r\n" + 
			"trim(a.ord_flow_rsn_dsc) as ord_flow_rsn_dsc,\r\n" + 
			"trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc,\r\n" + 
			"a.ord_flow_sum_dsc as STATUS_NAME,\r\n" + 
			"\r\n" +
			/*"CASE WHEN SUM(NO_OF_PKGS) > ? THEN "
			+ colorFlagRed + " WHEN SUM(NO_OF_PKGS) > ? THEN " + colorFlagYellow + " ELSE " + colorFlagGreen
			+ " END AS arrowColor"+*/
			"SUM(CASE WHEN DURATION_IN_HRS < 1 THEN NO_OF_PKGS ELSE 0 END) HRS_LT1_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 1 AND DURATION_IN_HRS < 3 THEN NO_OF_PKGS ELSE 0 END) HRS_1TO3_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 3 AND DURATION_IN_HRS < 6 THEN NO_OF_PKGS ELSE 0 END) HRS_3TO6_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 6 AND DURATION_IN_HRS < 24 THEN NO_OF_PKGS ELSE 0 END) HRS_6TO24_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_PKGS ELSE 0 END) HRS_24TO_48_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_PKGS ELSE 0 END) HRS_48TO_72_PKGS, \r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_PKGS ELSE 0 END) HRS_GT72_PKGS, \r\n" + 
			"SUM(NO_OF_PKGS) TOTAL_Orders \r\n" + 
			"FROM ( \r\n" + 
			"SELECT AP.DC_PARTN_NBR, AP.ORD_FLOW_STAT_ID, \r\n" + 
			"DATEDIFF(hour,AP.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, \r\n" + 
			"COUNT(*) NO_OF_PKGS,\r\n" + 
			"c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc \r\n" + 
			"FROM Q.ACTV_PKG AP \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat_dsc ofsd ON ap.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_stat b ON ap.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"LEFT OUTER JOIN Q.busn_proc_typ bpt ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.busn_acty_typ bat ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd \r\n" + 
			"WHERE AP.ORD_FLOW_STAT_ID IN (?) \r\n" + 
			"AND AP.DC_PARTN_NBR IN (0, 1, 5, 6,9) \r\n" + 
			"AND ofsd.stat_viewer_id = 100 \r\n" + 
			"GROUP BY AP.DC_PARTN_NBR, AP.ORD_FLOW_STAT_ID, c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc,DATEDIFF(hour,AP.STAT_EFF_TMS,CURRENT_TIMESTAMP) ) A \r\n" + 
			"GROUP BY \r\n" + 
			"CASE WHEN A.DC_PARTN_NBR = 0 THEN 'DROP SHIP' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 1 THEN 'SUFFOLK' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 5 THEN 'FLORENCE' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 6 THEN 'ONTARIO' \r\n" + 
			"WHEN A.DC_PARTN_NBR = 9 THEN 'BETHLEHEM' END , \r\n" + 
			"A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc, a.busn_proc_typ_dsc, \r\n" + 
			"a.busn_acty_typ_dsc, a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc order by WAREHOUSE  ;\r\n" + 
			"";

	public final String demandManageemntExceptionChart="SELECT   aol.ord_flow_stat_id,\r\n" + 
			"         COUNT(*) NO_OF_ORDERS\r\n" + 
			"FROM     q.active_ord_ln aol\r\n" + 
			"WHERE    aol.ORD_FLOW_STAT_ID in (2190000,2210000,2230000,2250000,31660000,3170000,3140000,2270000)\r\n" + 
			"GROUP BY aol.ord_flow_stat_id;";
	//
	public final String demandManageemntExceptionInHours ="\r\n" + 
			"SELECT   A.ORD_FLOW_STAT_ID, \r\n" + 
			"			         trim(a.ord_flow_sum_dsc) as ord_flow_sum_dsc, \r\n" + 
			"			         trim(a.busn_proc_typ_dsc) as busn_proc_typ_dsc, \r\n" + 
			"			         trim(a.busn_acty_typ_dsc) as busn_acty_typ_dsc, \r\n" + 
			"			         trim(a.ord_flow_rsn_dsc) as ord_flow_rsn_dsc, \r\n" + 
			"			         trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc, \r\n" + 
			"			         a.ord_flow_sum_dsc as STATUS_NAME, \r\n" + 
			"			         SUM(CASE WHEN DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) HRS_LT24_ORDS, \r\n" + 
			"			         SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) HRS_24TO48_ORDS,\r\n" + 
			"SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_48TO72_ORDS,\r\n" + 
			"			         SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_GT72_ORDS, \r\n" + 
			"			         SUM(CASE WHEN DURATION_IN_HRS IS NOT NULL THEN  NO_OF_ORDERS ELSE 0 END) as TOTAL_Orders \r\n" + 
			"			FROM     ( \r\n" + 
			"			 \r\n" + 
			"			select ofsd.ord_flow_stat_id, DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS,c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from Q.ord_flow_stat_dsc ofsd   \r\n" + 
			"			         LEFT OUTER JOIN q.active_ord_ln aol ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id  \r\n" + 
			"			         LEFT OUTER JOIN Q.ord_flow_stat b ON ofsd.ord_flow_stat_id = b.ord_flow_stat_id  \r\n" + 
			"			         LEFT OUTER JOIN Q.busn_proc_typ bpt ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd  \r\n" + 
			"			         LEFT OUTER JOIN Q.busn_acty_typ bat ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd  \r\n" + 
			"			         LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd  \r\n" + 
			"			         LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd where ofsd.ORD_FLOW_STAT_ID in ('2190000','2210000','2230000','2250000','2270000','3140000','3166000','3170000','3176500','3177000','2290000')  \r\n" + 
			"			AND ofsd.stat_viewer_id = 100 \r\n" + 
			"   \r\n" + 
			"			group by ofsd.ord_flow_stat_id,c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc ,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP) \r\n" + 
			"			 \r\n" + 
			"			) a \r\n" + 
			"			GROUP BY A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc, a.busn_proc_typ_dsc,  \r\n" + 
			"			         a.busn_acty_typ_dsc, a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;";

	
	public final String demandFulfilmentExceptionInHours="SELECT   A.ORD_FLOW_STAT_ID,\r\n" + 
			"         trim(a.ord_flow_sum_dsc) as ord_flow_sum_dsc,\r\n" + 
			"         trim(a.busn_proc_typ_dsc) as busn_proc_typ_dsc,\r\n" + 
			"         trim(a.busn_acty_typ_dsc) as busn_acty_typ_dsc,\r\n" + 
			"         trim(a.ord_flow_rsn_dsc) as ord_flow_rsn_dsc,\r\n" + 
			"         trim(a.ord_flow_stat_dsc) as ord_flow_stat_dsc,\r\n" + 
			"         a.ord_flow_sum_dsc as STATUS_NAME,\r\n" + 
			"         SUM(CASE WHEN DURATION_IN_HRS < 24 THEN NO_OF_ORDERS ELSE 0 END) HRS_LT24_ORDS,\r\n" + 
			"         SUM(CASE WHEN DURATION_IN_HRS >= 24 AND DURATION_IN_HRS < 48 THEN NO_OF_ORDERS ELSE 0 END) HRS_24TO48_ORDS,\r\n" + 
			" SUM(CASE WHEN DURATION_IN_HRS >= 48 AND DURATION_IN_HRS < 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_48TO72_ORDS,\r\n" + 
			"         SUM(CASE WHEN DURATION_IN_HRS >= 72 THEN NO_OF_ORDERS ELSE 0 END) HRS_GT72_ORDS,\r\n" + 
			"         SUM(NO_OF_ORDERS) as TOTAL_Orders\r\n" + 
			"FROM     ( select ofsd.ord_flow_stat_id, DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)DURATION_IN_HRS, COUNT(*) NO_OF_ORDERS,c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc from Q.ord_flow_stat_dsc ofsd\r\n" + 
			"         LEFT OUTER JOIN  q.active_ord_ln aol  ON aol.ord_flow_stat_id = ofsd.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_stat b ON ofsd.ord_flow_stat_id = b.ord_flow_stat_id \r\n" + 
			"         LEFT OUTER JOIN Q.busn_proc_typ bpt ON b.busn_proc_typ_cd = bpt.busn_proc_typ_cd \r\n" + 
			"         LEFT OUTER JOIN Q.busn_acty_typ bat ON b.busn_acty_typ_cd = bat.busn_acty_typ_cd AND b.busn_proc_typ_cd = bat.busn_proc_typ_cd \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd \r\n" + 
			"         LEFT OUTER JOIN Q.ord_flow_rsn_typ d ON b.ord_flow_rsn_cd = d.ord_flow_rsn_cd where ofsd.ORD_FLOW_STAT_ID in (2350000,2380000,2410000,2320000,2530000,2440000) AND ofsd.stat_viewer_id = 100 group by ofsd.ord_flow_stat_id,c.ord_flow_sum_dsc, bpt.busn_proc_typ_dsc, bat.busn_acty_typ_dsc, d.ord_flow_rsn_dsc, ofsd.ord_flow_stat_dsc ,DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP) ) a\r\n" + 
			"GROUP BY A.ORD_FLOW_STAT_ID, a.ord_flow_sum_dsc, a.busn_proc_typ_dsc, \r\n" + 
			"         a.busn_acty_typ_dsc, a.ord_flow_rsn_dsc, a.ord_flow_stat_dsc;";

	public final String financeCheckReprocess="select aol.ORD_NBR , aol.ORD_LN_NBR , aol.ACCT_NBR , aol.ORD_DT , aol.ITEM_NBR , aol.LAST_UPD_TMS,\r\n" + 
			"         aol.ORD_FLOW_STAT_ID as AOL_STATUS,\r\n" + 
			"         ol.ORD_FLOW_STAT_ID as OL_STATUS\r\n" + 
			"FROM     q.ACTIVE_ORD_LN aol \r\n" + 
			"         inner join qord.ordmline ol on aol.ORD_NBR = ol.ord_nbr and aol.ORD_LN_NBR = ol.ord_ln_nbr\r\n" + 
			"WHERE    aol.ORD_FLOW_STAT_ID in (3175500)\r\n" + 
			"AND      aol.STAT_EFF_TMS < dateadd(dd,-5, current_timestamp)\r\n" + 
			"AND      ol.ORD_FLOW_STAT_ID = 320000\r\n" + 
			"AND      aol.STAT_EFF_TMS >= dateadd(dd,-130, current_timestamp);";
	
	@Value("${financeHold.red}")
	int financeHoldRed;
	@Value("${financeHold.yellow}")
	int financeHoldYellow;
	@Value("${demandManagement.red}")
	int demandManagementRed;
	@Value("${demandManagement.yellow}")
	int demandManagementYellow;
	@Value("${demandFulfilment.red}")
	int demandFulfilmentRed;
	@Value("${demandManagement.yellow}")
	int demandFulfilmentYellow;

	
	
	
	//FINANCE HOLD PIE CHART QUERY
	
		public final String financePieChartInflowCount ="select count(*) from q.ORD_LN_STAT_HIST olh with(nolock) where olh.ord_flow_stat_id='320000'\r\n" + 
		"AND     olh.INSRT_TMS>= dateadd(day,-30,CURRENT_TIMESTAMP);";
	
		public final String financePieChartOutFlow="SELECT   count(*)\r\n" + 
				"FROM     qord.ordmline ol with (nolock) \r\n" + 
				"          join q.ORD_LN_STAT_HIST olh with (nolock) on ol.ORD_NBR=olh.ORD_NBR and ol.ORD_LN_NBR=olh.ORD_LN_NBR \r\n" + 
				"        \r\n" + 
				"WHERE    ol.ord_flow_stat_id not in ('320000','340000')\r\n" + 
				"AND      olh.ord_flow_stat_id='320000'\r\n" + 
				
				"AND      olh.INSRT_TMS>= dateadd(day,-30,CURRENT_TIMESTAMP);";
		
		public final String financePieChartReleaseCount ="select count(*) from q.ORD_LN_STAT_HIST olh with(nolock) where olh.ord_flow_stat_id='340000'\r\n" + 
				"AND     olh.INSRT_TMS>= dateadd(day,-30,CURRENT_TIMESTAMP);";
		
		public Integer getFinancePieChartInflowCount() {

			//List<OrderStatusCountModel> financeHoldOrders = new ArrayList<>();
			int financeInflow=0;
			try {
				//System.out.println(colorFlagGreen);
				financeInflow = jdbcTemplate.queryForObject(
						financePieChartInflowCount,Integer.class);
			} catch (Exception e) {
				// TODO: handle exception
				//System.out.println(e);
			}
			return financeInflow;
		}
		
		public Integer getFinancePieChartReleaseCount() {

			int financePieChartRelease=0;
			try {
				financePieChartRelease = jdbcTemplate.queryForObject(
						financePieChartReleaseCount,Integer.class);
			} catch (Exception e) {
				// TODO: handle exception
				//System.out.println(e);
			}
			return financePieChartRelease;
		}
	
		
		
		
		public Integer getFinancePieChartOutFlow() {

			int financeOutflow=0;
			try {
				financeOutflow = jdbcTemplate.queryForObject(
						financePieChartOutFlow,Integer.class);
			} catch (Exception e) {
				// TODO: handle exception
				//System.out.println(e);
			}
			return financeOutflow;
		}
	
	public List<OrderStatusCountModel> orderInFinanceHoldCount() {

		List<OrderStatusCountModel> financeHoldOrders = new ArrayList<>();
		try {
			//System.out.println(colorFlagGreen);
			financeHoldOrders = jdbcTemplate.query(
					orderSelectionQuery + ordersInFinanceHoldWhereQueryCount + orderGroupByQuery,
					new Object[] { financeHoldRed, financeHoldYellow }, new OrderStatusRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return financeHoldOrders;
	}

	public List<OrderStatusCountModel> ordersInDMEventRetreiverCount() {
		List<OrderStatusCountModel> ordersInDMEventRetreivers = new ArrayList<>();
		try {
			ordersInDMEventRetreivers = jdbcTemplate.query(
					orderSelectionQuery + ordersInDMEventRetreivereQueryCount + orderGroupByQuery,
					new Object[] { demandManagementRed, demandManagementYellow }, new OrderStatusRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return ordersInDMEventRetreivers;
	}

	public List<WarehousePackageCountModel> packageInDemandFulfilmentCount() {
		List<WarehousePackageCountModel> warehousePackageCountModels = new ArrayList<>();
		try {
			warehousePackageCountModels = jdbcTemplate.query(demandFulfilmentQuery,
					new Object[] { demandFulfilmentRed, demandFulfilmentYellow }, new WarehousePackageCountRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return warehousePackageCountModels;
	}
	
	/*public List<FinanceOrderDetailsModel> financeOrderReleaseDetails(Date startDate,Date endDate){
		List<FinanceOrderDetailsModel> orderStatusModels = new ArrayList<>();
		
		 SimpleDateFormat ft = 
			      new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

			      System.out.println("Start Date: " + ft.format(startDate));
			      System.out.println("End Date: " + ft.format(endDate));
		try {
			orderStatusModels = jdbcTemplate.query(financeHoldStuckOrderDetails,
					new Object[] { startDate,endDate }, 
					new FinanceOrderDetailsModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
	*/
	
	public  String orderDBQueryStuckOrders="Select lr.order_nbr as ord_nbr from q.LEGACY_EVENT_RESULT lr with(nolock)\r\n" + 
			"\r\n" + 
			"where \r\n" + 
			" lr.last_update_datetime = (select max(last_update_datetime) from q.LEGACY_EVENT_RESULT lr1 with(nolock) where lr.order_nbr=lr1.order_nbr)\r\n" + 
			"and process_status_type_cd in ('P','D','E') and final_action_cd not in ('H','R','C')\r\n" + 
			"and (lr.order_nbr in ($orders$)) ;\r\n" + 
			"";
	/*public List<FinanceOrderDetailsModel> financeHoldOrderDetails(Date startDate,Date endDate){
		List<BaseOrderDetail> orderStatusModelsQRG1 = new ArrayList<>();
		List<BaseOrderDetail> orderStatusModelsOrderDB = new ArrayList<>();
		List<BaseOrderDetail> orderStatusModels = new ArrayList<>();
		
		String test="Select top 100 lr.order_nbr as ord_nbr, lr.model_type_cd as ord_ln_nbr from q.LEGACY_EVENT_RESULT lr;";
		
		
		System.out.println("TEST");
		
		 SimpleDateFormat ft = 
			      new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

			      System.out.println("Start Date: " + ft.format(startDate));
			      System.out.println("End Date: " + ft.format(endDate));
		try {
			orderStatusModelsQRG1 = jdbcTemplate.query(financeHoldStuckOrderDetails,
					new Object[] { startDate,endDate }, 
					new OrderFlowStatVWModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		try {
			StringBuilder orders=new StringBuilder();
			for (BaseOrderDetail baseOrderDetail : orderStatusModelsQRG1) {
				orders.append("'"+baseOrderDetail.getOrderNumber()+"',");
			}
			int index=orders.lastIndexOf(",");
			orders.replace(index, index+1, "")	;
			
			orderDBQueryStuckOrders=orderDBQueryStuckOrders.replace("$orders$", orders);
			
			orderStatusModelsOrderDB = jdbcTemplate2.query(orderDBQueryStuckOrders,
					
					new OrderFlowStatVWModelRowMapper());
			System.out.println("ORDER DB");
			//System.out.println(orderStatusModels);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("FINACE QRG1 count:"+ orderStatusModelsQRG1.size());
		System.out.println("Finace hold order DB: "+orderStatusModelsOrderDB.size());
		List<FinanceOrderDetailsModel> financeOrderDetailsModels=new ArrayList<>();
		
		try {
			StringBuilder orders=new StringBuilder();
			for (BaseOrderDetail baseOrderDetail : orderStatusModelsOrderDB) {
				orders.append("'"+baseOrderDetail.getOrderNumber()+"',");
			}
			int index=orders.lastIndexOf(",");
			orders.replace(index, index+1, "")	;
			
			financeHoldStuckOrderDetailsFinal=financeHoldStuckOrderDetailsFinal.replace("$orders$", orders);
			
			financeOrderDetailsModels = jdbcTemplate.query(financeHoldStuckOrderDetailsFinal,
					
					new FinanceOrderDetailsModelRowMapper());
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return financeOrderDetailsModels;
	}
		
		*/
		public List<FinanceOrderDetail> financeOrderOutflowflowDetails(Date startDate,Date endDate){
			List<FinanceOrderDetail> orderStatusModels = new ArrayList<>();
			
			 SimpleDateFormat ft = 
				      new SimpleDateFormat (DATE_FORMAT);

				    
			try {
//				orderStatusModels = jdbcTemplate.query(financeHoldStuckOrderOutflowflowDetails,
//						new Object[] { startDate,endDate }, 
//						new FinanceOrderDetailsModelRowMapper());
				
				orderStatusModels = jdbcTemplate.query(financeOutflowOrderQuery,
						new Object[] { startDate,endDate }, 
						new FinanceOrderDetailRowMapper());
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		
		return orderStatusModels;
	}
	
		public List<FinanceOrderDetail> financeReleasedOrderaDetails(Date startDate,Date endDate){
			List<FinanceOrderDetail> orderStatusModels = new ArrayList<>();
			
			 SimpleDateFormat ft = 
				      new SimpleDateFormat (DATE_FORMAT);

				     
			try {
//				orderStatusModels = jdbcTemplate.query(financeHoldStuckOrderOutflowflowDetails,
//						new Object[] { startDate,endDate }, 
//						new FinanceOrderDetailsModelRowMapper());
				
				orderStatusModels = jdbcTemplate.query(financeReleasedOrderQuery,
						new Object[] { startDate,endDate }, 
						new FinanceOrderDetailRowMapper());
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		
		return orderStatusModels;
	}
	
		
		public List<FinanceOrderDetail> financeOrderInflowDetails(Date startDate,Date endDate){
			List<FinanceOrderDetail> orderStatusModels = new ArrayList<>();
			
			 SimpleDateFormat ft = 
				      new SimpleDateFormat (DATE_FORMAT);

				     
			try {
//				orderStatusModels = jdbcTemplate.query(financeHoldStuckOrderOutflowflowDetails,
//						new Object[] { startDate,endDate }, 
//						new FinanceOrderDetailsModelRowMapper());
				
				orderStatusModels = jdbcTemplate.query(financeInflowOrderQuery,
						new Object[] { startDate,endDate }, 
						new FinanceOrderDetailRowMapper());
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		
		return orderStatusModels;
	}
	
	
	
	public List<OrderDetailsModel> getFinanceHoldStuckOrderDetails() {
		List<OrderDetailsModel> orderStatusModels = new ArrayList<>();
		try {
			 List<OrderDetailsModel> query = jdbcTemplate.query(financeHoldStuckOrderDetails,
					//new Object[] { financeHoldRed, financeHoldYellow }, 
					new OrderDetailsModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}
	
	
	public List<FinanceHoldChartData> demandManagementChart() {
		List<FinanceHoldChartData> orderData = new ArrayList<>();
		System.out.println("======================  DEMAND MANAGEMENT CHART query  ========================");
		try {
			orderData = jdbcTemplate.query(demandManageemntExceptionChart,
					//new Object[] { financeHoldRed, financeHoldYellow }, 
					new FinanceHoldChartRowMapper());
			//FinanceOrderStatusModelRowMapper
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	return orderData;
	}
	public List<FinanceHoldChartData> financeHoldChart() {
		List<FinanceHoldChartData> financeHoldChartData = new ArrayList<>();
		int count=0;
		try {
			count = jdbcTemplate.queryForObject(financeHoldOrderChart,
					//new Object[] { financeHoldRed, financeHoldYellow }, 
					Integer.class);
			FinanceHoldChartData chartData=new FinanceHoldChartData();
			chartData.setStatusId(new BigDecimal(320000));
			chartData.setOrdFlowSumDsc("Finance Hold");
			chartData.setTotalOrders(new BigDecimal(count));
			financeHoldChartData.add(chartData);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		
		
		
		try {
			count = jdbcTemplate.queryForObject(financeReleasedOrderChart,
					//new Object[] { financeHoldRed, financeHoldYellow }, 
					Integer.class);
			FinanceHoldChartData chartData=new FinanceHoldChartData();
			chartData.setStatusId(new BigDecimal(340000));
			chartData.setOrdFlowSumDsc("Released");
			chartData.setTotalOrders(new BigDecimal(count));
			financeHoldChartData.add(chartData);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return financeHoldChartData;
	}
	
	
	
	public List<FinanceOrderStatusModel> getFinanceHoldInHours() {
		List<FinanceOrderStatusModel> orderStatusModels = new ArrayList<>();
		try {
			  orderStatusModels = jdbcTemplate.query(financeHoldInMinutes,
					//new Object[] { financeHoldRed, financeHoldYellow }, 
					new FinanceOrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}
	
	public List<FinanceOrderStatusModel> financeOrderRelease() {
		List<FinanceOrderStatusModel> orderStatusModels = new ArrayList<>();
		try {
			  orderStatusModels = jdbcTemplate.query(financeOrderReleaseInHours,
					//new Object[] { financeHoldRed, financeHoldYellow }, 
					new FinanceOrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return orderStatusModels;
	}

	public List<OrderStatusModel> demandManagementNoInventoryInHours() {
		List<OrderStatusModel> orderStatusModels = new ArrayList<>();
		try {
			orderStatusModels = jdbcTemplate.query(demandManagementNoInventoryInHoursQuery,
					//new Object[] { demandManagementRed, demandFulfilmentYellow }, 
					new OrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}
	
	public List<OrderStatusModel> demandManagementStuckOrderInHours() {
		List<OrderStatusModel> orderStatusModels = new ArrayList<>();
		try {
			orderStatusModels = jdbcTemplate.query(demandManagementStuckOrderInHoursQuery,
					//new Object[] { demandManagementRed, demandFulfilmentYellow }, 
					new OrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}

	public List<OrderStatusModel> demandManagementRealInventoryHoldInHours() {
		List<OrderStatusModel> orderStatusModels = new ArrayList<>();
		try {
			orderStatusModels = jdbcTemplate.query(demandManagementRealInventoryHoldInHoursQuery,
					//new Object[] { demandManagementRed, demandFulfilmentYellow }, 
					new OrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}
	
	
	public List<OrderStatusModel> demandManagementExceptionInHours() {
		List<OrderStatusModel> orderStatusModels = new ArrayList<>();
		System.out.println("----------------DEMAND MANAGEMENT EXCEPTION QUERY--------------");
		try {
			orderStatusModels = jdbcTemplate.query(demandManageemntExceptionInHours, new OrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}

	
	
	public int demandManagementOrdersWithNoEDDandShpByDT() {
		int count=0;
		String query=dmOrderswithoutEDDandSHPbyDT;
		try {
			query=query.replace(COLUMN_REPLACE_CONST,"count(*)");
			count = jdbcTemplate.queryForObject(query, Integer.class);
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return count;
	}
	
	
	public int getDmOrdersNotReleased() {
		int count=0;
		String query=dmOrdersNotReleased;
		try {
			
			query=query.replace(COLUMN_REPLACE_CONST,"count(*)");
			count = jdbcTemplate.queryForObject(query, Integer.class);
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return count;
	}
	
	
	public int getDmOrdersWithPastEDD() {
		int count=0;
		String query=dmOrdersWithPastEDD;
		try {
			query=query.replace(COLUMN_REPLACE_CONST,"count(*)");
			count = jdbcTemplate.queryForObject(query, Integer.class);
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return count;
	}
	
	
	
	
	public List<OrderDetailsModel> demandManagementOrdersWithNoEDDandShpByDTOrderDetails() {
		List<OrderDetailsModel> orders = new ArrayList<>();
		String query=dmOrderswithoutEDDandSHPbyDT;
		try {
			query=query.replace(COLUMN_REPLACE_CONST,"aol.REVSD_ESTDELVRY_DT , aol.SHIP_BY_DT, aol.ORD_NBR , aol.ORD_LN_NBR , aol.ITEM_NBR , aol.ORD_FLOW_STAT_ID , aol.LAST_UPD_TMS , aol.ACCT_NBR , aol.ORD_DT");
			orders = jdbcTemplate.query(query, new DMOrderDetailsModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orders;
	}
	
	
	public List<OrderDetailsModel> dmOrdersNotReleasedOrderDetails() {
		List<OrderDetailsModel> orders = new ArrayList<>();
		String query=dmOrdersNotReleased;
		try {
			
			query=query.replace(COLUMN_REPLACE_CONST,"aol.REVSD_ESTDELVRY_DT , aol.SHIP_BY_DT, aol.ORD_NBR , aol.ORD_LN_NBR , aol.ITEM_NBR , aol.ORD_FLOW_STAT_ID , aol.LAST_UPD_TMS , aol.ACCT_NBR , aol.ORD_DT");
			orders = jdbcTemplate.query(query, new DMOrderDetailsModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orders;
	}
	
	
	public List<OrderDetailsModel> dmOrdersWithPastEDDOrderDetails() {
		List<OrderDetailsModel> orders = new ArrayList<>();
		String query=dmOrdersWithPastEDD;
		try {
			query=query.replace(COLUMN_REPLACE_CONST,"aol.REVSD_ESTDELVRY_DT , aol.SHIP_BY_DT, aol.ORD_NBR , aol.ORD_LN_NBR , aol.ITEM_NBR , aol.ORD_FLOW_STAT_ID , aol.LAST_UPD_TMS , aol.ACCT_NBR , aol.ORD_DT");
			orders = jdbcTemplate.query(query, new DMOrderDetailsModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orders;
	}
	
	
	public List<OrderStatusModel> getDemandFulfilmentExceptionInHours() {
		List<OrderStatusModel> orderStatusModels = new ArrayList<>();
		try {
			orderStatusModels = jdbcTemplate.query(demandFulfilmentExceptionInHours, new OrderStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderStatusModels;
	}
	
	
	//AVAIL
	public List<PackageStatusModel> getDemandFulfilmentInHours(Optional<String> dcNbr) {
		List<PackageStatusModel> packageStatusModels = new ArrayList<>();
		try {
			if (dcNbr.isPresent())
				packageStatusModels = jdbcTemplate.query(demandFulfilmentByWarehouseInHours,
					///	new Object[] { demandFulfilmentRed, demandFulfilmentYellow, dcNbr.get() },
						new PackageStatusModelRowMapper());
			else
				packageStatusModels = jdbcTemplate.query(demandFulfilmentInHours,
					//	new Object[] { demandFulfilmentRed, demandFulfilmentYellow },
						new PackageStatusModelRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return packageStatusModels;
	}

	private String orderDetailsQuery = "select aol.ORD_NBR , aol.ORD_LN_NBR , aol.ACCT_NBR , aol.ORD_DT , aol.ITEM_NBR , aol.LAST_UPD_TMS from q.active_ord_ln aol LEFT OUTER JOIN Q.ord_flow_stat b ON aol.ord_flow_stat_id = b.ord_flow_stat_id LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd where aol.ORD_FLOW_STAT_ID in (?) and DATEDIFF($field$,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)>=? $ORD_EVENT_FILTER$ and DATEDIFF($field$,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)<? order by aol.ORD_NBR , aol.ORD_LN_NBR ;";//
	private String orderDetailsAboveQuery = "select aol.ORD_NBR , aol.ORD_LN_NBR , aol.ACCT_NBR , aol.ORD_DT , aol.ITEM_NBR , aol.LAST_UPD_TMS from q.active_ord_ln aol LEFT OUTER JOIN Q.ord_flow_stat b ON aol.ord_flow_stat_id = b.ord_flow_stat_id LEFT OUTER JOIN Q.ord_flow_sum_typ AS c ON b.ord_flow_sum_cd = c.ord_flow_sum_cd where aol.ORD_FLOW_STAT_ID in (?) $ORD_EVENT_FILTER$ and DATEDIFF($field$,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)>=?  order by aol.ORD_NBR , aol.ORD_LN_NBR ;";//

	public List<OrderDetailsModel> financeCheckOrderDetails(){
		List<OrderDetailsModel> orderDetailsModel = new ArrayList<>();
		try {
			orderDetailsModel = jdbcTemplate.query(financeHoldStuckOrders,//financeCheckReprocess, 
					new OrderDetailsModelRowMapper());
		}	catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return orderDetailsModel;
	}
	
	
	public static String orderReleaseAbvQury="select aol.ORD_NBR , aol.ORD_LN_NBR , aol.ACCT_NBR , aol.ORD_DT , aol.ITEM_NBR , aol.LAST_UPD_TMS "
			+ "from q.active_ord_ln aol where aol.ORD_FLOW_STAT_ID in ('340000') and aol.LAST_UPD_TMS>= dateadd(day,-365,current_timestamp)  and DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)>=?  order by aol.ORD_NBR , aol.ORD_LN_NBR ;"; 
	public static String orderReleaseQury="select aol.ORD_NBR , aol.ORD_LN_NBR , aol.ACCT_NBR , aol.ORD_DT , aol.ITEM_NBR , aol.LAST_UPD_TMS from q.active_ord_ln aol where aol.ORD_FLOW_STAT_ID in ('340000') and DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)>=? and DATEDIFF(hour,aol.STAT_EFF_TMS,CURRENT_TIMESTAMP)<? AND aol.LAST_UPD_TMS>= dateadd(day,-365,current_timestamp)   order by aol.ORD_NBR , aol.ORD_LN_NBR ;"; 

	@SuppressWarnings("deprecation")
	public List<OrderDetailsModel> financeReleaeOrderDetails(String field, int start, int end) {
		List<OrderDetailsModel> orderDetailsModel = new ArrayList<>();
	try {
		if (end != 0) {
			orderReleaseQury = orderReleaseQury.replace("$field$", field);
			//System.out.println("last query");
			orderDetailsModel = jdbcTemplate.query(orderReleaseQury, new Object[] {  start, end },
					new OrderDetailsModelRowMapper());
		} else {
			orderReleaseAbvQury = orderReleaseAbvQury.replace("$field$", field);
			//System.out.println("above query");
			orderDetailsModel = jdbcTemplate.query(orderReleaseAbvQury, new Object[] {  start },
					new OrderDetailsModelRowMapper());
		}}
	catch (Exception e) {
		// TODO: handle exception
		System.out.println(e);
	}
		
		return orderDetailsModel;
	}
	
	
	public List<OrderDetailsModel> orderDetails(String status, String field, int start, int end, boolean isInvHold) {
		List<OrderDetailsModel> orderDetailsModel = new ArrayList<>();
		try {// ,new Timestamp(endDate.getTime()
			//System.out.println("DAO-> status: " + status + " Field: " + field + " Start: " + start + " End: " + end
				//	+ " isInvHold: " + isInvHold);
			String orderdetailQuery = orderDetailsQuery;
			String orderdetailAbvQuery=orderDetailsAboveQuery;
			//System.out.println("CHECK: "+((status.equals("320000") | status.equals("340000"))));
			if (!(status.equals("320000") || status.equals("340000"))) {
				//System.out.println("Add event tms");
				orderdetailQuery = orderdetailQuery.replace("$ORD_EVENT_FILTER$","$ORD_EVENT_FILTER$ AND      EVENT_TMS < dateadd(hour,-4,current_timestamp) AND      aol.ord_dt > '2022-01-01'");}
			
		/*	if(status.equals("340000")) {
				
				orderdetailQuery.replace("$ORD_EVENT_FILTER$","$ORD_EVENT_FILTER$ AND  aol.LAST_UPD_TMS>= dateadd(day,-180,current_timestamp)");
				System.out.println(orderdetailQuery);
			}*/
			//String g="";
			if (isInvHold) {
				orderdetailQuery = orderdetailQuery.replace("$ORD_EVENT_FILTER$",
						"and ord_evnt_typ_cd in ('INVRL', 'ADTSV', 'ICXBO','DCXBO','UNPIK','DLPRD','CNCL','DCXWL','CX','DLSGZ','DLSRC','DLVEN','DLZIP','ICXWL') and  EVENT_TMS < dateadd(hour,-4,current_timestamp)  and aol.ord_dt > '2022-01-01'");
				orderdetailAbvQuery=orderdetailAbvQuery.replace("$ORD_EVENT_FILTER$",
						"and ord_evnt_typ_cd in ('INVRL', 'ADTSV', 'ICXBO','DCXBO','UNPIK','DLPRD','CNCL','DCXWL','CX','DLSGZ','DLSRC','DLVEN','DLZIP','ICXWL') and  EVENT_TMS < dateadd(hour,-4,current_timestamp)  and aol.ord_dt > '2022-01-01'");
				
			} else {
				orderdetailQuery = orderdetailQuery.replace("$ORD_EVENT_FILTER$", "");
				orderdetailAbvQuery=orderdetailAbvQuery.replace("$ORD_EVENT_FILTER$", "");
			}

			if (end != 0) {
				orderdetailQuery = orderdetailQuery.replace("$field$", field);
				//System.out.println("last query");
				orderDetailsModel = jdbcTemplate.query(orderdetailQuery, new Object[] { status, start, end },
						new OrderDetailsModelRowMapper());
			} else {
				orderdetailAbvQuery = orderdetailAbvQuery.replace("$field$", field);
				//System.out.println("above query");
				orderDetailsModel = jdbcTemplate.query(orderdetailAbvQuery, new Object[] { status, start },
						new OrderDetailsModelRowMapper());
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return orderDetailsModel;
	}

//
//	
	//
	// public final String packageDetailsLastHours="select
	// ap.pkg_id,ap.ORD_FLOW_STAT_ID as package_Status,ap.INVC_NBR,
	// ap.dc_partn_nbr,ap.ACTV_IND, ap.LAST_UPD_TMS as
	// package_last_UPD_TMS,ap.BOX_NBR,AOL.ORD_LN_NBR,
	// aol.ORD_NBR,aol.ORD_FLOW_STAT_ID as order_Status,aol.LAST_UPD_TMS as
	// order_last_UPD_TMS FROM Q.ACTV_PKG ap, q.active_ord_ln aol, q.package_ol_rel
	// por where por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR AND
	// ap.PKG_ID =por.PKG_ID and ap.ord_flow_stat_id= ? and ap.DC_PARTN_NBR=? and
	// DATEDIFF(hour,ap.STAT_EFF_TMS,CURRENT_TIMESTAMP)>= ? and
	// DATEDIFF(hour,ap.STAT_EFF_TMS,CURRENT_TIMESTAMP)< ?";
	public final String packageDetailsLastHours = "select ap.pkg_id,ap.ORD_FLOW_STAT_ID as package_Status,ap.INVC_NBR, ap.dc_partn_nbr,ap.ACTV_IND, ap.LAST_UPD_TMS as package_last_UPD_TMS,ap.BOX_NBR  FROM Q.ACTV_PKG ap where ap.ord_flow_stat_id= ? and ap.DC_PARTN_NBR=? and DATEDIFF(hour,ap.STAT_EFF_TMS,CURRENT_TIMESTAMP)>= ? and DATEDIFF(hour,ap.STAT_EFF_TMS,CURRENT_TIMESTAMP)< ?";
	public final String packageDetailsAboveHours = "select ap.pkg_id,ap.ORD_FLOW_STAT_ID as package_Status,ap.INVC_NBR, ap.dc_partn_nbr,ap.ACTV_IND, ap.LAST_UPD_TMS as package_last_UPD_TMS,ap.BOX_NBR FROM Q.ACTV_PKG ap where  ap.ord_flow_stat_id= ? and ap.DC_PARTN_NBR=? and DATEDIFF(hour,ap.STAT_EFF_TMS,CURRENT_TIMESTAMP)>= ?";

	public List<PackageDetailsModel> packageDetails(String status, int dcId, String field, int start, int end) {

		//System.out.println(
				//"Statsu: " + status + " DCID: " + dcId + " Field: " + field + " start: " + start + " end: " + end);
		List<PackageDetailsModel> packageDetailsModel = new ArrayList<>();
		try {// ,new Timestamp(endDate.getTime()
			if (end != 0) {
				String orderdetailQuery = orderDetailsQuery.replace("$field$", field);
				//System.out.println("last query");
				packageDetailsModel = jdbcTemplate.query(packageDetailsLastHours,
						new Object[] { status, dcId, start, end }, new PackageDetailsRowMapper());
			} else {
				String orderdetailQuery = orderDetailsAboveQuery.replace("$field$", field);
				//System.out.println("above query");
				packageDetailsModel = jdbcTemplate.query(packageDetailsAboveHours, new Object[] { status, dcId, start },
						new PackageDetailsRowMapper());
			}
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return packageDetailsModel;
	}

}
