package com.qvc.orderflowdashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.qvc.orderflowdashboard.dao.DashboardDAO;
import com.qvc.orderflowdashboard.service.DashboardService;

@RestController
public class DashboardController {

	@Autowired
	DashboardDAO dashboardDAO;

	@Autowired
	DashboardService dashboardService;

}
