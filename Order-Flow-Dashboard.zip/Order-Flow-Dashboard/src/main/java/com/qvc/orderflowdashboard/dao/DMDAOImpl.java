package com.qvc.orderflowdashboard.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.qvc.orderflowdashboard.mapper.OrderDetailsModelRowMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.qvc.orderflowdashboard.mapper.OrderFlowRowMapper;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;


@Repository
@Qualifier("demandManagementDAO")
public class DMDAOImpl implements OrderFlowDAO{

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(DMDAOImpl.class);

	@Autowired
	@Qualifier("jdbcTemplate1")
	private JdbcTemplate jdbcTemplate;

	/*@Autowired
	@Qualifier("jdbcTemplate2")
	private JdbcTemplate jdbcTemplate2;*/

    /*String orderSummaryQuery = "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED\r\n"
			+ "			SELECT T.ORD_FLOW_STAT_ID,\r\n"
			+ "						         T.DC_ID AS DC_ID,\r\n"
			+ "						         NUll AS AGE_BUCKET_CD,\r\n"
			+ "						         T.IS_EXCPTN_IND,\r\n"
			+ "						         T.TOT_ORD_LN_CNT,\r\n"
			+ "						         T.TOT_UNIT_CNT,\r\n"
			+ "						         T.TOT_MRCH_PRICE_AMT,\r\n"
			+ "						         T.TOT_PKG_CNT,\r\n"
			+ "						         VW.*\r\n"
			+ "\r\n"
			+ "FROM\r\n"
			+ "(\r\n"
			+ "SELECT 	D.ORD_FLOW_STAT_ID,\r\n"
			+ "						         D.DC_ID AS DC_ID,\r\n"
			+ "						         NUll AS AGE_BUCKET_CD,\r\n"
			+ "						         D.IS_EXCPTN_IND,\r\n"
			+ "						         D.TOT_ORD_LN_CNT,\r\n"
			+ "						         D.TOT_UNIT_CNT,\r\n"
			+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
			+ "						         D.TOT_PKG_CNT	\r\n"
			+ "						FROM\r\n"
			+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
			+ "							(\r\n"
			+ "								SELECT   \r\n"
			+ "									 C.ORD_FLOW_STAT_ID,\r\n"
			+ "									 C.DC_ID AS DC_ID,\r\n"
			+ "									 C.IS_EXCPTN_IND,\r\n"
			+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
			+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
			+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
			+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
			+ "								FROM     (\r\n"
			+ "										SELECT   \r\n"
			+ "											 O.ORD_FLOW_STAT_ID,\r\n"
			+ "											 NULL AS DC_ID,\r\n"
			+ "											 0 AS TOT_PKG_CNT,\r\n"
			+ "											 TOT_ORD_LN_CNT,\r\n"
			+ "											 TOT_UNIT_CNT,\r\n"
			+ "											 TOT_MRCH_PRICE_AMT,\r\n"
			+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
			+ "										FROM     Q.ORD_STAT_SUM_A O \r\n"
			+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
			+ "									UNION ALL\r\n"
			+ "										SELECT   O.ORD_FLOW_STAT_ID,\r\n"
			+ "											 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
			+ "											 O.PKG_CNT TOT_PKG_CNT,\r\n"
			+ "											 O.TOT_ORD_LN_CNT,\r\n"
			+ "											 O.TOT_UNIT_CNT,\r\n"
			+ "											 O.TOT_MRCH_PRICE_AMT,\r\n"
			+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
			+ "										FROM     Q.PKG_STAT_SUM_A O \r\n"
			+ "											 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
			+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
			+ "						\r\n"
			+ "								) C\r\n"
			+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
			+ "							) D\r\n"
			+ "						WHERE\r\n"
			+ "							OAT.OSCR_ACTV_TBL_CD = 'A' \r\n"
			+ "							\r\n"
			+ "						UNION ALL\r\n"
			+ "						\r\n"
			+ "						\r\n"
			+ "						SELECT\r\n"
			+ "							 D.ORD_FLOW_STAT_ID,\r\n"
			+ "						         D.DC_ID AS DC_ID,\r\n"
			+ "						         NULL AS AGE_BUCKET_CD,\r\n"
			+ "						         D.IS_EXCPTN_IND,\r\n"
			+ "						         D.TOT_ORD_LN_CNT,\r\n"
			+ "						         D.TOT_UNIT_CNT,\r\n"
			+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
			+ "						         D.TOT_PKG_CNT	\r\n"
			+ "						FROM\r\n"
			+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
			+ "							(\r\n"
			+ "								SELECT   \r\n"
			+ "									 C.ORD_FLOW_STAT_ID,\r\n"
			+ "									 C.DC_ID AS DC_ID,\r\n"
			+ "									 C.IS_EXCPTN_IND,\r\n"
			+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
			+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
			+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
			+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
			+ "								FROM     \r\n"
			+ "								(\r\n"
			+ "									SELECT   \r\n"
			+ "										 O.ORD_FLOW_STAT_ID,\r\n"
			+ "										 NULL AS DC_ID,\r\n"
			+ "										 0 AS TOT_PKG_CNT,\r\n"
			+ "										 TOT_ORD_LN_CNT,\r\n"
			+ "										 TOT_UNIT_CNT,\r\n"
			+ "										 TOT_MRCH_PRICE_AMT,\r\n"
			+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
			+ "									FROM     Q.ORD_STAT_SUM_B O \r\n"
			+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
			+ "									UNION ALL\r\n"
			+ "									SELECT   O.ORD_FLOW_STAT_ID,\r\n"
			+ "										 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
			+ "										 O.PKG_CNT TOT_PKG_CNT,\r\n"
			+ "										 O.TOT_ORD_LN_CNT,\r\n"
			+ "										 O.TOT_UNIT_CNT,\r\n"
			+ "										 O.TOT_MRCH_PRICE_AMT,\r\n"
			+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
			+ "									FROM     Q.PKG_STAT_SUM_B O \r\n"
			+ "										 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
			+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
			+ "						\r\n"
			+ "								) C\r\n"
			+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
			+ "							) D\r\n"
			+ "						WHERE\r\n"
			+ "							OAT.OSCR_ACTV_TBL_CD = 'B'\r\n"
			+ ")T\r\n"
			+ "\r\n"
			+ "JOIN \r\n"
			+ "(SELECT\r\n"
			+ "					ord_flow_stat_id,\r\n"
			+ "					busn_proc_typ_dsc,\r\n"
			+ "					busn_acty_typ_dsc,\r\n"
			+ "					ord_flow_sum_dsc,\r\n"
			+ "					ord_flow_rsn_dsc,\r\n"
			+ "					busn_proc_typ_cd,\r\n"
			+ "					busn_acty_typ_cd,\r\n"
			+ "					ord_flow_sum_cd,\r\n"
			+ "					ord_flow_rsn_cd,\r\n"
			+ "					is_excptn_ind,\r\n"
			+ "					ord_flow_lvl_dsc,\r\n"
			+ "					is_oscrol_ind,\r\n"
			+ "					is_oscrpkd_ind,\r\n"
			+ "					is_oscrpkq_ind\r\n"
			+ "				FROM\r\n"
			+ "					q.ord_flow_stat_vw with(nolock)		\r\n"
			+ "WHERE is_oscrol_ind = 'Yes' OR is_oscrpkd_ind = 'Yes' OR is_oscrpkq_ind = 'Yes') VW on VW.ord_flow_stat_id = T.ord_flow_stat_id";
	
	*/ 
    /*String orderSummaryQuery = "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED\r\n"
				+ "			SELECT T.ORD_FLOW_STAT_ID,\r\n"
				+ "						         T.DC_ID AS DC_ID,\r\n"
				+ "						         NUll AS AGE_BUCKET_CD,\r\n"
				+ "						         T.IS_EXCPTN_IND,\r\n"
				+ "						         T.TOT_ORD_LN_CNT,\r\n"
				+ "						         T.TOT_UNIT_CNT,\r\n"
				+ "						         T.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         T.TOT_PKG_CNT,\r\n"
				+ "						         VW.*\r\n"
				+ "\r\n"
				+ "FROM\r\n"
				+ "(\r\n"
				+ "SELECT 	D.ORD_FLOW_STAT_ID,\r\n"
				+ "						         D.DC_ID AS DC_ID,\r\n"
				+ "						         NUll AS AGE_BUCKET_CD,\r\n"
				+ "						         D.IS_EXCPTN_IND,\r\n"
				+ "						         D.TOT_ORD_LN_CNT,\r\n"
				+ "						         D.TOT_UNIT_CNT,\r\n"
				+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         D.TOT_PKG_CNT	\r\n"
				+ "						FROM\r\n"
				+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
				+ "							(\r\n"
				+ "								SELECT   \r\n"
				+ "									 C.ORD_FLOW_STAT_ID,\r\n"
				+ "									 C.DC_ID AS DC_ID,\r\n"
				+ "									 C.IS_EXCPTN_IND,\r\n"
				+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
				+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
				+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
				+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
				+ "								FROM     (\r\n"
				+ "										SELECT   \r\n"
				+ "											 O.ORD_FLOW_STAT_ID,\r\n"
				+ "											 NULL AS DC_ID,\r\n"
				+ "											 0 AS TOT_PKG_CNT,\r\n"
				+ "											 TOT_ORD_LN_CNT,\r\n"
				+ "											 TOT_UNIT_CNT,\r\n"
				+ "											 TOT_MRCH_PRICE_AMT,\r\n"
				+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "										FROM     Q.ORD_STAT_SUM_A O \r\n"
				+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "									UNION ALL\r\n"
				+ "										SELECT   O.ORD_FLOW_STAT_ID,\r\n"
				+ "											 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
				+ "											 O.PKG_CNT TOT_PKG_CNT,\r\n"
				+ "											 O.TOT_ORD_LN_CNT,\r\n"
				+ "											 O.TOT_UNIT_CNT,\r\n"
				+ "											 O.TOT_MRCH_PRICE_AMT,\r\n"
				+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "										FROM     Q.PKG_STAT_SUM_A O \r\n"
				+ "											 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
				+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "					WHERE O.LAST_UPD_TMS >= ? and O.LAST_UPD_TMS <=?	\r\n"
				+ "								) C\r\n"
				+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
				+ "							) D\r\n"
				+ "						WHERE\r\n"
				+ "							OAT.OSCR_ACTV_TBL_CD = 'A' \r\n"
				+ "							\r\n"
				+ "						UNION ALL\r\n"
				+ "						\r\n"
				+ "						\r\n"
				+ "						SELECT\r\n"
				+ "							 D.ORD_FLOW_STAT_ID,\r\n"
				+ "						         D.DC_ID AS DC_ID,\r\n"
				+ "						         NULL AS AGE_BUCKET_CD,\r\n"
				+ "						         D.IS_EXCPTN_IND,\r\n"
				+ "						         D.TOT_ORD_LN_CNT,\r\n"
				+ "						         D.TOT_UNIT_CNT,\r\n"
				+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         D.TOT_PKG_CNT	\r\n"
				+ "						FROM\r\n"
				+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
				+ "							(\r\n"
				+ "								SELECT   \r\n"
				+ "									 C.ORD_FLOW_STAT_ID,\r\n"
				+ "									 C.DC_ID AS DC_ID,\r\n"
				+ "									 C.IS_EXCPTN_IND,\r\n"
				+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
				+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
				+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
				+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
				+ "								FROM     \r\n"
				+ "								(\r\n"
				+ "									SELECT   \r\n"
				+ "										 O.ORD_FLOW_STAT_ID,\r\n"
				+ "										 NULL AS DC_ID,\r\n"
				+ "										 0 AS TOT_PKG_CNT,\r\n"
				+ "										 TOT_ORD_LN_CNT,\r\n"
				+ "										 TOT_UNIT_CNT,\r\n"
				+ "										 TOT_MRCH_PRICE_AMT,\r\n"
				+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "									FROM     Q.ORD_STAT_SUM_B O \r\n"
				+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1' WHERE O.LAST_UPD_TMS >= ? and O.LAST_UPD_TMS <=?\r\n"
				+ "\r\n"
				+ "									UNION ALL\r\n"
				+ "									SELECT   O.ORD_FLOW_STAT_ID,\r\n"
				+ "										 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
				+ "										 O.PKG_CNT TOT_PKG_CNT,\r\n"
				+ "										 O.TOT_ORD_LN_CNT,\r\n"
				+ "										 O.TOT_UNIT_CNT,\r\n"
				+ "										 O.TOT_MRCH_PRICE_AMT,\r\n"
				+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "									FROM     Q.PKG_STAT_SUM_B O \r\n"
				+ "										 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
				+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "						WHERE  O.LAST_UPD_TMS >= ? and O.LAST_UPD_TMS <=?\r\n"
				+ "								) C\r\n"
				+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
				+ "							) D\r\n"
				+ "						WHERE\r\n"
				+ "							OAT.OSCR_ACTV_TBL_CD = 'B'\r\n"
				+ ")T\r\n"
				+ "\r\n"
				+ "JOIN \r\n"
				+ "(SELECT\r\n"
				+ "					ord_flow_stat_id,\r\n"
				+ "					busn_proc_typ_dsc,\r\n"
				+ "					busn_acty_typ_dsc,\r\n"
				+ "					ord_flow_sum_dsc,\r\n"
				+ "					ord_flow_rsn_dsc,\r\n"
				+ "					busn_proc_typ_cd,\r\n"
				+ "					busn_acty_typ_cd,\r\n"
				+ "					ord_flow_sum_cd,\r\n"
				+ "					ord_flow_rsn_cd,\r\n"
				+ "					is_excptn_ind,\r\n"
				+ "					ord_flow_lvl_dsc,\r\n"
				+ "					ord_flow_stat_dsc,\r\n"
				+ "					is_oscrol_ind,\r\n"
				+ "					is_oscrpkd_ind,\r\n"
				+ "					is_oscrpkq_ind\r\n"
				+ "				FROM\r\n"
				+ "					q.ord_flow_stat_vw with(nolock)		\r\n"
				+ "WHERE is_oscrol_ind = 'Yes' OR is_oscrpkd_ind = 'Yes' OR is_oscrpkq_ind = 'Yes') VW on VW.ord_flow_stat_id = T.ord_flow_stat_id  ";
		*/

	String orderSummaryQuery ="SELECT   O.ord_flow_stat_id,\r\n" +
			"         O.tot_ord_ln_cnt,\r\n" +
			"         vw1.busn_proc_typ_dsc,\r\n" +
			"         vw1.busn_acty_typ_dsc,\r\n" +
			"         vw1.ord_flow_sum_dsc,\r\n" +
			"         vw1.ord_flow_rsn_dsc,\r\n" +
			"         vw1.busn_proc_typ_cd,\r\n" +
			"         vw1.busn_acty_typ_cd,\r\n" +
			"         vw1.ord_flow_sum_cd,\r\n" +
			"         vw1.ord_flow_rsn_cd,\r\n" +
			"         vw1.is_excptn_ind,\r\n" +
			"         vw1.ord_flow_lvl_dsc,\r\n" +
			"         vw1.is_oscrol_ind,\r\n" +
			"         vw1.is_oscrpkd_ind,\r\n" +
			"         vw1.ord_flow_stat_dsc,\r\n" +
			"         vw1.is_oscrpkq_ind\r\n" +
			"FROM     q.ord_flow_stat_vw VW1 with(nolock) \r\n" +
			"         join ( SELECT aol.ord_flow_stat_id, VW.busn_proc_typ_dsc,COUNT(aol.ord_ln_nbr) as tot_ord_ln_cnt from q.active_ord_ln aol \r\n" +
			"         inner join q.ord_flow_stat_vw VW with(nolock) on VW.ord_flow_stat_id = aol.ord_flow_stat_id and VW.busn_proc_typ_dsc = 'Demand Management' and ( VW.is_oscrol_ind = 'Yes' OR VW.is_oscrpkd_ind = 'Yes' OR VW.is_oscrpkq_ind = 'Yes'  ) and  aol.LAST_UPD_TMS>=? and aol.LAST_UPD_TMS<=? and VW.IS_EXCPTN_IND=?\r\n" +
			"         LEFT\r\n" +
			" join Q.ORD_FLOW_STAT_ATTR ofsa with (nolock) on VW.ord_flow_stat_id = ofsa.ord_flow_stat_id and ofsa.ORD_FLOW_ATTR_CD = 'ISEX1' \r\n" +
			"group by aol.ord_flow_stat_id, VW.busn_proc_typ_dsc )O on O.ord_flow_stat_id = VW1.ord_flow_stat_id ";

	String itExceptionsWhereClause = "  AND VW1.is_excptn_ind = 'Yes' ";

	String financeOrderWhereSQL = "   WHERE VW.busn_proc_typ_dsc = 'Demand Management'";

String getPackageNotCreatedOrdersQuery="\n" +
		"select aol.ORD_NBR,aol.ACCT_NBR, aol.ORD_LN_NBR, aol.ITEM_NBR, aol.REVSD_ESTDELVRY_DT, aol.SHIP_BY_DT, aol.ORD_DT, aol.LAST_UPD_TMS, aol.STAT_EFF_TMS\n" +
		"\n" +
		"FROM Q.ACTV_PKG ap, q.active_ord_ln aol, q.package_ol_rel por where \n" +
		"por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR\n" +
		"AND ap.PKG_ID =por.PKG_ID\n" +
		"and aol.ord_flow_stat_id in ('500000','500500','500010','630000')\n" +
		"and ap.ord_flow_stat_id='2470000'\n" +
		"and aol.ord_dt >= ? and aol.ord_dt <= ?\n" +
		"and not exists  (select ap1.pkg_id from Q.ACTV_PKG ap1,  q.package_ol_rel por1 where \n" +
		"por1.ORD_NBR = aol.ORD_NBR AND por1.ORD_LN_NBR = AOL.ORD_LN_NBR\n" +
		"AND ap1.PKG_ID =por1.PKG_ID \n" +
		"and ap1.actv_ind='y' )";
	String packageNotCreatedQuery= "SELECT   O.ord_flow_stat_id,\r\n" +
			"         O.tot_ord_ln_cnt,\r\n" +
			"         vw1.busn_proc_typ_dsc,\r\n" +
			"         vw1.busn_acty_typ_dsc,\r\n" +
			"         vw1.ord_flow_sum_dsc,\r\n" +
			"         vw1.ord_flow_rsn_dsc,\r\n" +
			"         vw1.busn_proc_typ_cd,\r\n" +
			"         vw1.busn_acty_typ_cd,\r\n" +
			"         vw1.ord_flow_sum_cd,\r\n" +
			"         vw1.ord_flow_rsn_cd,\r\n" +
			"         vw1.is_excptn_ind,\r\n" +
			"         vw1.ord_flow_lvl_dsc,\r\n" +
			"         vw1.is_oscrol_ind,\r\n" +
			"         vw1.is_oscrpkd_ind,\r\n" +
			"         vw1.ord_flow_stat_dsc,\r\n" +
			"         vw1.is_oscrpkq_ind\r\n" +
			"FROM     q.ord_flow_stat_vw VW1 with(nolock) \r\n" +
			"         join (\r\n" +
			"select ap.ord_flow_stat_id, count(aol.ord_ln_nbr) as tot_ord_ln_cnt\r\n" +
			"\r\n" +
			"FROM Q.ACTV_PKG ap, q.active_ord_ln aol, q.package_ol_rel por where \r\n" +
			"por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR\r\n" +
			"AND ap.PKG_ID =por.PKG_ID\r\n" +
			"and aol.ord_flow_stat_id in ('500000','500500','500010','630000')\r\n" +
			"and ap.ord_flow_stat_id='2470000'\r\n" +
			"and aol.ord_dt >= ? and aol.ord_dt <= ?\r\n" +
			//"and aol.ord_dt >= '2020-07-18 09:18:20.500' and aol.ord_dt <= current_timestamp \r\n"+
			"and not exists  (select ap1.pkg_id from Q.ACTV_PKG ap1,  q.package_ol_rel por1 where \r\n" +
			"por1.ORD_NBR = aol.ORD_NBR AND por1.ORD_LN_NBR = AOL.ORD_LN_NBR\r\n" +
			"AND ap1.PKG_ID =por1.PKG_ID \r\n" +
			"and ap1.actv_ind='y' )\r\n" +
			"group by ap.ord_flow_stat_id\r\n" +
			") o on o.ord_flow_stat_id=vw1.ord_flow_stat_id";
	
	
	
	@SuppressWarnings("deprecation")
	public List<OrderFlowExceptions> getBusinessExceptions(Date startDate, Date endDate) {
		List<OrderFlowExceptions> demandManagementBusinessExceptionsList = new ArrayList<>();
		System.out.println("DM Bussiness Exception");
		try {
			demandManagementBusinessExceptionsList = jdbcTemplate.query(orderSummaryQuery ,new Object[] { startDate, endDate,"NO"}, new OrderFlowRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return demandManagementBusinessExceptionsList;
	}

	@SuppressWarnings("deprecation")
	public List<OrderFlowExceptions> getITExceptions(Date startDate, Date endDate) {
		List<OrderFlowExceptions> demandManagementITExceptionsList = new ArrayList<>();
		System.out.println("DM IT Exception");
		try {
			demandManagementITExceptionsList = jdbcTemplate.query(orderSummaryQuery + itExceptionsWhereClause,new Object[] {startDate, endDate,"YES"} ,new OrderFlowRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return demandManagementITExceptionsList;
	}

	public OrderFlowExceptions getpackageNotCreated(Date startDate,Date endDate) {
		System.out.println("getpackageNotCreated: ");
		OrderFlowExceptions demandManagementITExceptions =new OrderFlowExceptions();
		System.out.println("DM IT Exception");
		try {
			demandManagementITExceptions = jdbcTemplate.queryForObject(packageNotCreatedQuery
					,new Object[]{startDate,endDate}
					,new OrderFlowRowMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return demandManagementITExceptions;
	}



	public List<OrderDetailsModel> getpackageNotCreatedOrderDetails(Date startDate,Date endDate) {
		List<OrderDetailsModel> orderDetails = new ArrayList<>();
		System.out.println("Order Query:");
		try {
			orderDetails = jdbcTemplate.query(getPackageNotCreatedOrdersQuery, new Object[] {startDate, endDate }, new OrderDetailsModelRowMapper());

		} catch (Exception e) {
			log.error("Exception in getorderDetailsJSON ::: " , e);
		}
		System.out.println("\n\n OrderDetails List:::"+orderDetails);
		return orderDetails;
	}

	@Override
	public List<OrderDetailsModel> getorderDetailsJSON(int status, Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderFlowStatVWModel getOrderFlowStatusVW(String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PackageDetailsModel> getPackageDetails(String status, Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
