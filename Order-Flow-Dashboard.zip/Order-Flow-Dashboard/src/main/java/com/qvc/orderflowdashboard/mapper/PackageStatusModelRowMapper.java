package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.PackageStatusModel;
import com.qvc.orderflowdashboard.entity.CellDataPoint;

public class PackageStatusModelRowMapper implements RowMapper<PackageStatusModel> {

	public PackageStatusModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		PackageStatusModel packageStatusModel= new PackageStatusModel();
		try{
			   packageStatusModel.setWareHouseName(rs.getString("WAREHOUSE").trim());
        packageStatusModel.setStatusId(rs.getBigDecimal("ORD_FLOW_STAT_ID"));
        packageStatusModel.setLast1Hour(new CellDataPoint( rs.getBigDecimal("HRS_LT1_PKGS")));
        packageStatusModel.setLast1To3Hour(new CellDataPoint(rs.getBigDecimal("HRS_1TO3_PKGS")));
        packageStatusModel.setLast3To6Hour(new CellDataPoint(rs.getBigDecimal("HRS_3TO6_PKGS")));
        packageStatusModel.setLast6To24Hour(new CellDataPoint(rs.getBigDecimal("HRS_6TO24_PKGS")));
        packageStatusModel.setLast24To48Hour(new CellDataPoint(rs.getBigDecimal("HRS_24TO_48_PKGS")));
        
        packageStatusModel.setLast48To72Hour(new CellDataPoint(rs.getBigDecimal("HRS_48TO_72_PKGS")));
        packageStatusModel.setGreaterThan72Hour(new CellDataPoint(rs.getBigDecimal("HRS_GT72_PKGS")));
        packageStatusModel.setTotalOrders(rs.getBigDecimal("TOTAL_Orders"));
        
        
        packageStatusModel.setBusnActyTypDsc(rs.getString("busn_acty_typ_dsc").trim());
        packageStatusModel.setOrdFlowRsnDsc(rs.getString("ord_flow_rsn_dsc").trim());
        packageStatusModel.setOrdFlowStatDsc(rs.getString("ord_flow_stat_dsc").trim());
        packageStatusModel.setOrdFlowSumDsc(rs.getString("ord_flow_sum_dsc").trim());
        packageStatusModel.setService(rs.getString("busn_proc_typ_dsc").trim());
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

        return packageStatusModel;
	}

}
