package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderStatusModel;
import com.qvc.orderflowdashboard.entity.CellDataPoint;

public class OrderStatusModelRowMapper implements RowMapper<OrderStatusModel> {

	public OrderStatusModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderStatusModel orderStatusModel= new OrderStatusModel();
		try{
			   orderStatusModel.setStatusName(rs.getString("STATUS_NAME").trim());
        orderStatusModel.setStatusId(rs.getBigDecimal("ORD_FLOW_STAT_ID"));
        
        orderStatusModel.setTotalOrders(rs.getBigDecimal("TOTAL_Orders"));
        
        
        orderStatusModel.setLst24Hour(new CellDataPoint(rs.getBigDecimal("HRS_LT24_ORDS")));
        orderStatusModel.setLst24To48Hour(new CellDataPoint(rs.getBigDecimal("HRS_24TO48_ORDS")));
        orderStatusModel.setAbv72Hour(new CellDataPoint(rs.getBigDecimal("HRS_GT72_ORDS")));
        orderStatusModel.setLst48To72Hour(new CellDataPoint(rs.getBigDecimal("HRS_48TO72_ORDS")));
        
        
       
		 orderStatusModel.setBusnActyTypDsc(rs.getString("busn_acty_typ_dsc").trim());
      
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

        return orderStatusModel;
	}

}
