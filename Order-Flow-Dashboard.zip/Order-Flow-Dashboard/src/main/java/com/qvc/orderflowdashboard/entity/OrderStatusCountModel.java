package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;

public class OrderStatusCountModel {
	
	private BigDecimal orderStatus;
	private BigDecimal count;
	private String colorFlag;
	private String service;
	private String ordFlowSumDsc;
	private String busnActyTypDsc;
	private String ordFlowRsnDsc;
	private String ordFlowStatDsc;
	
	public String getColorFlag() {
		return colorFlag;
	}
	public void setColorFlag(String colorFlag) {
		this.colorFlag = colorFlag;
	}
	public BigDecimal getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(BigDecimal orderStatus) {
		this.orderStatus = orderStatus;
	}
	public BigDecimal getCount() {
		return count;
	}
	public void setCount(BigDecimal count) {
		this.count = count;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getOrdFlowSumDsc() {
		return ordFlowSumDsc;
	}
	public void setOrdFlowSumDsc(String ordFlowSumDsc) {
		this.ordFlowSumDsc = ordFlowSumDsc;
	}
	public String getBusnActyTypDsc() {
		return busnActyTypDsc;
	}
	public void setBusnActyTypDsc(String busnActyTypDsc) {
		this.busnActyTypDsc = busnActyTypDsc;
	}
	public String getOrdFlowRsnDsc() {
		return ordFlowRsnDsc;
	}
	public void setOrdFlowRsnDsc(String ordFlowRsnDsc) {
		this.ordFlowRsnDsc = ordFlowRsnDsc;
	}
	public String getOrdFlowStatDsc() {
		return ordFlowStatDsc;
	}
	public void setOrdFlowStatDsc(String ordFlowStatDsc) {
		this.ordFlowStatDsc = ordFlowStatDsc;
	}

	@Override
	public String toString() {
		return "\nOrderStatusModel [orderStatus=" + orderStatus + ", count=" + count + ", colorFlag=" + colorFlag
				+ ", service=" + service + ", ordFlowSumDsc=" + ordFlowSumDsc + ", busnActyTypDsc=" + busnActyTypDsc
				+ ", ordFlowRsnDsc=" + ordFlowRsnDsc + ", ordFlowStatDsc=" + ordFlowStatDsc + "]";
	}

	
	

}
