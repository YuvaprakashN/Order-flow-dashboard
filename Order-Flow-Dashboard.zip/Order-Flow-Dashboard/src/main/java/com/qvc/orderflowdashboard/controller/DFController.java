package com.qvc.orderflowdashboard.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qvc.orderflowdashboard.model.OrderFlowModel;
import com.qvc.orderflowdashboard.service.DFService;
import com.qvc.orderflowdashboard.service.DashboardService;

//@RestController
@Controller
public class DFController {

	private final DashboardService dashboardService;
	private final DFService dFOrderFlowService;

	public DFController(DashboardService dashboardService, DFService dFOrderFlowService) {
		this.dashboardService = dashboardService;
		this.dFOrderFlowService = dFOrderFlowService;
	}

	@GetMapping("/loadDFBusinessExceptionsTable")
	@ResponseBody
	public List<OrderFlowModel> loadDFBusinessExceptionsTable(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		Date stsEffTm = dashboardService.convertJSDateToDate(startDate);
		Date updTimeStamp = dashboardService.convertJSDateToDate(endDate);
		return dFOrderFlowService.getDFBusinessExceptions(stsEffTm, updTimeStamp);
	}

	@GetMapping("/loadDFITExceptionsTable")
	@ResponseBody

	public List<OrderFlowModel> loadDFITExceptionsTable(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		Date start = dashboardService.convertJSDateToDate(startDate);
		Date end = dashboardService.convertJSDateToDate(endDate);
		return dFOrderFlowService.getDFITExceptions(start, end);
	}

}
