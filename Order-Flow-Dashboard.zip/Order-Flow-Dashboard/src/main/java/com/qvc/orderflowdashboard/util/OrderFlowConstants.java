package com.qvc.orderflowdashboard.util;

import java.util.HashMap;
import java.util.Map;

public class OrderFlowConstants {
	public static final int DASHBOARD_CHART_DURATION = -30;
	public static Map<Integer, String> StatusDescMap;
	static {
		StatusDescMap = new HashMap<>();
		StatusDescMap.put(630000, "Packages Allocated to Shipping DC");
		StatusDescMap.put(680000, "Sent to Dropship vendor/QVC");
		StatusDescMap.put(670000, "Packages Selected, not transmitted to DC");
		StatusDescMap.put(725000, "QVC Confirmed Receipt");
		StatusDescMap.put(725100, "QVC Confirmed Receipt");
		StatusDescMap.put(780000, "Sent to Dropshipper");
		StatusDescMap.put(790000, "Dropshipper Confirmed Receipt");
		
		StatusDescMap.put(2190000, "Inventory Rules Evaluation");
		StatusDescMap.put(2210000, "Inventory Hold");
		StatusDescMap.put(2230000, "Manage Inventory");
		StatusDescMap.put(2250000, "Manage Time Based Events");
		StatusDescMap.put(2270000, "Prioritize Order Line");
		StatusDescMap.put(3140000, "Order Flow Management");		
		StatusDescMap.put(3170000, "Order Catcher");
		
	}
}

