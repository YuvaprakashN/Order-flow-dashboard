package com.qvc.orderflowdashboard.entity;

public class OrderFlowEntity {

	private String warehouse;
	private int statusId;
	private int last1Hour;
	private int last1To3Hour;
	private int last3To6Hour;
	private int last6To24Hour;
	private int last24To48Hour;
	private int last48To78Hour;
	private int greaterThan72Hour;
	private int totalPackage;
	public OrderFlowEntity() {
		super();
	}
	public String getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(String warehouse) {
		this.warehouse = warehouse;
	}
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public int getLast1Hour() {
		return last1Hour;
	}
	public void setLast1Hour(int last1Hour) {
		this.last1Hour = last1Hour;
	}
	public int getLast1To3Hour() {
		return last1To3Hour;
	}
	public void setLast1To3Hour(int last1To3Hour) {
		this.last1To3Hour = last1To3Hour;
	}
	public int getLast3To6Hour() {
		return last3To6Hour;
	}
	public void setLast3To6Hour(int last3To6Hour) {
		this.last3To6Hour = last3To6Hour;
	}
	public int getLast6To24Hour() {
		return last6To24Hour;
	}
	public void setLast6To24Hour(int last6To24Hour) {
		this.last6To24Hour = last6To24Hour;
	}
	public int getLast24To48Hour() {
		return last24To48Hour;
	}
	public void setLast24To48Hour(int last24To48Hour) {
		this.last24To48Hour = last24To48Hour;
	}
	public int getGreaterThan72Hour() {
		return greaterThan72Hour;
	}
	public void setGreaterThan72Hour(int greaterThan72Hour) {
		this.greaterThan72Hour = greaterThan72Hour;
	}
	public int getTotalPackage() {
		return totalPackage;
	}
	public void setTotalPackage(int totalPackage) {
		this.totalPackage = totalPackage;
	}
	@Override
	public String toString() {
		return "OrderFlowEntity [\nwarehouse=" + warehouse + ", statusId=" + statusId + ", last1Hour=" + last1Hour
				+ ", last1To3Hour=" + last1To3Hour + ", last3To6Hour=" + last3To6Hour + ", last6To24Hour="
				+ last6To24Hour + ", last24To48Hour=" + last24To48Hour + ", greaterThan72Hour=" + greaterThan72Hour
				+ ", totalPackage=" + totalPackage + "]";
	}
	public int getLast48To78Hour() {
		return last48To78Hour;
	}
	public void setLast48To78Hour(int last48To78Hour) {
		this.last48To78Hour = last48To78Hour;
	}
	
	
	
}
