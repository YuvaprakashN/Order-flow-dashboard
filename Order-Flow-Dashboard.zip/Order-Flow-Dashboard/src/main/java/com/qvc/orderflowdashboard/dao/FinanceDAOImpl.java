package com.qvc.orderflowdashboard.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.qvc.orderflowdashboard.controller.DashboardRESTController;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.qvc.orderflowdashboard.mapper.OrderDetailsModelRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderFlowRowMapper;
import com.qvc.orderflowdashboard.mapper.OrderFlowStatVWModelRowMapper;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;


@Repository
@Qualifier("financeDAO")
public class FinanceDAOImpl implements OrderFlowDAO{

	 private static final org.slf4j.Logger log = LoggerFactory.getLogger(FinanceDAOImpl.class);
	
	 @Autowired
	 @Qualifier("jdbcTemplate1")
	 private JdbcTemplate jdbcTemplate;
	 
	 /*@Autowired
	 @Qualifier("jdbcTemplate2")
	 private JdbcTemplate jdbcTemplate2;*/

	 
	 String orderSummaryQuery ="SELECT   O.ord_flow_stat_id,\r\n" + 
	 		"         O.tot_ord_ln_cnt,\r\n" + 
	 		"         vw1.busn_proc_typ_dsc,\r\n" + 
	 		"         vw1.busn_acty_typ_dsc,\r\n" + 
	 		"         vw1.ord_flow_sum_dsc,\r\n" + 
	 		"         vw1.ord_flow_rsn_dsc,\r\n" + 
	 		"         vw1.busn_proc_typ_cd,\r\n" + 
	 		"         vw1.busn_acty_typ_cd,\r\n" + 
	 		"         vw1.ord_flow_sum_cd,\r\n" + 
	 		"         vw1.ord_flow_rsn_cd,\r\n" + 
	 		"         vw1.is_excptn_ind,\r\n" + 
	 		"         vw1.ord_flow_lvl_dsc,\r\n" + 
	 		"         vw1.is_oscrol_ind,\r\n" + 
	 		"         vw1.is_oscrpkd_ind,\r\n" + 
	 		"         vw1.ord_flow_stat_dsc,\r\n" + 
	 		"         vw1.is_oscrpkq_ind\r\n" + 
	 		"FROM     q.ord_flow_stat_vw VW1 with(nolock) \r\n" + 
	 		"         join ( SELECT aol.ord_flow_stat_id, VW.busn_proc_typ_dsc,COUNT(aol.ord_ln_nbr) as tot_ord_ln_cnt from q.active_ord_ln aol \r\n" + 
	 		"         inner join q.ord_flow_stat_vw VW with(nolock) on VW.ord_flow_stat_id = aol.ord_flow_stat_id and VW.busn_proc_typ_dsc = 'Order Credit Services' and ( VW.is_oscrol_ind = 'Yes' OR VW.is_oscrpkd_ind = 'Yes' OR VW.is_oscrpkq_ind = 'Yes' )  and VW.IS_EXCPTN_IND=? and  aol.LAST_UPD_TMS>=? and aol.LAST_UPD_TMS<=?\r\n" + 
	 		"         LEFT\r\n" + 
	 		" join Q.ORD_FLOW_STAT_ATTR ofsa with (nolock) on VW.ord_flow_stat_id = ofsa.ord_flow_stat_id and ofsa.ORD_FLOW_ATTR_CD = 'ISEX1' \r\n" + 
	 		"group by aol.ord_flow_stat_id, VW.busn_proc_typ_dsc )O on O.ord_flow_stat_id = VW1.ord_flow_stat_id ";
	
	 
	 String itExceptionsWhereClause = "  AND VW1.is_excptn_ind = 'Yes' ";
	
	String financeOrderWhereSQL = "   WHERE VW1.busn_proc_typ_dsc = 'Order Credit Services'";
	
	
	String orderDetailQuery=
			"select aol.ORD_NBR,aol.ACCT_NBR, aol.ORD_LN_NBR, aol.ITEM_NBR, aol.REVSD_ESTDELVRY_DT, aol.SHIP_BY_DT, aol.ORD_DT, aol.LAST_UPD_TMS, aol.STAT_EFF_TMS from q.ACTIVE_ORD_LN aol where aol.ORD_FLOW_STAT_ID =? and aol.LAST_UPD_TMS>=? and aol.LAST_UPD_TMS<=?";
	
	
	public final String financePieChartOutFlow="SELECT   count(*)\r\n" + 
			"FROM     qord.ordmline ol with (nolock) \r\n" + 
			"          join q.ORD_LN_STAT_HIST olh with (nolock) on ol.ORD_NBR=olh.ORD_NBR and ol.ORD_LN_NBR=olh.ORD_LN_NBR \r\n" + 
			"        \r\n" + 
			"WHERE    ol.ord_flow_stat_id not in ('320000','340000')\r\n" + 
			"AND      olh.ord_flow_stat_id='320000'\r\n" + 
			
			"AND      olh.INSRT_TMS>= dateadd(day,-30,CURRENT_TIMESTAMP);";
	
	public final String financePieChartInflowCount ="select count(*) from q.ORD_LN_STAT_HIST olh with(nolock) where olh.ord_flow_stat_id='320000'\r\n" + 
			"AND     olh.INSRT_TMS>= dateadd(day,-30,CURRENT_TIMESTAMP);";
		
	public final String financePieChartReleaseCount ="SELECT   count(*)\r\n" + 
			"FROM     ( SELECT   Distinct aol.ord_nbr,\r\n" + 
			"         aol.ord_ln_nbr\r\n" + 
			"FROM     q.ACTIVE_ORD_LN aol with (nolock) \r\n" + 
			"         join q.ORD_LN_STAT_HIST olh with (nolock) on olh.ord_nbr=aol.ord_nbr and aol.ord_ln_nbr = olh.ord_ln_nbr\r\n" + 
			"WHERE    olh.INSRT_TMS >= dateadd(day,-30,CURRENT_TIMESTAMP)\r\n" + 
			"AND      olh.INSRT_TMS <= CURRENT_TIMESTAMP\r\n" + 
			"AND      olh.ORD_FLOW_STAT_ID ='320000'\r\n" + 
			"and aol.ord_flow_stat_id='340000' ) as a";
	
	public String stuckOrderHoldCountQuery="SELECT   count(*)\r\n" + 
			"FROM     ( SELECT   Distinct aol.ord_nbr,  aol.ord_ln_nbr\r\n" + 
			"FROM     q.ACTIVE_ORD_LN aol with (nolock) \r\n" + 
			"         join q.ORD_LN_STAT_HIST olh with (nolock) on olh.ord_nbr=aol.ord_nbr and aol.ord_ln_nbr = olh.ord_ln_nbr\r\n" + 
			"WHERE    olh.INSRT_TMS >= ?\r\n" + 
			"AND      olh.INSRT_TMS <= ?\r\n" + 
			"AND      olh.ORD_FLOW_STAT_ID ='320000' ) as a";
	
	
	@SuppressWarnings("deprecation")
	public int financeHoldOrderCount(Date startDate,Date endDate) {
		Integer count=0;
		try {
		count = jdbcTemplate.queryForObject(stuckOrderHoldCountQuery, new Object[] { startDate,endDate },Integer.class);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return count;
	}
	
	public Integer getFinancePieChartReleaseCount() {

		int financePieChartRelease=0;
		try {
			financePieChartRelease = jdbcTemplate.queryForObject(
					financePieChartReleaseCount,Integer.class);
		} catch (Exception e) {
			System.out.println(e);
		}
		return financePieChartRelease;
	}
	
	public Integer getFinancePieChartInflowCount() {

		//List<OrderStatusCountModel> financeHoldOrders = new ArrayList<>();
		int financeInflow=0;
		try {
			//System.out.println(colorFlagGreen);
			financeInflow = jdbcTemplate.queryForObject(
					financePieChartInflowCount,Integer.class);
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return financeInflow;
	}
	
	public Integer getFinancePieChartOutFlow() {

		int financeOutflow=0;
		try {
			financeOutflow = jdbcTemplate.queryForObject(
					financePieChartOutFlow,Integer.class);
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e);
		}
		return financeOutflow;
	}
	
	
	
	
	
	@SuppressWarnings("deprecation")
	public List<OrderFlowExceptions> getBusinessExceptions(Date startDate, Date endDate) {
		List<OrderFlowExceptions> financeBusinessExceptionsList = new ArrayList<>();
		System.out.println("Finance Business Exception Query:");
		try {
			financeBusinessExceptionsList = jdbcTemplate.query(orderSummaryQuery,new Object[] {"NO", startDate, endDate}, new OrderFlowRowMapper());
			//financeBusinessExceptionsList = jdbcTemplate.query(orderSummaryQuery + financeOrderWhereSQL, new OrderFlowRowMapper());
		} catch (Exception e) {
			log.error("Exception in getBusinessExceptions ::: " , e);
		}
		System.out.println("\n\n financeBusinessExceptionsList:::"+financeBusinessExceptionsList);
		return financeBusinessExceptionsList;
	}

	@SuppressWarnings("deprecation")
	public List<OrderFlowExceptions> getITExceptions(Date startDate, Date endDate) {
		List<OrderFlowExceptions> financeITExceptionsList = new ArrayList<>();
		System.out.println("Finance IT Exception Query:");
		//declareParameter(new SqlParameter(Types.DATE)); //start date
		//declareParameter(new SqlParameter(Types.DATE)); //end date
		try {
			financeITExceptionsList = jdbcTemplate.query(orderSummaryQuery  + itExceptionsWhereClause, new Object[] {"YES",startDate, endDate }, new OrderFlowRowMapper());
			
			//financeITExceptionsList = jdbcTemplate.query(orderSummaryQuery + financeOrderWhereSQL + itExceptionsWhereClause, new OrderFlowRowMapper());
		} catch (Exception e) {
			log.error("Exception in getITExceptions ::: " , e);
		}
		System.out.println("\n\n financeITExceptionsList:::"+financeITExceptionsList);
		return financeITExceptionsList;
	}
	
	@SuppressWarnings("deprecation")
	public List<OrderDetailsModel> getorderDetailsJSON(int status,Date startDate, Date endDate) {
		List<OrderDetailsModel> orderDetails = new ArrayList<>();
		System.out.println("Order Query:");
		try {
			orderDetails = jdbcTemplate.query(orderDetailQuery, new Object[] {status,startDate, endDate }, new OrderDetailsModelRowMapper());
			
		} catch (Exception e) {
			log.error("Exception in getorderDetailsJSON ::: " , e);
		}
		System.out.println("\n\n OrderDetails List:::"+orderDetails);
		return orderDetails;
	}
	
	
	
	String orderFlowStatQuery="select vw.ORD_FLOW_STAT_ID, vw.BUSN_PROC_TYP_DSC, vw.BUSN_ACTY_TYP_DSC, vw.ORD_FLOW_SUM_DSC, vw.ORD_FLOW_RSN_DSC, vw.ORD_FLOW_STAT_DSC from q.ord_flow_stat_vw vw where vw.ord_flow_stat_id=?";
	@SuppressWarnings("deprecation")
	public OrderFlowStatVWModel getOrderFlowStatusVW(String status) {
		OrderFlowStatVWModel orderFlowStatVWModel = new OrderFlowStatVWModel();
		System.out.println("Order Query:");
		try {
			orderFlowStatVWModel = jdbcTemplate.queryForObject(orderFlowStatQuery, new Object[] {status }, new OrderFlowStatVWModelRowMapper());
			
		} catch (Exception e) {
			log.error("Exception in getOrderFlowStatusVW ::: " , e);
		}
		System.out.println("\n\n orderFlowStatVWModel :::"+orderFlowStatVWModel);
		return orderFlowStatVWModel;
	}

	@Override
	public List<PackageDetailsModel> getPackageDetails(String status, Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderFlowExceptions getpackageNotCreated(Date startDate,Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
}
