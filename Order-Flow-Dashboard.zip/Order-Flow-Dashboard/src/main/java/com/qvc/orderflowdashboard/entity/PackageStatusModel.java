package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;

public class PackageStatusModel {
	private String wareHouseName;
	private String statusName;
	private BigDecimal statusId;
	
	private CellDataPoint last1Hour;
	private CellDataPoint last1To3Hour;
	private CellDataPoint last3To6Hour;
	private CellDataPoint last6To24Hour;
	private CellDataPoint last24To48Hour;
	private CellDataPoint last48To72Hour;
	private CellDataPoint greaterThan72Hour;
	private BigDecimal totalOrders;
	
	private String service;
	private String ordFlowSumDsc;
	private String busnActyTypDsc;
	private String ordFlowRsnDsc;
	private String ordFlowStatDsc;
	
	
	private String colorCode;

	
	
	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	

	public String getWareHouseName() {
		return wareHouseName;
	}

	public void setWareHouseName(String wareHouseName) {
		this.wareHouseName = wareHouseName;
	}

	public BigDecimal getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(BigDecimal totalOrders) {
		this.totalOrders = totalOrders;
	}

	public BigDecimal getStatusId() {
		return statusId;
	}

	public void setStatusId(BigDecimal statusId) {
		this.statusId = statusId;
	}

	public CellDataPoint getLast1Hour() {
		return last1Hour;
	}

	public void setLast1Hour(CellDataPoint last1Hour) {
		this.last1Hour = last1Hour;
	}

	public CellDataPoint getLast1To3Hour() {
		return last1To3Hour;
	}

	public void setLast1To3Hour(CellDataPoint last1To3Hour) {
		this.last1To3Hour = last1To3Hour;
	}

	public CellDataPoint getLast3To6Hour() {
		return last3To6Hour;
	}

	public void setLast3To6Hour(CellDataPoint last3To6Hour) {
		this.last3To6Hour = last3To6Hour;
	}

	public CellDataPoint getLast6To24Hour() {
		return last6To24Hour;
	}

	public void setLast6To24Hour(CellDataPoint last6To24Hour) {
		this.last6To24Hour = last6To24Hour;
	}

	public CellDataPoint getLast24To48Hour() {
		return last24To48Hour;
	}

	public void setLast24To48Hour(CellDataPoint last24To48Hour) {
		this.last24To48Hour = last24To48Hour;
	}

	public CellDataPoint getLast48To72Hour() {
		return last48To72Hour;
	}

	public void setLast48To72Hour(CellDataPoint last48To72Hour) {
		this.last48To72Hour = last48To72Hour;
	}

	public CellDataPoint getGreaterThan72Hour() {
		return greaterThan72Hour;
	}

	public void setGreaterThan72Hour(CellDataPoint greaterThan72Hour) {
		this.greaterThan72Hour = greaterThan72Hour;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getOrdFlowSumDsc() {
		return ordFlowSumDsc;
	}

	public void setOrdFlowSumDsc(String ordFlowSumDsc) {
		this.ordFlowSumDsc = ordFlowSumDsc;
	}

	public String getBusnActyTypDsc() {
		return busnActyTypDsc;
	}

	public void setBusnActyTypDsc(String busnActyTypDsc) {
		this.busnActyTypDsc = busnActyTypDsc;
	}

	public String getOrdFlowRsnDsc() {
		return ordFlowRsnDsc;
	}

	public void setOrdFlowRsnDsc(String ordFlowRsnDsc) {
		this.ordFlowRsnDsc = ordFlowRsnDsc;
	}

	public String getOrdFlowStatDsc() {
		return ordFlowStatDsc;
	}

	public void setOrdFlowStatDsc(String ordFlowStatDsc) {
		this.ordFlowStatDsc = ordFlowStatDsc;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	@Override
	public String toString() {
		return "\nPackageStatusModel [wareHouseName=" + wareHouseName + ", statusName=" + statusName + ", statusId="
				+ statusId + ", last1Hour=" + last1Hour + ", last1To3Hour=" + last1To3Hour + ", last3To6Hour="
				+ last3To6Hour + ", last6To24Hour=" + last6To24Hour + ", last24To48Hour=" + last24To48Hour
				+ ", last48To72Hour=" + last48To72Hour + ", greaterThan72Hour=" + greaterThan72Hour + ", totalOrders="
				+ totalOrders + ", service=" + service + ", ordFlowSumDsc=" + ordFlowSumDsc + ", busnActyTypDsc="
				+ busnActyTypDsc + ", ordFlowRsnDsc=" + ordFlowRsnDsc + ", ordFlowStatDsc=" + ordFlowStatDsc
				+ ", colorCode=" + colorCode + "]";
	}
	

}
