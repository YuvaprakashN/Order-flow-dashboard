package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;

public class OrderFlowStatVWModelRowMapper implements RowMapper<OrderFlowStatVWModel> {
	public OrderFlowStatVWModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderFlowStatVWModel flowStatVWModel = new OrderFlowStatVWModel();
		try {

			flowStatVWModel.setOrd_flow_stat_dsc(rs.getString("ord_flow_stat_dsc"));
			flowStatVWModel.setOrderFlowStatId(rs.getLong("ord_flow_stat_id"));
			flowStatVWModel.setBusn_proc_typ_dsc(rs.getString("busn_proc_typ_dsc"));
			flowStatVWModel.setBusn_acty_typ_dsc(rs.getString("busn_acty_typ_dsc"));

			flowStatVWModel.setOrd_flow_sum_dsc(rs.getString("ord_flow_sum_dsc"));
			flowStatVWModel.setOrd_flow_rsn_dsc(rs.getString("ord_flow_rsn_dsc"));

		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

		return flowStatVWModel;
	}

}
