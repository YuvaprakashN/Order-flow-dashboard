package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.OrderStatusCountModel;

public class OrderStatusRowMapper implements RowMapper<OrderStatusCountModel> {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(OrderStatusRowMapper.class);

	@Override
	public OrderStatusCountModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderStatusCountModel orderModel = new OrderStatusCountModel();
		try {
			orderModel.setOrderStatus(rs.getBigDecimal("ORD_FLOW_STAT_ID"));
			orderModel.setColorFlag(rs.getString("arrowColor").trim());
			orderModel.setBusnActyTypDsc(rs.getString("busn_acty_typ_dsc").trim());
			orderModel.setCount(rs.getBigDecimal("count"));
			orderModel.setOrdFlowRsnDsc(rs.getString("ord_flow_rsn_dsc").trim());
			orderModel.setOrdFlowStatDsc(rs.getString("ord_flow_stat_dsc").trim());
			orderModel.setOrdFlowSumDsc(rs.getString("ord_flow_sum_dsc").trim());
			orderModel.setService(rs.getString("busn_proc_typ_dsc").trim());

		} catch (Exception e) {
			log.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return orderModel;
	}

}
