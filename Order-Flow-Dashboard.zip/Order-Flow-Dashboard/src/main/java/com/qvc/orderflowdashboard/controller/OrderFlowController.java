package com.qvc.orderflowdashboard.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;
import com.qvc.orderflowdashboard.service.DFService;
import com.qvc.orderflowdashboard.service.DMService;
import com.qvc.orderflowdashboard.service.FinanceService;

@Controller
public class OrderFlowController {

	private static final String SUB_CATEGORY_COLOR_FLAG = "subCategoryColorFlag";

	private static final String SUB_CATEGORY_CNT = "subCategoryCnt";

	private static final String SUB_CATEGORY = "subCategory";

	private static final String RED_COLOR = "#EC7063";

	
	private final FinanceService orderFlowService;

	
	private final DFService dFOrderFlowService;
	
	
	
	
	public OrderFlowController(FinanceService orderFlowService, DMService dMOrderFlowService,
			DFService dFOrderFlowService) {
		super();
		this.orderFlowService = orderFlowService;
		this.dFOrderFlowService = dFOrderFlowService;
	}



	@Value("${demandManagement.orderdetails.page.name}")
	private String demandManagementOrderDetailsPage;

	@Value("${demandFulfillment.orderdetails.page.name}")
	private String demandFulfilmentOrderDetailsPage;
	
	@GetMapping("/fetchFinanceOrderSummary")
	@ResponseBody
	public List fetchRowExpandData() {
		List list1 = new ArrayList();
		List list2 = new ArrayList();
		Map dataMap = null;
		Map subDataMap = null;
		dataMap = new HashMap();
		subDataMap = new HashMap();
		dataMap.put("category", "Evaluate Risk");
		dataMap.put("categoryOrderCnt", 10);
		dataMap.put("categoryColorFlag", RED_COLOR);
		subDataMap.put(SUB_CATEGORY, "No Reason Code Specified");
		subDataMap.put(SUB_CATEGORY_CNT, 4);
		subDataMap.put(SUB_CATEGORY_COLOR_FLAG, RED_COLOR);
		list2.add(subDataMap);

		subDataMap = new HashMap();
		subDataMap.put(SUB_CATEGORY, "Special Review Requested");
		subDataMap.put(SUB_CATEGORY_CNT, 4);
		subDataMap.put(SUB_CATEGORY_COLOR_FLAG, RED_COLOR);
		list2.add(subDataMap);

		subDataMap = new HashMap();
		subDataMap.put(SUB_CATEGORY, "QVC Decision");
		subDataMap.put(SUB_CATEGORY_CNT, 2);
		subDataMap.put(SUB_CATEGORY_COLOR_FLAG, RED_COLOR);
		list2.add(subDataMap);
		dataMap.put("subCategoryList", list2);

		list1.add(dataMap);

		dataMap = new HashMap();
		list2 = new ArrayList();
		dataMap.put("category", "Manage Credit Card Orders");
		dataMap.put("categoryOrderCnt", 53);
		dataMap.put("categoryColorFlag", RED_COLOR);

		subDataMap = new HashMap();
		subDataMap.put(SUB_CATEGORY, "Authorization Declined");
		subDataMap.put(SUB_CATEGORY_CNT, 12);
		subDataMap.put(SUB_CATEGORY_COLOR_FLAG, "#F4d03F");
		list2.add(subDataMap);

		subDataMap = new HashMap();
		subDataMap.put(SUB_CATEGORY, "Authorization Expired");
		subDataMap.put(SUB_CATEGORY_CNT, 35);
		subDataMap.put(SUB_CATEGORY_COLOR_FLAG, "#58D68D");
		list2.add(subDataMap);

		subDataMap = new HashMap();
		subDataMap.put(SUB_CATEGORY, "Advance Ordered");
		subDataMap.put(SUB_CATEGORY_CNT, 6);
		subDataMap.put(SUB_CATEGORY_COLOR_FLAG, RED_COLOR);
		list2.add(subDataMap);

		dataMap.put("subCategoryList", list2);

		list1.add(dataMap);

		return list1;

	}

	
	@GetMapping("/ordersDetailsJSON/{status}")
	@ResponseBody
	public List<OrderDetailsModel> getorderDetailsJSON(@PathVariable int status,@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		System.out.println("-----------------Order Details JSOn for Status: "+status+" | Start Date: "+startDate+" | End Date: "+endDate);
		Date start = orderFlowService.convertJSDateToDate(startDate);
		Date end = orderFlowService.convertJSDateToDate(endDate);
		List<OrderDetailsModel> orderDetails = orderFlowService.getorderDetailsJSON(status, start,end);
		System.out.println(orderDetails);
		return orderDetails;
		
	}
	
	
	@GetMapping("/orderDetails/{status}")
	public String getorderDetails(@PathVariable String status,@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate, Model model)  {
		System.out.println("Order Detail Status: "+status+" Start Date: "+startDate+" End Date: "+endDate);
		OrderFlowStatVWModel orderFlowStatusVW = orderFlowService.getOrderFlowStatusVW(status);
		System.out.println("orderFlowStatusVW: "+ orderFlowStatusVW);
		model.addAttribute("page", demandManagementOrderDetailsPage);
		model.addAttribute("statusId", status);
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("orderFlowStatusVW", orderFlowStatusVW);
		
		return "shared/Masterpage";

	}
	
	
	@GetMapping("/packagesDetailsJSON/{status}")
	@ResponseBody
	public List<PackageDetailsModel> getPackagesDetailsJSON(@PathVariable String status,@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		System.out.println("-----------------Packages Details JSOn for Status: "+status+" | Start Date: "+startDate+" | End Date: "+endDate);
		Date start = orderFlowService.convertJSDateToDate(startDate);
		Date end = orderFlowService.convertJSDateToDate(endDate);
		List<PackageDetailsModel> orderDetails = dFOrderFlowService.getPackageDetails(status, start,end);
		System.out.println(orderDetails);
		return orderDetails;
		
	}
	
	
	@GetMapping("/packageDFDetails/{status}")
	public String getPackageDetails(@PathVariable String status,@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate, Model model)  {
		System.out.println("Package Detail Status: "+status+" Start Date: "+startDate+" End Date: "+endDate);
		OrderFlowStatVWModel orderFlowStatusVW = orderFlowService.getOrderFlowStatusVW(status);
		System.out.println("orderFlowStatusVW: "+ orderFlowStatusVW);
		model.addAttribute("page", demandFulfilmentOrderDetailsPage);
		model.addAttribute("statusId", status);
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("orderFlowStatusVW", orderFlowStatusVW);
		
		return "shared/Masterpage";

	}

}
