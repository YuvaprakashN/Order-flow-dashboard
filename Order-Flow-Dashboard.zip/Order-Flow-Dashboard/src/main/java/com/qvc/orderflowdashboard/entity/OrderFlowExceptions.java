package com.qvc.orderflowdashboard.entity;

public class OrderFlowExceptions {
	
	private long orderFlowStatId;
	private String dcId;
	private String exceptionInd;
	private long totOrderLineCnt;
	private long totUnitCnt;
	private long totMerchPriceAmt;
	private long totPkgCnt;
	private String ageBucket;
	
	private String ord_flow_stat_dsc;
	
	private String busn_proc_typ_dsc;
	private String busn_acty_typ_dsc;
	private String ord_flow_sum_dsc;
	private String ord_flow_rsn_dsc;
	private String ord_flow_lvl_dsc;
	private String is_oscrol_ind;
	private String is_oscrpkd_ind;
	private String is_oscrpkq_ind;
	
	public String getOrd_flow_stat_dsc() {
		return ord_flow_stat_dsc;
	}
	public void setOrd_flow_stat_dsc(String ord_flow_stat_dsc) {
		this.ord_flow_stat_dsc = ord_flow_stat_dsc;
	}
	public long getOrderFlowStatId() {
		return orderFlowStatId;
	}
	public void setOrderFlowStatId(long orderFlowStatId) {
		this.orderFlowStatId = orderFlowStatId;
	}
	public String getDcId() {
		return dcId;
	}
	public void setDcId(String dcId) {
		this.dcId = dcId;
	}
	public String getExceptionInd() {
		return exceptionInd;
	}
	public void setExceptionInd(String exceptionInd) {
		this.exceptionInd = exceptionInd;
	}
	public long getTotOrderLineCnt() {
		return totOrderLineCnt;
	}
	public void setTotOrderLineCnt(long totOrderLineCnt) {
		this.totOrderLineCnt = totOrderLineCnt;
	}
	public long getTotUnitCnt() {
		return totUnitCnt;
	}
	public void setTotUnitCnt(long totUnitCnt) {
		this.totUnitCnt = totUnitCnt;
	}
	public long getTotMerchPriceAmt() {
		return totMerchPriceAmt;
	}
	public void setTotMerchPriceAmt(long totMerchPriceAmt) {
		this.totMerchPriceAmt = totMerchPriceAmt;
	}
	public long getTotPkgCnt() {
		return totPkgCnt;
	}
	public void setTotPkgCnt(long totPkgCnt) {
		this.totPkgCnt = totPkgCnt;
	}
	public String getAgeBucket() {
		return ageBucket;
	}
	public void setAgeBucket(String ageBucket) {
		this.ageBucket = ageBucket;
	}
	public String getBusn_proc_typ_dsc() {
		return busn_proc_typ_dsc;
	}
	public void setBusn_proc_typ_dsc(String busn_proc_typ_dsc) {
		this.busn_proc_typ_dsc = busn_proc_typ_dsc;
	}
	public String getBusn_acty_typ_dsc() {
		return busn_acty_typ_dsc;
	}
	public void setBusn_acty_typ_dsc(String busn_acty_typ_dsc) {
		this.busn_acty_typ_dsc = busn_acty_typ_dsc;
	}
	public String getOrd_flow_sum_dsc() {
		return ord_flow_sum_dsc;
	}
	public void setOrd_flow_sum_dsc(String ord_flow_sum_dsc) {
		this.ord_flow_sum_dsc = ord_flow_sum_dsc;
	}
	public String getOrd_flow_rsn_dsc() {
		return ord_flow_rsn_dsc;
	}
	public void setOrd_flow_rsn_dsc(String ord_flow_rsn_dsc) {
		this.ord_flow_rsn_dsc = ord_flow_rsn_dsc;
	}
	public String getOrd_flow_lvl_dsc() {
		return ord_flow_lvl_dsc;
	}
	public void setOrd_flow_lvl_dsc(String ord_flow_lvl_dsc) {
		this.ord_flow_lvl_dsc = ord_flow_lvl_dsc;
	}
	public String getIs_oscrol_ind() {
		return is_oscrol_ind;
	}
	public void setIs_oscrol_ind(String is_oscrol_ind) {
		this.is_oscrol_ind = is_oscrol_ind;
	}
	public String getIs_oscrpkd_ind() {
		return is_oscrpkd_ind;
	}
	public void setIs_oscrpkd_ind(String is_oscrpkd_ind) {
		this.is_oscrpkd_ind = is_oscrpkd_ind;
	}
	public String getIs_oscrpkq_ind() {
		return is_oscrpkq_ind;
	}
	public void setIs_oscrpkq_ind(String is_oscrpkq_ind) {
		this.is_oscrpkq_ind = is_oscrpkq_ind;
	}
	@Override
	public String toString() {
		return "OrderFlowExceptions [totPkgCnt=" + totPkgCnt + " orderFlowStatId=" + orderFlowStatId + ", dcId=" + dcId + ", exceptionInd="
				+ exceptionInd + ", totOrderLineCnt=" + totOrderLineCnt + ", totUnitCnt=" + totUnitCnt
				+ ", totMerchPriceAmt=" + totMerchPriceAmt + ", totPkgCnt=" + totPkgCnt + ", ageBucket=" + ageBucket
				+ ", ord_flow_stat_dsc=" + ord_flow_stat_dsc + ", busn_proc_typ_dsc=" + busn_proc_typ_dsc
				+ ", busn_acty_typ_dsc=" + busn_acty_typ_dsc + ", ord_flow_sum_dsc=" + ord_flow_sum_dsc
				+ ", ord_flow_rsn_dsc=" + ord_flow_rsn_dsc + ", ord_flow_lvl_dsc=" + ord_flow_lvl_dsc
				+ ", is_oscrol_ind=" + is_oscrol_ind + ", is_oscrpkd_ind=" + is_oscrpkd_ind + ", is_oscrpkq_ind="
				+ is_oscrpkq_ind + "]";
	}

	
	
	
	
}
