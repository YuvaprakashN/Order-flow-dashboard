package com.qvc.orderflowdashboard.vo;

import java.util.ArrayList;
import java.util.List;

public class BarChart
    {
        private List<String> labels;
        private List<BarChartDatasets> datasets;
        
        
        
		public BarChart(List<String> labels, List<BarChartDatasets> datasets) {
			super();
			this.labels = labels;
			this.datasets = datasets;
		}
		public BarChart() {
			super();
			this.datasets=new ArrayList<BarChartDatasets>();
		}
		public List<String> getLabels() {
			return labels;
		}
		public void setLabels(List<String> labels) {
			this.labels = labels;
		}
		public List<BarChartDatasets> getDatasets() {
			return datasets;
		}
		public void setDatasets(List<BarChartDatasets> datasets) {
			this.datasets = datasets;
		}
		@Override
		public String toString() {
			return "\nBarChart [labels=" + labels + ", datasets=" + datasets + "]";
		}
		
		
        
    }