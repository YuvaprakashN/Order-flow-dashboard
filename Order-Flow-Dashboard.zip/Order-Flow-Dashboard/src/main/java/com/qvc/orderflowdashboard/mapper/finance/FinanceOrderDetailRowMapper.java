package com.qvc.orderflowdashboard.mapper.finance;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.model.FinanceOrderDetail;

public class FinanceOrderDetailRowMapper implements RowMapper<FinanceOrderDetail> {
	FinanceOrderDetail orderDetailsModel =null;
	@Override
	public FinanceOrderDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
		orderDetailsModel = new FinanceOrderDetail();
		try
		{
			orderDetailsModel.setOrderNumber(rs.getString("ORD_NBR"));
			orderDetailsModel.setOrderLineNumber(rs.getInt("ORD_LN_NBR"));
			orderDetailsModel.setAccountNumber(rs.getString("MBR_NBR"));
			orderDetailsModel.setItemNumber(rs.getString("SKN_ID"));
			orderDetailsModel.setOrderDate(rs.getDate("ORDER_DATE"));


			orderDetailsModel.setLastUpdatedDate(rs.getTimestamp("LAST_UPD_TMS"));
			orderDetailsModel.setEstimatedDeliveryDate(rs.getTimestamp("CURR_EST_DELVRY_DT"));
			orderDetailsModel.setShipByDate(rs.getTimestamp("SHP_BY_DT"));
			orderDetailsModel.setInsertedTimestamp(rs.getTimestamp("INSRT_TMS"));
			orderDetailsModel.setOrdmlineStatus(rs.getString("ord_flow_sum_dsc"));
		
		}catch(
		Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e);
		}
		return orderDetailsModel;


}}
