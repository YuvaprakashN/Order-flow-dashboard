package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;

public class OrderStatusModel {
	private String statusName;
	private BigDecimal statusId;
	private BigDecimal totalOrders;
	
	private String service;
	private String ordFlowSumDsc;
	private String busnActyTypDsc;
	private String ordFlowRsnDsc;
	private String ordFlowStatDsc;
	
	
	
	
	private String colorCode;

	private CellDataPoint lst24Hour;
	private CellDataPoint lst24To48Hour;
	private CellDataPoint lst48To72Hour;
	private CellDataPoint abv72Hour;
	
	
	
	
	public CellDataPoint getLst48To72Hour() {
		return lst48To72Hour;
	}

	public void setLst48To72Hour(CellDataPoint lst48To72Hour) {
		this.lst48To72Hour = lst48To72Hour;
	}

	public CellDataPoint getLst24Hour() {
		return lst24Hour;
	}

	public void setLst24Hour(CellDataPoint lst24Hour) {
		this.lst24Hour = lst24Hour;
	}

	public CellDataPoint getLst24To48Hour() {
		return lst24To48Hour;
	}

	public void setLst24To48Hour(CellDataPoint lst24To48Hour) {
		this.lst24To48Hour = lst24To48Hour;
	}

	public CellDataPoint getAbv72Hour() {
		return abv72Hour;
	}

	public void setAbv72Hour(CellDataPoint abv72Hour) {
		this.abv72Hour = abv72Hour;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public BigDecimal getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(BigDecimal totalOrders) {
		this.totalOrders = totalOrders;
	}

	public BigDecimal getStatusId() {
		return statusId;
	}

	public void setStatusId(BigDecimal statusId) {
		this.statusId = statusId;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getOrdFlowSumDsc() {
		return ordFlowSumDsc;
	}

	public void setOrdFlowSumDsc(String ordFlowSumDsc) {
		this.ordFlowSumDsc = ordFlowSumDsc;
	}

	public String getBusnActyTypDsc() {
		return busnActyTypDsc;
	}

	public void setBusnActyTypDsc(String busnActyTypDsc) {
		this.busnActyTypDsc = busnActyTypDsc;
	}

	public String getOrdFlowRsnDsc() {
		return ordFlowRsnDsc;
	}

	public void setOrdFlowRsnDsc(String ordFlowRsnDsc) {
		this.ordFlowRsnDsc = ordFlowRsnDsc;
	}

	public String getOrdFlowStatDsc() {
		return ordFlowStatDsc;
	}

	public void setOrdFlowStatDsc(String ordFlowStatDsc) {
		this.ordFlowStatDsc = ordFlowStatDsc;
	}

	@Override
	public String toString() {
		return "\nOrderStatusModel [statusName=" + statusName + ", statusId=" + statusId + ", totalOrders=" + totalOrders
				+ ", service=" + service + ", ordFlowSumDsc=" + ordFlowSumDsc + ", busnActyTypDsc=" + busnActyTypDsc
				+ ", ordFlowRsnDsc=" + ordFlowRsnDsc + ", ordFlowStatDsc=" + ordFlowStatDsc + ", colorCode=" + colorCode
				+ ", lst24Hour=" + lst24Hour + ", lst24To48Hour=" + lst24To48Hour + ", abv72Hour=" + abv72Hour + "]";
	}

	

	





	
	
	

}
