package com.qvc.orderflowdashboard.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qvc.orderflowdashboard.dao.DashboardDAO;
import com.qvc.orderflowdashboard.model.OrderFlowModel;
import com.qvc.orderflowdashboard.service.DashboardService;
import com.qvc.orderflowdashboard.service.FinanceService;

//@RestController
@Controller
public class FinanceController {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(FinanceController.class);
	

	@Value("${finance.page.name}")
	private String financePage;
 
	private final FinanceService financeService;

	
	
	public FinanceController(FinanceService financeService) {
		super();
		this.financeService = financeService;
	}

	@GetMapping("/loadFinanceBusinessExceptionsTable")
	@ResponseBody
	public List<OrderFlowModel> loadFinanceBusinessExceptionsTable(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		log.info("START DATE: " + startDate);
		log.info("END DATE: " + endDate);
		Date stsEffTm = financeService.convertJSDateToDate(startDate);
		Date updTimeStamp = financeService.convertJSDateToDate(endDate);
		return financeService.getFinanceBusinessExceptions(stsEffTm, updTimeStamp);
	}

	@GetMapping("/loadFinanceITExceptionsTable")
	@ResponseBody
	public List<OrderFlowModel> loadFinanceITExceptionsTable(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws ParseException {
		log.info("START DATE: " + startDate);
		log.info("END DATE: " + endDate);
		Date stsEffTm = financeService.convertJSDateToDate(startDate);
		Date updTimeStamp = financeService.convertJSDateToDate(endDate);
		return financeService.getFinanceITExceptions(stsEffTm, updTimeStamp);
	}

}
