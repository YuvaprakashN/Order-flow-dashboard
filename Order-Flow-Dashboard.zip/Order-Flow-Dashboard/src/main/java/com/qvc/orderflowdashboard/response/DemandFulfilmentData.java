package com.qvc.orderflowdashboard.response;

import java.util.List;

import com.qvc.orderflowdashboard.entity.WarehousePackageCountModel;

public class DemandFulfilmentData{
	private List<WarehousePackageCountModel> demandFulfilment;
	private String colorFlag;
	public List<WarehousePackageCountModel> getDemandFulfilment() {
		return demandFulfilment;
	}
	public void setDemandFulfilment(List<WarehousePackageCountModel> demandFulfilment) {
		this.demandFulfilment = demandFulfilment;
	}
	public String getColorFlag() {
		return colorFlag;
	}
	public void setColorFlag(String colorFlag) {
		this.colorFlag = colorFlag;
	}
	@Override
	public String toString() {
		return "demandFulfilmentData [demandFulfilment=" + demandFulfilment + ", colorFlag=" + colorFlag + "]";
	}
	
}

