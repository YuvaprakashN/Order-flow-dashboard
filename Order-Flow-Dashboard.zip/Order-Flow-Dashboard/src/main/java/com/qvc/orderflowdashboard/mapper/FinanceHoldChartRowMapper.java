package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.vo.FinanceHoldChartData;

public class FinanceHoldChartRowMapper implements RowMapper<FinanceHoldChartData> {

	public FinanceHoldChartData mapRow(ResultSet rs, int rowNum) throws SQLException {
		FinanceHoldChartData orderStatusModel = new FinanceHoldChartData();
		try {

			orderStatusModel.setStatusId(rs.getBigDecimal("ord_flow_stat_id"));

			orderStatusModel.setTotalOrders(rs.getBigDecimal("NO_OF_ORDERS"));

			orderStatusModel.setTotalOrders(rs.getBigDecimal("TOTAL_Orders"));

		} catch (Exception e) {
			System.out.println("Fnance Order Status model row mapper error" + e.getMessage());
			System.out.println(e);
		}
		System.out.println(orderStatusModel);
		return orderStatusModel;
	}

}
