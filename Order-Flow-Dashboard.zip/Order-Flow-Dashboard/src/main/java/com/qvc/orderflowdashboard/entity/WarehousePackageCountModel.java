package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;

public class WarehousePackageCountModel {

	private String warehouseName;
	private BigDecimal count;
	private String colorFlag;
	public WarehousePackageCountModel() {
		super();
	}
	
	public String getColorFlag() {
		return colorFlag;
	}

	public void setColorFlag(String colorFlag) {
		this.colorFlag = colorFlag;
	}

	public String getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}
	public BigDecimal getCount() {
		return count;
	}
	public void setCount(BigDecimal count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "\nWarehousePackageCountModel [warehouseName=" + warehouseName + ", count=" + count + ", colorFlag="
				+ colorFlag + "]";
	}
	
	
	
	
}
