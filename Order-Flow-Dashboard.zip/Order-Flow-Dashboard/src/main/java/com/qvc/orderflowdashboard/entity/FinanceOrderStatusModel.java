package com.qvc.orderflowdashboard.entity;

import java.math.BigDecimal;

public class FinanceOrderStatusModel {
	private BigDecimal statusId;

	private BigDecimal totalOrders;
	
	private String service;
	private String ordFlowSumDsc;
	private String busnActyTypDsc;
	private String ordFlowRsnDsc;
	private String ordFlowStatDsc;
	
	
	
	
	private String colorCode;

	private CellDataPoint lst1Hour;
	private CellDataPoint lst1To24Hour;
	private CellDataPoint lst24To48Hour;
	private CellDataPoint lst48To72Hour;
	private CellDataPoint abv72Hour;
	
	
	
	public CellDataPoint getLst24To48Hour() {
		return lst24To48Hour;
	}

	public void setLst24To48Hour(CellDataPoint lst24To48Hour) {
		this.lst24To48Hour = lst24To48Hour;
	}

	public CellDataPoint getAbv72Hour() {
		return abv72Hour;
	}

	public void setAbv72Hour(CellDataPoint abv72Hour) {
		this.abv72Hour = abv72Hour;
	}


	public BigDecimal getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(BigDecimal totalOrders) {
		this.totalOrders = totalOrders;
	}

	public BigDecimal getStatusId() {
		return statusId;
	}

	public void setStatusId(BigDecimal statusId) {
		this.statusId = statusId;
	}

	
	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getOrdFlowSumDsc() {
		return ordFlowSumDsc;
	}

	public void setOrdFlowSumDsc(String ordFlowSumDsc) {
		this.ordFlowSumDsc = ordFlowSumDsc;
	}

	public String getBusnActyTypDsc() {
		return busnActyTypDsc;
	}

	public void setBusnActyTypDsc(String busnActyTypDsc) {
		this.busnActyTypDsc = busnActyTypDsc;
	}

	public String getOrdFlowRsnDsc() {
		return ordFlowRsnDsc;
	}

	public void setOrdFlowRsnDsc(String ordFlowRsnDsc) {
		this.ordFlowRsnDsc = ordFlowRsnDsc;
	}

	public String getOrdFlowStatDsc() {
		return ordFlowStatDsc;
	}

	public void setOrdFlowStatDsc(String ordFlowStatDsc) {
		this.ordFlowStatDsc = ordFlowStatDsc;
	}

	public CellDataPoint getLst1Hour() {
		return lst1Hour;
	}

	public void setLst1Hour(CellDataPoint lst1Hour) {
		this.lst1Hour = lst1Hour;
	}

	public CellDataPoint getLst1To24Hour() {
		return lst1To24Hour;
	}

	public void setLst1To24Hour(CellDataPoint lst1To24Hour) {
		this.lst1To24Hour = lst1To24Hour;
	}

	public CellDataPoint getLst48To72Hour() {
		return lst48To72Hour;
	}

	public void setLst48To72Hour(CellDataPoint lst48To72Hour) {
		this.lst48To72Hour = lst48To72Hour;
	}

	@Override
	public String toString() {
		return "\nFinanceOrderStatusModel [statusId=" + statusId + ", totalOrders=" + totalOrders + ", service=" + service
				+ ", ordFlowSumDsc=" + ordFlowSumDsc + ", busnActyTypDsc=" + busnActyTypDsc + ", ordFlowRsnDsc="
				+ ordFlowRsnDsc + ", ordFlowStatDsc=" + ordFlowStatDsc + ", colorCode=" + colorCode + ", lst1Hour="
				+ lst1Hour + ", lst1To24Hour=" + lst1To24Hour + ", lst24To48Hour=" + lst24To48Hour + ", lst48To72Hour="
				+ lst48To72Hour + ", abv72Hour=" + abv72Hour + "]";
	}

	

	

	





	
	
	

}
