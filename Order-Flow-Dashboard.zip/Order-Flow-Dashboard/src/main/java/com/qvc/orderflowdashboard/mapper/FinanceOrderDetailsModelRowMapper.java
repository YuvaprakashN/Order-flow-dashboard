package com.qvc.orderflowdashboard.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.qvc.orderflowdashboard.entity.FinanceOrderDetailsModel;

public class FinanceOrderDetailsModelRowMapper implements RowMapper<FinanceOrderDetailsModel> {
	public FinanceOrderDetailsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		FinanceOrderDetailsModel orderDetailsModel = new FinanceOrderDetailsModel();
		try {

			orderDetailsModel.setOrderLineNumber(rs.getInt("ORD_LN_NBR"));
			orderDetailsModel.setOrderNumber(rs.getString("ORD_NBR"));
			orderDetailsModel.setStatusEffTimestamp(rs.getTimestamp("STAT_EFF_TMS"));

			orderDetailsModel.setAolLastUpdatedDate(rs.getTimestamp("aol_LAST_UPD_TMS"));
			orderDetailsModel.setOlLastUpdatedDate(rs.getTimestamp("aol_LAST_UPD_TMS"));

			orderDetailsModel.setActiveOrdLnStatus(rs.getString("aol_ORD_FLOW_STAT_ID"));
			orderDetailsModel.setOrdmlineStatus(rs.getString("ol_ORD_FLOW_STAT_ID"));

		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e);
		}

		return orderDetailsModel;
	}

}
