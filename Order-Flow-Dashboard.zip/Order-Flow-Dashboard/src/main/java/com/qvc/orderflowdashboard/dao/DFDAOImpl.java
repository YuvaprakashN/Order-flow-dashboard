package com.qvc.orderflowdashboard.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.qvc.orderflowdashboard.mapper.OrderFlowRowMapper;
import com.qvc.orderflowdashboard.mapper.PackageDetailsRowMapper;
import com.qvc.orderflowdashboard.entity.OrderDetailsModel;
import com.qvc.orderflowdashboard.entity.OrderFlowExceptions;
import com.qvc.orderflowdashboard.entity.OrderFlowStatVWModel;
import com.qvc.orderflowdashboard.entity.PackageDetailsModel;


@Repository
@Qualifier("DFDAO")
public class DFDAOImpl implements OrderFlowDAO{
	
	 @Autowired
	 @Qualifier("jdbcTemplate1")
	 private JdbcTemplate jdbcTemplate;
	 
	/* @Autowired
	 @Qualifier("jdbcTemplate2")
	 private JdbcTemplate jdbcTemplate2;*/
	 
	 String orderSummaryQuery ="SELECT   C.ord_flow_stat_id,\r\n" + 
	 		"         C.tot_ord_ln_cnt,\r\n" + 
	 		"         C.tot_pkg_cnt,\r\n" + 
	 		"\r\n" + 
	 		"         vw1.busn_proc_typ_dsc,\r\n" + 
	 		"         vw1.busn_acty_typ_dsc,\r\n" + 
	 		"         vw1.ord_flow_sum_dsc,\r\n" + 
	 		"         vw1.ord_flow_rsn_dsc,\r\n" + 
	 		"         vw1.busn_proc_typ_cd,\r\n" + 
	 		"         vw1.busn_acty_typ_cd,\r\n" + 
	 		"         vw1.ord_flow_sum_cd,\r\n" + 
	 		"         vw1.ord_flow_rsn_cd,\r\n" + 
	 		"         vw1.is_excptn_ind,\r\n" + 
	 		"         vw1.ord_flow_lvl_dsc,\r\n" + 
	 		"         vw1.is_oscrol_ind,\r\n" + 
	 		"         vw1.is_oscrpkd_ind,\r\n" + 
	 		"         vw1.ord_flow_stat_dsc,\r\n" + 
	 		"         vw1.is_oscrpkq_ind\r\n" + 
	 		"FROM     q.ord_flow_stat_vw VW1 with(nolock) \r\n" + 
	 		"         JOIN ( \r\n" + 
	 		"SELECT   VW.ord_flow_stat_id,\r\n" + 
	 		"         VW.busn_proc_typ_dsc,\r\n" + 
	 		"\r\n" + 
	 		"         SUM(CASE WHEN aol.ord_ln_nbr is not null THEN 1 ELSE 0 END) as tot_ord_ln_cnt,\r\n" + 
	 		"         SUM(CASE WHEN ap.pkg_id is not null THEN 1 ELSE 0 END) as tot_pkg_cnt\r\n" + 
	 		"FROM     q.active_ord_ln aol with(nolock)\r\n" + 
	 		"         left join q.package_ol_rel por with(nolock) on por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR \r\n" + 
	 		"         left join Q.ACTV_PKG ap with(nolock) on ap.PKG_ID =por.PKG_ID \r\n" + 
	 		"         inner join q.ord_flow_stat_vw VW with(nolock) on (VW.ord_flow_stat_id = aol.ord_flow_stat_id or VW.ord_flow_stat_id = ap.ord_flow_stat_id) and VW.busn_proc_typ_dsc = 'Demand Fulfillment' and ( VW.is_oscrol_ind = 'Yes' OR VW.is_oscrpkd_ind = 'Yes' OR VW.is_oscrpkq_ind = 'Yes' ) \r\n" + 
	 		"         LEFT join Q.ORD_FLOW_STAT_ATTR ofsa with (nolock) on VW.ord_flow_stat_id = ofsa.ord_flow_stat_id and ofsa.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n" + 
	 		"\r\n" + 
	 		"where ((ap.last_upd_tms>=? and ap.last_upd_tms <=?) or (aol.last_upd_tms>=? and aol.last_upd_tms<=? ))\r\n" + 
	 		"GROUP BY vw.ord_flow_stat_id, VW.busn_proc_typ_dsc\r\n" + 
	 		"\r\n" + 
	 		" ) C on C.ord_flow_stat_id = VW1.ord_flow_stat_id and VW1.busn_proc_typ_dsc = 'Demand Fulfillment' AND VW1.is_excptn_ind = ?;\r\n" + 
	 		"";

	/* String orderSummaryQuery = "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED\r\n"
				+ "			SELECT T.ORD_FLOW_STAT_ID,\r\n"
				+ "						         T.DC_ID AS DC_ID,\r\n"
				+ "						         NUll AS AGE_BUCKET_CD,\r\n"
				+ "						         T.IS_EXCPTN_IND,\r\n"
				+ "						         T.TOT_ORD_LN_CNT,\r\n"
				+ "						         T.TOT_UNIT_CNT,\r\n"
				+ "						         T.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         T.TOT_PKG_CNT,\r\n"
				+ "						         VW.*\r\n"
				+ "\r\n"
				+ "FROM\r\n"
				+ "(\r\n"
				+ "SELECT 	D.ORD_FLOW_STAT_ID,\r\n"
				+ "						         D.DC_ID AS DC_ID,\r\n"
				+ "						         NUll AS AGE_BUCKET_CD,\r\n"
				+ "						         D.IS_EXCPTN_IND,\r\n"
				+ "						         D.TOT_ORD_LN_CNT,\r\n"
				+ "						         D.TOT_UNIT_CNT,\r\n"
				+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         D.TOT_PKG_CNT	\r\n"
				+ "						FROM\r\n"
				+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
				+ "							(\r\n"
				+ "								SELECT   \r\n"
				+ "									 C.ORD_FLOW_STAT_ID,\r\n"
				+ "									 C.DC_ID AS DC_ID,\r\n"
				+ "									 C.IS_EXCPTN_IND,\r\n"
				+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
				+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
				+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
				+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
				+ "								FROM     (\r\n"
				+ "										SELECT   \r\n"
				+ "											 O.ORD_FLOW_STAT_ID,\r\n"
				+ "											 NULL AS DC_ID,\r\n"
				+ "											 0 AS TOT_PKG_CNT,\r\n"
				+ "											 TOT_ORD_LN_CNT,\r\n"
				+ "											 TOT_UNIT_CNT,\r\n"
				+ "											 TOT_MRCH_PRICE_AMT,\r\n"
				+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "										FROM     Q.ORD_STAT_SUM_A O \r\n"
				+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "									UNION ALL\r\n"
				+ "										SELECT   O.ORD_FLOW_STAT_ID,\r\n"
				+ "											 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
				+ "											 O.PKG_CNT TOT_PKG_CNT,\r\n"
				+ "											 O.TOT_ORD_LN_CNT,\r\n"
				+ "											 O.TOT_UNIT_CNT,\r\n"
				+ "											 O.TOT_MRCH_PRICE_AMT,\r\n"
				+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "										FROM     Q.PKG_STAT_SUM_A O \r\n"
				+ "											 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
				+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "					WHERE O.LAST_UPD_TMS >= ? and O.LAST_UPD_TMS <=?	\r\n"
				+ "								) C\r\n"
				+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
				+ "							) D\r\n"
				+ "						WHERE\r\n"
				+ "							OAT.OSCR_ACTV_TBL_CD = 'A' \r\n"
				+ "							\r\n"
				+ "						UNION ALL\r\n"
				+ "						\r\n"
				+ "						\r\n"
				+ "						SELECT\r\n"
				+ "							 D.ORD_FLOW_STAT_ID,\r\n"
				+ "						         D.DC_ID AS DC_ID,\r\n"
				+ "						         NULL AS AGE_BUCKET_CD,\r\n"
				+ "						         D.IS_EXCPTN_IND,\r\n"
				+ "						         D.TOT_ORD_LN_CNT,\r\n"
				+ "						         D.TOT_UNIT_CNT,\r\n"
				+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         D.TOT_PKG_CNT	\r\n"
				+ "						FROM\r\n"
				+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
				+ "							(\r\n"
				+ "								SELECT   \r\n"
				+ "									 C.ORD_FLOW_STAT_ID,\r\n"
				+ "									 C.DC_ID AS DC_ID,\r\n"
				+ "									 C.IS_EXCPTN_IND,\r\n"
				+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
				+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
				+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
				+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
				+ "								FROM     \r\n"
				+ "								(\r\n"
				+ "									SELECT   \r\n"
				+ "										 O.ORD_FLOW_STAT_ID,\r\n"
				+ "										 NULL AS DC_ID,\r\n"
				+ "										 0 AS TOT_PKG_CNT,\r\n"
				+ "										 TOT_ORD_LN_CNT,\r\n"
				+ "										 TOT_UNIT_CNT,\r\n"
				+ "										 TOT_MRCH_PRICE_AMT,\r\n"
				+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "									FROM     Q.ORD_STAT_SUM_B O \r\n"
				+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1' WHERE O.LAST_UPD_TMS >= ? and O.LAST_UPD_TMS <=?\r\n"
				+ "\r\n"
				+ "									UNION ALL\r\n"
				+ "									SELECT   O.ORD_FLOW_STAT_ID,\r\n"
				+ "										 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
				+ "										 O.PKG_CNT TOT_PKG_CNT,\r\n"
				+ "										 O.TOT_ORD_LN_CNT,\r\n"
				+ "										 O.TOT_UNIT_CNT,\r\n"
				+ "										 O.TOT_MRCH_PRICE_AMT,\r\n"
				+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "									FROM     Q.PKG_STAT_SUM_B O \r\n"
				+ "										 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
				+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "						WHERE  O.LAST_UPD_TMS >= ? and O.LAST_UPD_TMS <=?\r\n"
				+ "								) C\r\n"
				+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
				+ "							) D\r\n"
				+ "						WHERE\r\n"
				+ "							OAT.OSCR_ACTV_TBL_CD = 'B'\r\n"
				+ ")T\r\n"
				+ "\r\n"
				+ "JOIN \r\n"
				+ "(SELECT\r\n"
				+ "					ord_flow_stat_id,\r\n"
				+ "					busn_proc_typ_dsc,\r\n"
				+ "					busn_acty_typ_dsc,\r\n"
				+ "					ord_flow_sum_dsc,\r\n"
				+ "					ord_flow_rsn_dsc,\r\n"
				+ "					busn_proc_typ_cd,\r\n"
				+ "					busn_acty_typ_cd,\r\n"
				+ "					ord_flow_sum_cd,\r\n"
				+ "					ord_flow_rsn_cd,\r\n"
				+ "					is_excptn_ind,\r\n"
				+ "					ord_flow_lvl_dsc,\r\n"
				+ "					ord_flow_stat_dsc,\r\n"

				+ "					is_oscrol_ind,\r\n"
				+ "					is_oscrpkd_ind,\r\n"
				+ "					is_oscrpkq_ind\r\n"
				+ "				FROM\r\n"
				+ "					q.ord_flow_stat_vw with(nolock)		\r\n"
				+ "WHERE is_oscrol_ind = 'Yes' OR is_oscrpkd_ind = 'Yes' OR is_oscrpkq_ind = 'Yes') VW on VW.ord_flow_stat_id = T.ord_flow_stat_id";
	
	 */
	 /*String orderSummaryQuery = "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED\r\n"
				+ "			SELECT T.ORD_FLOW_STAT_ID,\r\n"
				+ "						         T.DC_ID AS DC_ID,\r\n"
				+ "						         NUll AS AGE_BUCKET_CD,\r\n"
				+ "						         T.IS_EXCPTN_IND,\r\n"
				+ "						         T.TOT_ORD_LN_CNT,\r\n"
				+ "						         T.TOT_UNIT_CNT,\r\n"
				+ "						         T.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         T.TOT_PKG_CNT,\r\n"
				+ "						         VW.*\r\n"
				+ "\r\n"
				+ "FROM\r\n"
				+ "(\r\n"
				+ "SELECT 	D.ORD_FLOW_STAT_ID,\r\n"
				+ "						         D.DC_ID AS DC_ID,\r\n"
				+ "						         NUll AS AGE_BUCKET_CD,\r\n"
				+ "						         D.IS_EXCPTN_IND,\r\n"
				+ "						         D.TOT_ORD_LN_CNT,\r\n"
				+ "						         D.TOT_UNIT_CNT,\r\n"
				+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         D.TOT_PKG_CNT	\r\n"
				+ "						FROM\r\n"
				+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
				+ "							(\r\n"
				+ "								SELECT   \r\n"
				+ "									 C.ORD_FLOW_STAT_ID,\r\n"
				+ "									 C.DC_ID AS DC_ID,\r\n"
				+ "									 C.IS_EXCPTN_IND,\r\n"
				+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
				+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
				+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
				+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
				+ "								FROM     (\r\n"
				+ "										SELECT   \r\n"
				+ "											 O.ORD_FLOW_STAT_ID,\r\n"
				+ "											 NULL AS DC_ID,\r\n"
				+ "											 0 AS TOT_PKG_CNT,\r\n"
				+ "											 TOT_ORD_LN_CNT,\r\n"
				+ "											 TOT_UNIT_CNT,\r\n"
				+ "											 TOT_MRCH_PRICE_AMT,\r\n"
				+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "										FROM     Q.ORD_STAT_SUM_A O \r\n"
				+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "									UNION ALL\r\n"
				+ "										SELECT   O.ORD_FLOW_STAT_ID,\r\n"
				+ "											 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
				+ "											 O.PKG_CNT TOT_PKG_CNT,\r\n"
				+ "											 O.TOT_ORD_LN_CNT,\r\n"
				+ "											 O.TOT_UNIT_CNT,\r\n"
				+ "											 O.TOT_MRCH_PRICE_AMT,\r\n"
				+ "											 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "										FROM     Q.PKG_STAT_SUM_A O \r\n"
				+ "											 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
				+ "											 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "						\r\n"
				+ "								) C\r\n"
				+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
				+ "							) D\r\n"
				+ "						WHERE\r\n"
				+ "							OAT.OSCR_ACTV_TBL_CD = 'A' \r\n"
				+ "							\r\n"
				+ "						UNION ALL\r\n"
				+ "						\r\n"
				+ "						\r\n"
				+ "						SELECT\r\n"
				+ "							 D.ORD_FLOW_STAT_ID,\r\n"
				+ "						         D.DC_ID AS DC_ID,\r\n"
				+ "						         NULL AS AGE_BUCKET_CD,\r\n"
				+ "						         D.IS_EXCPTN_IND,\r\n"
				+ "						         D.TOT_ORD_LN_CNT,\r\n"
				+ "						         D.TOT_UNIT_CNT,\r\n"
				+ "						         D.TOT_MRCH_PRICE_AMT,\r\n"
				+ "						         D.TOT_PKG_CNT	\r\n"
				+ "						FROM\r\n"
				+ "							Q.OSCR_ACTV_TBL OAT,\r\n"
				+ "							(\r\n"
				+ "								SELECT   \r\n"
				+ "									 C.ORD_FLOW_STAT_ID,\r\n"
				+ "									 C.DC_ID AS DC_ID,\r\n"
				+ "									 C.IS_EXCPTN_IND,\r\n"
				+ "									 SUM(C.TOT_ORD_LN_CNT) AS TOT_ORD_LN_CNT,\r\n"
				+ "									 SUM(C.TOT_UNIT_CNT) AS TOT_UNIT_CNT,\r\n"
				+ "									 SUM(C.TOT_MRCH_PRICE_AMT) AS TOT_MRCH_PRICE_AMT,\r\n"
				+ "									 SUM(C.TOT_PKG_CNT) AS TOT_PKG_CNT\r\n"
				+ "								FROM     \r\n"
				+ "								(\r\n"
				+ "									SELECT   \r\n"
				+ "										 O.ORD_FLOW_STAT_ID,\r\n"
				+ "										 NULL AS DC_ID,\r\n"
				+ "										 0 AS TOT_PKG_CNT,\r\n"
				+ "										 TOT_ORD_LN_CNT,\r\n"
				+ "										 TOT_UNIT_CNT,\r\n"
				+ "										 TOT_MRCH_PRICE_AMT,\r\n"
				+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "									FROM     Q.ORD_STAT_SUM_B O \r\n"
				+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "									UNION ALL\r\n"
				+ "									SELECT   O.ORD_FLOW_STAT_ID,\r\n"
				+ "										 CASE WHEN (DC.QVC_OPERTED_IND = 'Y' AND DC.DC_TYP_CD != '3PL') THEN DC.SITE_CD ELSE CAST(DC.DC_ID as char) END DC_ID,\r\n"
				+ "										 O.PKG_CNT TOT_PKG_CNT,\r\n"
				+ "										 O.TOT_ORD_LN_CNT,\r\n"
				+ "										 O.TOT_UNIT_CNT,\r\n"
				+ "										 O.TOT_MRCH_PRICE_AMT,\r\n"
				+ "										 CASE WHEN STAT.ORD_FLOW_STAT_ID IS NOT NULL THEN 'Yes' ELSE 'No' END IS_EXCPTN_IND\r\n"
				+ "									FROM     Q.PKG_STAT_SUM_B O \r\n"
				+ "										 JOIN Q.DIST_CTR DC ON DC.DC_ID = O.DC_ID \r\n"
				+ "										 LEFT JOIN Q.ORD_FLOW_STAT_ATTR STAT ON O.ORD_FLOW_STAT_ID = STAT.ORD_FLOW_STAT_ID AND STAT.ORD_FLOW_ATTR_CD = 'ISEX1'\r\n"
				+ "						\r\n"
				+ "								) C\r\n"
				+ "								GROUP BY C.ORD_FLOW_STAT_ID, C.DC_ID, C.IS_EXCPTN_IND	\r\n"
				+ "							) D\r\n"
				+ "						WHERE\r\n"
				+ "							OAT.OSCR_ACTV_TBL_CD = 'B'\r\n"
				+ ")T\r\n"
				+ "\r\n"
				+ "JOIN \r\n"
				+ "(SELECT\r\n"
				+ "					ord_flow_stat_id,\r\n"
				+ "					busn_proc_typ_dsc,\r\n"
				+ "					busn_acty_typ_dsc,\r\n"
				+ "					ord_flow_sum_dsc,\r\n"
				+ "					ord_flow_rsn_dsc,\r\n"
				+ "					busn_proc_typ_cd,\r\n"
				+ "					busn_acty_typ_cd,\r\n"
				+ "					ord_flow_sum_cd,\r\n"
				+ "					ord_flow_rsn_cd,\r\n"
				+ "					is_excptn_ind,\r\n"
				+ "					ord_flow_lvl_dsc,\r\n"
				+ "					is_oscrol_ind,\r\n"
				+ "					is_oscrpkd_ind,\r\n"
				+ "					is_oscrpkq_ind\r\n"
				+ "				FROM\r\n"
				+ "					q.ord_flow_stat_vw with(nolock)		\r\n"
				+ "WHERE is_oscrol_ind = 'Yes' OR is_oscrpkd_ind = 'Yes' OR is_oscrpkq_ind = 'Yes') VW on VW.ord_flow_stat_id = T.ord_flow_stat_id";
		*/
	String itExceptionsWhereClause = "  AND VW.is_excptn_ind = 'Yes' ";
	
	String financeOrderWhereSQL = "   WHERE VW.busn_proc_typ_dsc = 'Demand Fulfillment'";
	
	
	String packageDetailQuery = "SELECT aol.ORD_NBR , aol.ORD_LN_NBR, aol.ITEM_NBR , aol.ACCT_NBR , aol.ORD_DT, aol.LAST_UPD_TMS as order_last_UPD_TMS, ap.PKG_ID , ap.INVC_NBR , ap.BOX_NBR ,ap.LAST_UPD_TMS as package_last_UPD_TMS, dc.LEGACY_WHSE_NBR, dc.DC_DSC\r\n" + 
			"FROM     q.active_ord_ln aol with(nolock)\r\n" + 
			"         left join q.package_ol_rel por with(nolock) on por.ORD_NBR = aol.ORD_NBR AND por.ORD_LN_NBR = AOL.ORD_LN_NBR \r\n" + 
			"         left join Q.ACTV_PKG ap with(nolock) on ap.PKG_ID =por.PKG_ID \r\n" + 
			"left join q.DIST_CTR dc on dc.dc_id= ap.SRCED_DC_ID\r\n" + 
			"where ((ap.last_upd_tms>=? and ap.last_upd_tms <=?) or (aol.last_upd_tms>=? and aol.last_upd_tms<=? )) and (aol.ord_flow_stat_id =? or ap.ord_flow_stat_id =?)";
	
	@SuppressWarnings("deprecation")
	public List<OrderFlowExceptions> getBusinessExceptions(Date startDate, Date endDate) {
		List<OrderFlowExceptions> financeBusinessExceptionsList = new ArrayList<>();
		System.out.println("Demand Fulfilment Business Query:");
		try {
			financeBusinessExceptionsList = jdbcTemplate.query(orderSummaryQuery,new Object[] { startDate, endDate,startDate, endDate,"NO" }, new OrderFlowRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Demand Fulfilment Business Exception:");
			System.out.println(e);
		}
		return financeBusinessExceptionsList;
	}

	@SuppressWarnings("deprecation")
	public List<OrderFlowExceptions> getITExceptions(Date startDate, Date endDate) {
		List<OrderFlowExceptions> financeITExceptionsList = new ArrayList<>();
		System.out.println("Demand Fulfilment Exception Query:");
		try {
			financeITExceptionsList = jdbcTemplate.query(orderSummaryQuery ,new Object[] {startDate, endDate,startDate, endDate,"YES"},new OrderFlowRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Demand Fulfilment IT Exception:");
			System.out.println(e);
		}
		return financeITExceptionsList;
	}
	
	
	@SuppressWarnings("deprecation")
	public List<PackageDetailsModel> getPackageDetails(String status,Date startDate, Date endDate) {
		List<PackageDetailsModel> packageDetailsModels = new ArrayList<>();
		System.out.println("Demand Fulfilment Package Details Query:");
		try {
			packageDetailsModels = jdbcTemplate.query(packageDetailQuery ,new Object[] {startDate, endDate,startDate, endDate,status,status},new PackageDetailsRowMapper());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Demand Fulfilment Package Details Exception:");
			System.out.println(e);
		}
		return packageDetailsModels;
	}
	
	
	
	

	@Override
	public List<OrderDetailsModel> getorderDetailsJSON(int status, Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderFlowStatVWModel getOrderFlowStatusVW(String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderFlowExceptions getpackageNotCreated(Date startDate,Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
