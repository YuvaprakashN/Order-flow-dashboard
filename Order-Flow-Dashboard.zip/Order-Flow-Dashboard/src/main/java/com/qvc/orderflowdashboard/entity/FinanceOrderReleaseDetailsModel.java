package com.qvc.orderflowdashboard.entity;

import java.util.Date;

public class FinanceOrderReleaseDetailsModel {
	
	private String orderNumber;
	private Integer orderLineNumber;
	private String itemNumber;
	private Date aolLastUpdatedDate;

	
	private Date statusEffTimestamp;
	
	private String activeOrdLnStatus;

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}

	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Date getAolLastUpdatedDate() {
		return aolLastUpdatedDate;
	}

	public void setAolLastUpdatedDate(Date aolLastUpdatedDate) {
		this.aolLastUpdatedDate = aolLastUpdatedDate;
	}

	public Date getStatusEffTimestamp() {
		return statusEffTimestamp;
	}

	public void setStatusEffTimestamp(Date statusEffTimestamp) {
		this.statusEffTimestamp = statusEffTimestamp;
	}

	public String getActiveOrdLnStatus() {
		return activeOrdLnStatus;
	}

	public void setActiveOrdLnStatus(String activeOrdLnStatus) {
		this.activeOrdLnStatus = activeOrdLnStatus;
	}

	@Override
	public String toString() {
		return "FinanceOrderReleaseDetailsModel [orderNumber=" + orderNumber + ", orderLineNumber=" + orderLineNumber
				+ ", itemNumber=" + itemNumber + ", aolLastUpdatedDate=" + aolLastUpdatedDate + ", statusEffTimestamp="
				+ statusEffTimestamp + ", activeOrdLnStatus=" + activeOrdLnStatus + "]";
	}

}
