package com.qvc.orderflowdashboard.response;

import java.util.List;

import com.qvc.orderflowdashboard.entity.OrderStatusCountModel;

public class DemandManagementData{
	private List<OrderStatusCountModel> demandManagement;
	private String colorFlag;
	public List<OrderStatusCountModel> getDemandManagement() {
		return demandManagement;
	}
	public void setDemandManagement(List<OrderStatusCountModel> demandManagement) {
		this.demandManagement = demandManagement;
	}
	public String getColorFlag() {
		return colorFlag;
	}
	public void setColorFlag(String colorFlag) {
		this.colorFlag = colorFlag;
	}
	@Override
	public String toString() {
		return "DemandManagementData [demandManagement=" + demandManagement + ", colorFlag=" + colorFlag + "]";
	}	
	
}