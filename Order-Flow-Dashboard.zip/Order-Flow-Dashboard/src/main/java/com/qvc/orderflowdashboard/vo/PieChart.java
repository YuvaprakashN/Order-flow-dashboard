package com.qvc.orderflowdashboard.vo;

import java.util.List;

public class PieChart {
	private List<String> labels;
	private List<PieChartDatasets> datasets;
	

	public PieChart(List<String> labels, List<PieChartDatasets> datasets) {
		super();
		this.labels = labels;
		this.datasets = datasets;
	}
	public List<PieChartDatasets> getdatasets() {
		return datasets;
	}
	public void setdatasets(List<PieChartDatasets> datasets) {
		this.datasets = datasets;
	}
	public List<String> getlabels() {
		return labels;
	}
	public void setlabels(List<String> labels) {
		this.labels = labels;
	}
	@Override
	public String toString() {
		return "PieChart [labels=" + labels + ", datasets=" + datasets + "]";
	}
	
	
	
}