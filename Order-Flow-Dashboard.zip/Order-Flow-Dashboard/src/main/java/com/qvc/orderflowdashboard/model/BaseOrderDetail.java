package com.qvc.orderflowdashboard.model;

public class BaseOrderDetail {

	private String orderNumber;
	private Integer orderLineNumber;
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}
	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}
	@Override
	public String toString() {
		return "\nBaseOrderDetail [orderNumber=" + orderNumber + ", orderLineNumber=" + orderLineNumber + "]";
	}
	
	
}
